(() => {
  "use strict";

  const providedExampleFiles = [
    "C:\\Users\\ULTRAPC\\Downloads\\pmcap-FortniteClient-Win64-Shipping.exe-260403-163911.csv",
    "C:\\Users\\ULTRAPC\\Downloads\\pmcap-FortniteClient-Win64-Shipping.exe-260403-163911-stats.csv"
  ];

  const state = {
    viewMode: "beginner",
    samples: [],
    analysis: null,
    replaceTargetId: null,
    docSection: "workflow",
    nextId: 1
  };

  const metricCatalog = {
    avgFps: {
      beginnerName: "Average Performance",
      technicalName: "Average FPS",
      unit: "FPS",
      beginnerExplanation: "The overall speed of the run. Higher means the game stayed faster on average.",
      technicalExplanation: "Calculated as the inverse of mean frametime across valid frames. This is the baseline throughput metric."
    },
    medianFps: {
      beginnerName: "Typical Performance",
      technicalName: "Median FPS",
      unit: "FPS",
      beginnerExplanation: "What a typical frame rate looked like once isolated spikes are ignored.",
      technicalExplanation: "The 50th percentile of instantaneous FPS values. Useful when spikes distort the average."
    },
    p1Low: {
      beginnerName: "Worst 1% Moments",
      technicalName: "1% Low FPS",
      unit: "FPS",
      beginnerExplanation: "How the game behaved in the roughest moments that still happen often enough to matter.",
      technicalExplanation: "Mean FPS of the slowest 1% of frames. This captures meaningful low-end smoothness."
    },
    p01Low: {
      beginnerName: "Severe Stutter Floor",
      technicalName: "0.1% Low FPS",
      unit: "FPS",
      beginnerExplanation: "The extreme bottom end. Lower values here usually mean visible hitching or bad spikes.",
      technicalExplanation: "Mean FPS of the slowest 0.1% of frames. High noise is common on small samples."
    },
    avgFrametime: {
      beginnerName: "Average Frame Time",
      technicalName: "Average Frametime",
      unit: "ms",
      beginnerExplanation: "How long each frame took on average. Lower is better.",
      technicalExplanation: "Mean frame interval in milliseconds, derived from MsBetweenPresents or a fallback timing column."
    },
    p95Frametime: {
      beginnerName: "Rough Frames",
      technicalName: "95th Percentile Frametime",
      unit: "ms",
      beginnerExplanation: "The upper edge of normal bad frames. Lower means fewer noticeable slowdowns.",
      technicalExplanation: "95th percentile frametime. This isolates the slower side of the frame pacing distribution."
    },
    p99Frametime: {
      beginnerName: "Very Bad Frames",
      technicalName: "99th Percentile Frametime",
      unit: "ms",
      beginnerExplanation: "Rare but visible stalls. Lower is better.",
      technicalExplanation: "99th percentile frametime. Strong indicator for infrequent but impactful hitches."
    },
    frametimeCv: {
      beginnerName: "Smoothness Stability",
      technicalName: "Frametime Coefficient of Variation",
      unit: "",
      beginnerExplanation: "How stable the run felt from frame to frame. Lower means smoother delivery.",
      technicalExplanation: "Standard deviation divided by mean frametime. A compact dispersion metric for pacing stability."
    },
    durationSec: {
      beginnerName: "Capture Length",
      technicalName: "Duration",
      unit: "s",
      beginnerExplanation: "Longer captures tend to be more trustworthy because they include more situations.",
      technicalExplanation: "Total capture duration. Used directly in reliability scoring and group weighting."
    },
    frameCount: {
      beginnerName: "Frames Collected",
      technicalName: "Frame Count",
      unit: "",
      beginnerExplanation: "More frames usually means a more representative sample.",
      technicalExplanation: "Total valid timing rows retained after parsing and integrity filtering."
    }
  };

  const docSections = {
    workflow: {
      title: "Workflow and File Intake",
      body: `
        <div class="doc-card">
          <h4>How to use the analyzer</h4>
          <ul>
            <li>Load one or more PresentMon raw exports. Matching <span class="mono">-stats.csv</span> files are attached automatically when the base name matches.</li>
            <li>Rename the sample if needed and assign it to <strong>Before</strong>, <strong>After</strong>, or <strong>Neutral</strong>.</li>
            <li>Run analysis. Single samples get a validity verdict. Before/after groups get aggregation, comparison, confidence, and troubleshooting.</li>
            <li>If a file is malformed or missing critical timing columns, the analyzer tells you exactly what is missing and why that matters.</li>
          </ul>
        </div>
        <div class="doc-card">
          <h4>Supported input forms</h4>
          <ul>
            <li>Raw PresentMon frame-level exports with columns such as <span class="mono">MsBetweenPresents</span>, <span class="mono">TimeInSeconds</span>, <span class="mono">MsGPUTime</span>, and <span class="mono">Application</span>.</li>
            <li>Companion stats exports with fields such as <span class="mono">Average FPS</span>, <span class="mono">Duration</span>, and <span class="mono">1st Percentile FPS</span>.</li>
            <li>Stats-only samples are accepted, but they receive a reliability penalty because the analyzer cannot inspect raw frame pacing distributions.</li>
          </ul>
        </div>
      `
    },
    verdicts: {
      title: "Verdict Engine",
      body: `
        <div class="doc-card">
          <h4>How verdicts are decided</h4>
          <p>
            The engine combines average performance, low-percentile performance, frametime percentiles,
            pacing variability, and data quality. Each metric contributes to a weighted score, but only after the
            analyzer checks whether the observed change is larger than the likely noise floor.
          </p>
          <ul>
            <li><strong>Clear Improvement / Regression:</strong> multiple important metrics move in the same direction and exceed expected noise.</li>
            <li><strong>Mild Improvement / Regression:</strong> the signal points one way, but either the effect is small or confidence is not high enough for a stronger claim.</li>
            <li><strong>No Meaningful Difference:</strong> changes exist but remain inside the range where overlap and noise are too strong.</li>
            <li><strong>Inconclusive / Low Confidence:</strong> short captures, sample disagreement, heavy overlap, missing metrics, or noisy runs prevent a safe conclusion.</li>
          </ul>
        </div>
        <div class="doc-card">
          <h4>Conflict-aware logic</h4>
          <p>
            Higher average FPS is never treated as an automatic win. If averages improve but 1% lows worsen, or if
            frametime variability gets worse, the verdict is downgraded and the explanation calls that out directly.
          </p>
        </div>
      `
    },
    reliability: {
      title: "Validity and Reliability",
      body: `
        <div class="doc-card">
          <h4>Reliability scoring model</h4>
          <ul>
            <li><strong>Duration adequacy:</strong> very short captures are less trustworthy.</li>
            <li><strong>Frame count adequacy:</strong> too few frames reduce representativeness and percentile stability.</li>
            <li><strong>Internal stability:</strong> high frametime variance and large tail spikes reduce confidence.</li>
            <li><strong>Outlier behavior:</strong> extreme frame spikes or group-level outlier runs get penalized.</li>
            <li><strong>Data completeness:</strong> malformed numeric fields or missing timing columns lower trust.</li>
            <li><strong>Group consistency:</strong> when a run strongly disagrees with its siblings, the merge logic lowers its influence and explains why.</li>
          </ul>
        </div>
        <div class="doc-card">
          <h4>Status labels</h4>
          <ul>
            <li><strong>Reliable:</strong> the sample is long enough, stable enough, and complete enough to trust as primary evidence.</li>
            <li><strong>Borderline:</strong> usable with caution, but one or more weaknesses limit certainty.</li>
            <li><strong>Problematic:</strong> the run contains enough noise or quality issues that it should not carry much weight.</li>
            <li><strong>Re-test Recommended:</strong> integrity is too weak for a safe readout.</li>
          </ul>
        </div>
      `
    },
    metrics: {
      title: "Metric Glossary",
      body: ""
    },
    interpretation: {
      title: "Interpretation Guide",
      body: `
        <div class="doc-card">
          <h4>How to interpret common patterns</h4>
          <ul>
            <li><strong>Higher average FPS but worse lows:</strong> the system may peak higher, but delivery is less even. Real play can still feel worse.</li>
            <li><strong>Similar averages, worse frametime spread:</strong> the benchmark may be hiding stutter behind stable averages.</li>
            <li><strong>Lower average FPS with tighter variance:</strong> a limiter, power behavior, or tighter pacing may be reducing raw throughput while improving consistency.</li>
            <li><strong>Big changes smaller than sample noise:</strong> treat the result as inconclusive and capture more runs instead of forcing a verdict.</li>
            <li><strong>One run far outside the group:</strong> treat it as potential bad capture or environmental drift until a repeat confirms it.</li>
          </ul>
        </div>
        <div class="doc-card">
          <h4>When to re-test</h4>
          <ul>
            <li>Capture duration is too short to represent the scenario.</li>
            <li>Run-to-run variation is high enough that before and after overlap heavily.</li>
            <li>One sample dominates the group average because it is far from the others.</li>
            <li>Raw exports are missing and only summary stats are available for a key result.</li>
          </ul>
        </div>
      `
    }
  };

  const dom = {
    fileInput: document.getElementById("fileInput"),
    replaceInput: document.getElementById("replaceInput"),
    uploadZone: document.getElementById("uploadZone"),
    runAnalysisBtn: document.getElementById("runAnalysisBtn"),
    clearAllBtn: document.getElementById("clearAllBtn"),
    loadProvidedExampleBtn: document.getElementById("loadProvidedExampleBtn"),
    intakeBanner: document.getElementById("intakeBanner"),
    intakeBannerText: document.getElementById("intakeBannerText"),
    sampleList: document.getElementById("sampleList"),
    resultsHost: document.getElementById("resultsHost"),
    loadedSampleCount: document.getElementById("loadedSampleCount"),
    loadedStatsCount: document.getElementById("loadedStatsCount"),
    sessionStateLabel: document.getElementById("sessionStateLabel"),
    sessionStateText: document.getElementById("sessionStateText"),
    tooltip: document.getElementById("tooltip")
  };

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function mean(values) {
    if (!values.length) {
      return null;
    }
    return values.reduce((sum, value) => sum + value, 0) / values.length;
  }

  function sum(values) {
    return values.reduce((total, value) => total + value, 0);
  }

  function percentile(values, p) {
    if (!values.length) {
      return null;
    }
    const sorted = values.slice().sort((a, b) => a - b);
    const index = (sorted.length - 1) * p;
    const lower = Math.floor(index);
    const upper = Math.ceil(index);
    if (lower === upper) {
      return sorted[lower];
    }
    const weight = index - lower;
    return sorted[lower] + (sorted[upper] - sorted[lower]) * weight;
  }

  function median(values) {
    return percentile(values, 0.5);
  }

  function standardDeviation(values) {
    if (values.length < 2) {
      return 0;
    }
    const avg = mean(values);
    const variance = mean(values.map((value) => (value - avg) ** 2));
    return Math.sqrt(variance);
  }

  function coefficientOfVariation(values) {
    const avg = mean(values);
    if (!avg) {
      return null;
    }
    return standardDeviation(values) / avg;
  }

  function weightedMean(values, weights) {
    let weightedTotal = 0;
    let totalWeight = 0;
    for (let index = 0; index < values.length; index += 1) {
      const value = values[index];
      const weight = weights[index];
      if (Number.isFinite(value) && Number.isFinite(weight) && weight > 0) {
        weightedTotal += value * weight;
        totalWeight += weight;
      }
    }
    return totalWeight > 0 ? weightedTotal / totalWeight : null;
  }

  function weightedQuantile(values, weights, q) {
    const pairs = values
      .map((value, index) => ({ value, weight: weights[index] }))
      .filter((pair) => Number.isFinite(pair.value) && Number.isFinite(pair.weight) && pair.weight > 0)
      .sort((a, b) => a.value - b.value);
    if (!pairs.length) {
      return null;
    }
    const totalWeight = pairs.reduce((acc, pair) => acc + pair.weight, 0);
    let running = 0;
    for (const pair of pairs) {
      running += pair.weight;
      if (running / totalWeight >= q) {
        return pair.value;
      }
    }
    return pairs[pairs.length - 1].value;
  }

  function medianAbsoluteDeviation(values) {
    if (!values.length) {
      return 0;
    }
    const med = median(values);
    return median(values.map((value) => Math.abs(value - med))) || 0;
  }

  function normalizeNumber(value) {
    if (value == null) {
      return null;
    }
    const trimmed = String(value).trim();
    if (!trimmed || /^na$/i.test(trimmed) || /^n\/a$/i.test(trimmed)) {
      return null;
    }
    const parsed = Number.parseFloat(trimmed);
    return Number.isFinite(parsed) ? parsed : null;
  }

  function trimmedStem(filename) {
    return filename
      .replace(/\\/g, "/")
      .split("/")
      .pop()
      .replace(/\.csv$/i, "")
      .replace(/-stats$/i, "")
      .replace(/_stats$/i, "");
  }

  function normalizeGroup(rawValue) {
    const value = String(rawValue ?? "").toLowerCase();
    if (value.includes("after")) {
      return "after";
    }
    if (value.includes("before")) {
      return "before";
    }
    return "neutral";
  }

  function formatNumber(value, decimals = 2) {
    if (!Number.isFinite(value)) {
      return "N/A";
    }
    return new Intl.NumberFormat("en-US", {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(value);
  }

  function formatShortNumber(value) {
    if (!Number.isFinite(value)) {
      return "N/A";
    }
    return new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(value);
  }

  function formatPercent(value, decimals = 1) {
    if (!Number.isFinite(value)) {
      return "N/A";
    }
    return `${value >= 0 ? "+" : ""}${formatNumber(value, decimals)}%`;
  }

  function slugMetricName(metricKey) {
    const metric = metricCatalog[metricKey];
    return metric ? (state.viewMode === "beginner" ? metric.beginnerName : metric.technicalName) : metricKey;
  }

  function parseCsv(text) {
    const rows = [];
    let current = "";
    let row = [];
    let inQuotes = false;

    for (let index = 0; index < text.length; index += 1) {
      const char = text[index];
      if (inQuotes) {
        if (char === '"') {
          if (text[index + 1] === '"') {
            current += '"';
            index += 1;
          } else {
            inQuotes = false;
          }
        } else {
          current += char;
        }
      } else if (char === '"') {
        inQuotes = true;
      } else if (char === ",") {
        row.push(current);
        current = "";
      } else if (char === "\n") {
        row.push(current);
        rows.push(row);
        row = [];
        current = "";
      } else if (char !== "\r") {
        current += char;
      }
    }

    if (current.length || row.length) {
      row.push(current);
      rows.push(row);
    }

    if (!rows.length) {
      return { headers: [], records: [] };
    }

    const headers = rows[0].map((header) => header.trim());
    const records = rows.slice(1)
      .filter((record) => record.some((field) => field && field.trim().length))
      .map((record) => {
        const mapped = {};
        headers.forEach((header, index) => {
          mapped[header] = record[index] ?? "";
        });
        return mapped;
      });

    return { headers, records };
  }

  function inferFileKind(headers) {
    const set = new Set(headers.map((header) => header.trim().toLowerCase()));
    if (set.has("average fps") && set.has("duration")) {
      return "stats";
    }
    if (set.has("msbetweenpresents") || set.has("timeinseconds") || set.has("msbetweendisplaychange")) {
      return "raw";
    }
    return "unknown";
  }

  function ratioPart(part, total) {
    return total > 0 ? part / total : 0;
  }

  function quantileSeriesAverage(values, ratio) {
    if (!values.length) {
      return null;
    }
    const sorted = values.slice().sort((a, b) => a - b);
    const count = Math.max(1, Math.ceil(sorted.length * ratio));
    return mean(sorted.slice(0, count));
  }

  function createHistogram(values, binCount) {
    if (!values.length) {
      return [];
    }
    const min = Math.min(...values);
    const max = Math.max(...values);
    if (min === max) {
      return [{ x0: min, x1: max, count: values.length }];
    }
    const bins = Array.from({ length: binCount }, (_, index) => ({
      x0: min + ((max - min) / binCount) * index,
      x1: min + ((max - min) / binCount) * (index + 1),
      count: 0
    }));
    for (const value of values) {
      const normalized = (value - min) / (max - min);
      const index = clamp(Math.floor(normalized * binCount), 0, binCount - 1);
      bins[index].count += 1;
    }
    return bins;
  }

  function seriesFromRows(records, column) {
    return records
      .map((record) => normalizeNumber(record[column]))
      .filter((value) => Number.isFinite(value));
  }

  function setBanner(type, message) {
    dom.intakeBanner.className = `status-banner active ${type}`;
    dom.intakeBannerText.textContent = message;
  }

  function findSampleByStem(stem) {
    return state.samples.find((sample) => sample.stem === stem);
  }

  function createSampleBase(filename) {
    const stem = trimmedStem(filename);
    return {
      id: state.nextId++,
      name: stem,
      stem,
      role: normalizeGroup(stem),
      rawFileName: null,
      statsFileName: null,
      rawAnalysis: null,
      statsAnalysis: null,
      analysis: null
    };
  }

  function baseSvg(width, height) {
    return `<svg viewBox="0 0 ${width} ${height}" width="100%" height="100%" preserveAspectRatio="none">`;
  }

  function datasetMeta(role) {
    if (role === "before") {
      return {
        label: "Before",
        className: "before",
        explanation: "Baseline dataset"
      };
    }
    if (role === "after") {
      return {
        label: "After",
        className: "after",
        explanation: "Changed dataset"
      };
    }
    return {
      label: "Neutral",
      className: "neutral",
      explanation: "Standalone dataset"
    };
  }

  function semanticTone(signal) {
    if (!signal) {
      return {
        className: "neutral",
        label: "Standalone",
        arrow: "•",
        summary: "No comparison delta"
      };
    }

    if (signal.strength > 0.4) {
      return {
        className: "positive",
        label: "Improvement",
        arrow: "▲",
        summary: "After is better"
      };
    }

    if (signal.strength < -0.4) {
      return {
        className: "negative",
        label: "Regression",
        arrow: "▼",
        summary: "After is worse"
      };
    }

    return {
      className: "neutral",
      label: "No meaningful change",
      arrow: "•",
      summary: "Difference is inside noise"
    };
  }

  function metricPriority(metricKey) {
    if (metricKey === "avgFps" || metricKey === "p1Low") {
      return "primary";
    }
    if (metricKey === "avgFrametime") {
      return "primary";
    }
    return "secondary";
  }

  /* ANALYSIS */

  function extractFrameTimes(records, issues) {
    const frameTimes = [];
    const timeSeries = [];
    let invalidTimingRows = 0;
    let timeBacktracks = 0;
    let previousTime = null;
    let missingTiming = 0;

    for (const record of records) {
      const type = String(record.FrameType || "").trim().toLowerCase();
      if (type && type !== "application") {
        continue;
      }

      const present = normalizeNumber(record.MsBetweenPresents);
      const display = normalizeNumber(record.MsBetweenDisplayChange);
      const time = normalizeNumber(record.TimeInSeconds);
      let frametime = Number.isFinite(present) && present > 0 ? present : null;
      if (!frametime && Number.isFinite(display) && display > 0) {
        frametime = display;
      }
      if (!frametime && Number.isFinite(time) && Number.isFinite(previousTime) && time > previousTime) {
        frametime = (time - previousTime) * 1000;
      }

      if (Number.isFinite(time)) {
        if (previousTime != null && time < previousTime) {
          timeBacktracks += 1;
        }
        previousTime = time;
        timeSeries.push(time);
      }

      if (Number.isFinite(frametime) && frametime > 0 && frametime < 1000) {
        frameTimes.push(frametime);
      } else if (frametime != null) {
        invalidTimingRows += 1;
      } else {
        missingTiming += 1;
      }
    }

    if (!frameTimes.length) {
      issues.push("No valid frame timing values could be derived from the file.");
    }
    if (timeBacktracks > 0) {
      issues.push(`Timestamp integrity issue: ${timeBacktracks} backward time step${timeBacktracks === 1 ? "" : "s"} detected.`);
    }
    if (invalidTimingRows > 0) {
      issues.push(`Dropped ${invalidTimingRows} malformed timing row${invalidTimingRows === 1 ? "" : "s"} during parsing.`);
    }

    return {
      frameTimes,
      timeSeries,
      invalidTimingRows,
      missingTimingRows: missingTiming,
      timeBacktracks
    };
  }

  function analyzeStatsRecord(record) {
    return {
      durationSec: normalizeNumber(record.Duration),
      frameCount: normalizeNumber(record["Total Frames"]),
      avgFps: normalizeNumber(record["Average FPS"]),
      minFps: normalizeNumber(record["Minimum FPS"]),
      p1Low: normalizeNumber(record["1st Percentile FPS"]),
      p5Low: normalizeNumber(record["5th Percentile FPS"]),
      maxFps: normalizeNumber(record["Maximum FPS"])
    };
  }

  function createReliability(sampleMetrics, parsing, hasRaw, statsOnly) {
    let score = 100;
    const notes = [];
    const flags = [];

    if (!hasRaw && statsOnly) {
      score -= 18;
      notes.push("Only summary stats are available, so raw frametime inspection is missing.");
      flags.push("Stats-only sample");
    }

    if (sampleMetrics.durationSec < 20) {
      score -= 30;
      notes.push("Capture duration is under 20 seconds and is unlikely to be representative.");
      flags.push("Very short capture");
    } else if (sampleMetrics.durationSec < 45) {
      score -= 14;
      notes.push("Capture duration is short enough that the results may still swing between repeats.");
      flags.push("Short capture");
    }

    if (sampleMetrics.frameCount < 3000) {
      score -= 24;
      notes.push("Frame count is very low for stable percentile analysis.");
      flags.push("Low frame count");
    } else if (sampleMetrics.frameCount < 8000) {
      score -= 10;
      notes.push("Frame count is usable but not especially strong for 0.1% low interpretation.");
      flags.push("Moderate frame count");
    }

    const completeness = 1 - ratioPart(parsing.invalidTimingRows + parsing.missingTimingRows, parsing.totalRows || 1);
    if (completeness < 0.9) {
      score -= 24;
      notes.push("Too many rows could not be used for timing analysis.");
      flags.push("Low data completeness");
    } else if (completeness < 0.97) {
      score -= 10;
      notes.push("Some rows were unusable, which lowers trust in the sample.");
      flags.push("Partial data loss");
    }

    if (sampleMetrics.frametimeCv > 0.35) {
      score -= 24;
      notes.push("Frametime variance is extremely high relative to the average.");
      flags.push("Severe variance");
    } else if (sampleMetrics.frametimeCv > 0.2) {
      score -= 12;
      notes.push("Frametime variance is elevated and may hide stutter behind average FPS.");
      flags.push("High variance");
    } else if (sampleMetrics.frametimeCv > 0.12) {
      score -= 6;
      notes.push("Frametime stability is fair, but not exceptionally clean.");
      flags.push("Moderate pacing spread");
    }

    if (sampleMetrics.outlierRate > 0.05) {
      score -= 22;
      notes.push("A large share of frames are extreme outliers.");
      flags.push("Heavy outlier tail");
    } else if (sampleMetrics.outlierRate > 0.02) {
      score -= 12;
      notes.push("The frametime distribution has a noticeable outlier tail.");
      flags.push("Outlier tail");
    } else if (sampleMetrics.outlierRate > 0.01) {
      score -= 6;
      notes.push("A small but real outlier tail is present.");
      flags.push("Minor outlier tail");
    }

    if (sampleMetrics.avgFrametime && sampleMetrics.p99Frametime / sampleMetrics.avgFrametime > 3.2) {
      score -= 14;
      notes.push("The worst frametime tail is much higher than the average frame time.");
      flags.push("Long hitch tail");
    }

    if (sampleMetrics.p1Low && sampleMetrics.avgFps && sampleMetrics.p1Low / sampleMetrics.avgFps < 0.45) {
      score -= 14;
      notes.push("The 1% lows are far below the average, suggesting uneven delivery.");
      flags.push("Weak lows");
    } else if (sampleMetrics.p1Low && sampleMetrics.avgFps && sampleMetrics.p1Low / sampleMetrics.avgFps < 0.6) {
      score -= 8;
      notes.push("The low-end performance trails the average by a meaningful margin.");
      flags.push("Average-to-low gap");
    }

    if (parsing.timeBacktracks > 0) {
      score -= 12;
      notes.push("Timestamp ordering is not fully monotonic.");
      flags.push("Timestamp anomaly");
    }

    score = clamp(Math.round(score), 5, 100);
    let label = "Reliable";
    let className = "good";
    if (score < 50) {
      label = "Re-test Recommended";
      className = "bad";
    } else if (score < 70) {
      label = "Problematic";
      className = "bad";
    } else if (score < 85) {
      label = "Borderline";
      className = "warn";
    }

    if (!notes.length) {
      notes.push("No major validity issues were detected in the sample itself.");
    }

    return { score, label, className, notes, flags, completeness };
  }

  function analyzeRawSample(parsed, fileMeta) {
    const issues = [];
    const parsing = {
      totalRows: parsed.records.length,
      invalidTimingRows: 0,
      missingTimingRows: 0,
      timeBacktracks: 0
    };
    const frameExtraction = extractFrameTimes(parsed.records, issues);
    parsing.invalidTimingRows = frameExtraction.invalidTimingRows;
    parsing.missingTimingRows = frameExtraction.missingTimingRows;
    parsing.timeBacktracks = frameExtraction.timeBacktracks;

    const frameTimes = frameExtraction.frameTimes;
    const fpsSeries = frameTimes.map((value) => 1000 / value);
    const avgFrametime = mean(frameTimes) ?? 0;
    const durationFromTime = frameExtraction.timeSeries.length > 1
      ? frameExtraction.timeSeries[frameExtraction.timeSeries.length - 1] - frameExtraction.timeSeries[0]
      : sum(frameTimes) / 1000;

    const p75 = percentile(frameTimes, 0.75) ?? 0;
    const p25 = percentile(frameTimes, 0.25) ?? 0;
    const iqr = p75 - p25;
    const outlierLimit = p75 + iqr * 3;
    const outlierRate = ratioPart(frameTimes.filter((value) => value > outlierLimit).length, frameTimes.length);
    const gpuTimes = seriesFromRows(parsed.records, "MsGPUTime");
    const displayLatencies = seriesFromRows(parsed.records, "MsUntilDisplayed");
    const cpuUtils = seriesFromRows(parsed.records, "CPUUtilization");
    const gpuUtils = seriesFromRows(parsed.records, "GPUUtilization");

    const metrics = {
      avgFps: avgFrametime > 0 ? 1000 / avgFrametime : null,
      medianFps: median(fpsSeries),
      p1Low: quantileSeriesAverage(fpsSeries, 0.01),
      p01Low: fpsSeries.length >= 1000 ? quantileSeriesAverage(fpsSeries, 0.001) : null,
      avgFrametime,
      medianFrametime: median(frameTimes),
      p95Frametime: percentile(frameTimes, 0.95),
      p99Frametime: percentile(frameTimes, 0.99),
      frametimeStdDev: standardDeviation(frameTimes),
      frametimeCv: coefficientOfVariation(frameTimes) ?? 0,
      durationSec: durationFromTime,
      frameCount: frameTimes.length,
      outlierRate,
      cpuUtilization: mean(cpuUtils),
      gpuUtilization: mean(gpuUtils),
      avgGpuTime: mean(gpuTimes),
      avgDisplayLatency: mean(displayLatencies)
    };

    const reliability = createReliability(metrics, parsing, true, false);
    const processName = parsed.records.find((record) => record.Application)?.Application || trimmedStem(fileMeta.name);

    return {
      kind: "raw",
      processName,
      metrics,
      reliability,
      parsing,
      issues,
      columns: parsed.headers,
      frameTimes,
      fpsSeries,
      rawStats: {
        displayLatencies,
        gpuTimes
      }
    };
  }

  function analyzeStatsOnlySample(parsed, fileMeta) {
    const record = parsed.records[0] || {};
    const stats = analyzeStatsRecord(record);
    const metrics = {
      avgFps: stats.avgFps,
      medianFps: stats.avgFps,
      p1Low: stats.p1Low,
      p01Low: null,
      avgFrametime: stats.avgFps ? 1000 / stats.avgFps : null,
      medianFrametime: stats.avgFps ? 1000 / stats.avgFps : null,
      p95Frametime: stats.p1Low ? 1000 / stats.p1Low : null,
      p99Frametime: stats.p1Low ? (1000 / stats.p1Low) * 1.1 : null,
      frametimeStdDev: null,
      frametimeCv: 0.12,
      durationSec: stats.durationSec || 0,
      frameCount: stats.frameCount || 0,
      outlierRate: 0,
      cpuUtilization: null,
      gpuUtilization: null,
      avgGpuTime: null,
      avgDisplayLatency: null
    };
    const parsing = { totalRows: parsed.records.length, invalidTimingRows: 0, missingTimingRows: 0, timeBacktracks: 0 };
    const reliability = createReliability(metrics, parsing, false, true);
    reliability.notes.unshift("Raw frame-level export is missing, so distribution-level diagnostics are limited.");
    return {
      kind: "stats",
      processName: trimmedStem(fileMeta.name),
      metrics,
      reliability,
      parsing,
      issues: ["Summary stats loaded without matching raw frame data."],
      columns: parsed.headers,
      frameTimes: [],
      fpsSeries: [],
      rawStats: { displayLatencies: [], gpuTimes: [] }
    };
  }

  function compareRawAndStats(sample) {
    if (!sample.rawAnalysis || !sample.statsAnalysis) {
      return [];
    }
    const issues = [];
    const delta = sample.rawAnalysis.metrics.avgFps && sample.statsAnalysis.metrics.avgFps
      ? ((sample.rawAnalysis.metrics.avgFps - sample.statsAnalysis.metrics.avgFps) / sample.statsAnalysis.metrics.avgFps) * 100
      : 0;
    if (Math.abs(delta) > 5) {
      issues.push(`Raw-derived average FPS differs from companion stats by ${formatNumber(delta, 1)}%.`);
    }
    return issues;
  }

  function mergeAnalyses(sample) {
    const primary = sample.rawAnalysis || sample.statsAnalysis;
    if (!primary) {
      return null;
    }
    const merged = JSON.parse(JSON.stringify(primary));
    if (sample.statsAnalysis) {
      merged.companionStats = sample.statsAnalysis.metrics;
    }
    merged.issues = [...primary.issues, ...compareRawAndStats(sample)];
    return merged;
  }

  function detectGroupOutliers(samples) {
    if (samples.length < 3) {
      return samples.map(() => ({ isOutlier: false, reasons: [] }));
    }

    const composite = samples.map((sample) => {
      const metrics = sample.analysis.metrics;
      const stability = metrics.frametimeCv || 0;
      return (metrics.avgFps || 0) * 0.6 + (metrics.p1Low || metrics.avgFps || 0) * 0.4 - stability * 100;
    });
    const compositeMedian = median(composite) || 0;
    const compositeMad = medianAbsoluteDeviation(composite) || 1;
    const avgList = samples.map((sample) => sample.analysis.metrics.avgFps || 0);
    const p1List = samples.map((sample) => sample.analysis.metrics.p1Low || sample.analysis.metrics.avgFps || 0);
    const cvList = samples.map((sample) => sample.analysis.metrics.frametimeCv || 0);
    const medians = {
      avg: median(avgList) || 0,
      p1: median(p1List) || 0,
      cv: median(cvList) || 0
    };
    const mads = {
      avg: medianAbsoluteDeviation(avgList) || 1,
      p1: medianAbsoluteDeviation(p1List) || 1,
      cv: medianAbsoluteDeviation(cvList) || 1
    };

    return samples.map((sample, index) => {
      const reasons = [];
      const compositeZ = 0.6745 * (composite[index] - compositeMedian) / compositeMad;
      const avgZ = 0.6745 * ((sample.analysis.metrics.avgFps || 0) - medians.avg) / mads.avg;
      const p1Z = 0.6745 * ((sample.analysis.metrics.p1Low || sample.analysis.metrics.avgFps || 0) - medians.p1) / mads.p1;
      const cvZ = 0.6745 * ((sample.analysis.metrics.frametimeCv || 0) - medians.cv) / mads.cv;
      if (Math.abs(avgZ) > 2.8) {
        reasons.push("average performance sits far from the rest of the group");
      }
      if (Math.abs(p1Z) > 2.8) {
        reasons.push("low-percentile behavior disagrees strongly with sibling runs");
      }
      if (Math.abs(cvZ) > 2.8) {
        reasons.push("frametime stability is a strong group outlier");
      }
      return {
        isOutlier: Math.abs(compositeZ) > 3.5 || reasons.length >= 2,
        reasons
      };
    });
  }

  function analyzeGroup(groupName, samples) {
    if (!samples.length) {
      return null;
    }

    const outliers = detectGroupOutliers(samples);
    const weights = samples.map((sample, index) => {
      const reliabilityFactor = clamp(sample.analysis.reliability.score / 100, 0.2, 1);
      const durationFactor = clamp(Math.sqrt(Math.max(sample.analysis.metrics.durationSec, 1) / 60), 0.7, 1.4);
      const outlierFactor = outliers[index].isOutlier ? 0.42 : 1;
      return reliabilityFactor * durationFactor * outlierFactor;
    });

    const metricList = ["avgFps", "medianFps", "p1Low", "p01Low", "avgFrametime", "medianFrametime", "p95Frametime", "p99Frametime", "frametimeCv"];
    const metrics = {};
    for (const key of metricList) {
      const values = samples.map((sample) => sample.analysis.metrics[key]);
      metrics[key] = weightedMean(values, weights);
      metrics[`${key}Median`] = weightedQuantile(values, weights, 0.5);
    }
    metrics.durationSec = sum(samples.map((sample) => sample.analysis.metrics.durationSec || 0));
    metrics.frameCount = sum(samples.map((sample) => sample.analysis.metrics.frameCount || 0));
    metrics.cpuUtilization = weightedMean(samples.map((sample) => sample.analysis.metrics.cpuUtilization), weights);
    metrics.gpuUtilization = weightedMean(samples.map((sample) => sample.analysis.metrics.gpuUtilization), weights);
    metrics.avgGpuTime = weightedMean(samples.map((sample) => sample.analysis.metrics.avgGpuTime), weights);
    metrics.avgDisplayLatency = weightedMean(samples.map((sample) => sample.analysis.metrics.avgDisplayLatency), weights);

    const avgFpsValues = samples.map((sample) => sample.analysis.metrics.avgFps).filter(Number.isFinite);
    const p1Values = samples.map((sample) => sample.analysis.metrics.p1Low || sample.analysis.metrics.avgFps).filter(Number.isFinite);
    const cvValues = samples.map((sample) => sample.analysis.metrics.frametimeCv).filter(Number.isFinite);
    const consistency = {
      avgFpsCv: coefficientOfVariation(avgFpsValues) || 0,
      p1Cv: coefficientOfVariation(p1Values) || 0,
      stabilitySpread: standardDeviation(cvValues),
      reliabilityAvg: mean(samples.map((sample) => sample.analysis.reliability.score)) || 0
    };

    const concatenatedFrameTimes = [];
    const concatenatedFps = [];
    samples.forEach((sample, index) => {
      if (!outliers[index].isOutlier) {
        concatenatedFrameTimes.push(...sample.analysis.frameTimes);
        concatenatedFps.push(...sample.analysis.fpsSeries);
      }
    });

    const notes = [];
    const outlierSamples = samples.filter((_, index) => outliers[index].isOutlier);
    if (outlierSamples.length) {
      notes.push(`${outlierSamples.length} run${outlierSamples.length === 1 ? "" : "s"} received lower merge weight because it sat far from the rest of the group.`);
    }
    if (consistency.avgFpsCv > 0.05 || consistency.p1Cv > 0.08) {
      notes.push("Run-to-run spread is large enough to reduce confidence in a tight verdict.");
    }
    if (!notes.length) {
      notes.push("Group runs are reasonably aligned, so the aggregate is stable.");
    }

    return { name: groupName, samples, outliers, weights, metrics, consistency, frameTimes: concatenatedFrameTimes, fpsSeries: concatenatedFps, notes };
  }

  function pctChange(afterValue, beforeValue, higherIsBetter = true) {
    if (!Number.isFinite(afterValue) || !Number.isFinite(beforeValue) || beforeValue === 0) {
      return null;
    }
    const raw = ((afterValue - beforeValue) / beforeValue) * 100;
    return higherIsBetter ? raw : -raw;
  }

  function buildConfidence(before, after, signals, conflictCount) {
    const avgReliability = ((before.consistency.reliabilityAvg || 0) + (after.consistency.reliabilityAvg || 0)) / 2;
    const sampleCount = before.samples.length + after.samples.length;
    const sampleBonus = sampleCount >= 6 ? 14 : sampleCount >= 4 ? 8 : 0;
    const spreadPenalty = clamp((before.consistency.avgFpsCv + after.consistency.avgFpsCv) * 180, 0, 24);
    const lowSpreadPenalty = clamp((before.consistency.p1Cv + after.consistency.p1Cv) * 150, 0, 24);
    const outlierPenalty = [...before.outliers, ...after.outliers].filter((flag) => flag.isOutlier).length * 6;
    const weakSignals = signals.filter((signal) => Math.abs(signal.strength) < 0.75).length * 2.5;
    let score = avgReliability * 0.72 + 12 + sampleBonus - spreadPenalty - lowSpreadPenalty - outlierPenalty - weakSignals - conflictCount * 8;
    score = clamp(Math.round(score), 10, 98);
    let label = "Low confidence";
    if (score >= 80) {
      label = "High confidence";
    } else if (score >= 60) {
      label = "Medium confidence";
    }
    const reasons = [];
    if (sampleCount < 4) {
      reasons.push("small sample count");
    }
    if (spreadPenalty + lowSpreadPenalty > 18) {
      reasons.push("high run-to-run spread");
    }
    if (outlierPenalty > 0) {
      reasons.push("group outliers");
    }
    if (avgReliability < 75) {
      reasons.push("sample validity concerns");
    }
    if (conflictCount > 0) {
      reasons.push("mixed metric directions");
    }
    if (!reasons.length) {
      reasons.push("consistent samples and aligned metrics");
    }
    return { score, label, reasons };
  }

  function analyzeComparison(before, after) {
    if (!before || !after) {
      return null;
    }

    const metricRules = [
      { key: "avgFps", higherIsBetter: true, weight: 0.23, noiseFloorPct: 2.5 },
      { key: "p1Low", higherIsBetter: true, weight: 0.24, noiseFloorPct: 3.0 },
      { key: "p01Low", higherIsBetter: true, weight: 0.14, noiseFloorPct: 4.5 },
      { key: "avgFrametime", higherIsBetter: false, weight: 0.12, noiseFloorPct: 2.5 },
      { key: "p95Frametime", higherIsBetter: false, weight: 0.14, noiseFloorPct: 3.5 },
      { key: "frametimeCv", higherIsBetter: false, weight: 0.13, noiseFloorPct: 6.0 }
    ];

    const signals = [];
    let totalScore = 0;
    for (const rule of metricRules) {
      const beforeValue = before.metrics[rule.key];
      const afterValue = after.metrics[rule.key];
      if (!Number.isFinite(beforeValue) || !Number.isFinite(afterValue)) {
        continue;
      }
      const directedDelta = rule.higherIsBetter ? afterValue - beforeValue : beforeValue - afterValue;
      const baseline = Math.abs(beforeValue) || 1;
      const practicalNoise = baseline * (rule.noiseFloorPct / 100);
      const runNoise = Math.abs(beforeValue) * ((before.consistency.avgFpsCv + after.consistency.avgFpsCv) / 2);
      const noiseFloor = Math.max(practicalNoise, runNoise, baseline * 0.01);
      const strength = clamp(directedDelta / noiseFloor, -2.8, 2.8);
      const pct = pctChange(afterValue, beforeValue, rule.higherIsBetter);
      signals.push({ ...rule, beforeValue, afterValue, directedDelta, pct, strength, contribution: strength * rule.weight });
      totalScore += strength * rule.weight;
    }

    const supporting = signals.filter((signal) => signal.strength > 0.55).sort((a, b) => b.strength - a.strength);
    const conflicting = signals.filter((signal) => signal.strength < -0.55).sort((a, b) => a.strength - b.strength);
    const confidence = buildConfidence(before, after, signals, conflicting.length && supporting.length ? 1 : 0);
    let label = "No Meaningful Difference";
    if (confidence.score < 55 && Math.abs(totalScore) < 0.85) {
      label = "Inconclusive / Low Confidence";
    } else if (totalScore >= 1.05) {
      label = "Clear Improvement";
    } else if (totalScore >= 0.38) {
      label = "Mild Improvement";
    } else if (totalScore <= -1.05) {
      label = "Clear Regression";
    } else if (totalScore <= -0.38) {
      label = "Mild Regression";
    }
    if (confidence.score < 45 && label !== "Clear Regression" && label !== "Clear Improvement") {
      label = "Inconclusive / Low Confidence";
    }

    const reasons = [];
    supporting.slice(0, 3).forEach((signal) => {
      reasons.push(`${slugMetricName(signal.key)} moved in favor of the After group (${formatPercent(signal.pct, 1)}).`);
    });
    conflicting.slice(0, 2).forEach((signal) => {
      reasons.push(`${slugMetricName(signal.key)} pushes the opposite way (${formatPercent(signal.pct, 1)}).`);
    });
    if (!reasons.length) {
      reasons.push("The major metrics overlap too much for a strong directional verdict.");
    }

    let recommendedAction = "Re-run the scenario with controlled conditions before making a hard decision.";
    if (label.includes("Improvement") && confidence.score >= 70) {
      recommendedAction = "The After setup looks favorable. Run one confirmation pass if you need a final sign-off.";
    } else if (label.includes("Regression") && confidence.score >= 70) {
      recommendedAction = "The After setup likely introduced a real regression. Investigate the conflicting change set or revert it.";
    } else if (label === "No Meaningful Difference") {
      recommendedAction = "Treat the two setups as effectively equal for now unless another metric outside this capture matters more.";
    }

    return { label, score: totalScore, confidence, signals, supporting, conflicting, reasons, recommendedAction };
  }

  function analyzeSingleSample(sample) {
    const reliability = sample.analysis.reliability;
    let verdict = "Reliable sample";
    if (reliability.score < 50) {
      verdict = "Re-test recommended";
    } else if (reliability.score < 70) {
      verdict = "Problematic sample";
    } else if (reliability.score < 85) {
      verdict = "Borderline sample";
    }
    return {
      label: verdict,
      reasons: reliability.notes.slice(0, 4),
      confidence: {
        score: clamp(reliability.score, 20, 95),
        label: reliability.score >= 85 ? "High confidence" : reliability.score >= 70 ? "Medium confidence" : "Low confidence",
        reasons: reliability.notes.slice(0, 3)
      },
      recommendedAction: reliability.score >= 85
        ? "Use this run as primary evidence, but still keep a sibling capture if the decision is important."
        : "Capture a longer or cleaner repeat before trusting this run too much."
    };
  }

  function buildTroubleshooting(analysis) {
    const suggestions = [];
    const pushSuggestion = (title, explanation, confidence, evidence, retestFirst) => {
      suggestions.push({ title, explanation, confidence, evidence, retestFirst });
    };

    if (analysis.mode === "comparison") {
      const { before, after, comparison } = analysis;
      const avgDelta = pctChange(after.metrics.avgFps, before.metrics.avgFps, true) || 0;
      const lowDelta = pctChange(after.metrics.p1Low, before.metrics.p1Low, true) || 0;
      const cvDelta = pctChange(after.metrics.frametimeCv, before.metrics.frametimeCv, false) || 0;
      if (avgDelta > 2 && lowDelta < -2) {
        pushSuggestion(
          "Higher peak throughput, worse worst-case smoothness",
          "The After group gained average FPS but lost 1% low performance, which often points to instability or uneven delivery rather than a clean win.",
          "Medium",
          `Average FPS changed ${formatPercent(avgDelta, 1)} while 1% low changed ${formatPercent(lowDelta, 1)}.`,
          true
        );
      }
      if (cvDelta < -6) {
        pushSuggestion(
          "Frame pacing became less stable",
          "The after runs show worse frametime spread even if averages look similar. Check for stutter sources, scheduling changes, or intermittent background activity.",
          "Medium",
          `Frametime variability moved ${formatPercent(cvDelta, 1)} in the wrong direction.`,
          false
        );
      }
      if (before.outliers.some((flag) => flag.isOutlier) || after.outliers.some((flag) => flag.isOutlier)) {
        pushSuggestion(
          "A single run is distorting the aggregate",
          "One or more runs are far from the rest of their group and were automatically down-weighted during aggregation.",
          "High",
          "The merge logic detected a group outlier and reduced its influence.",
          true
        );
      }
      if (before.consistency.avgFpsCv > 0.05 || after.consistency.avgFpsCv > 0.05) {
        pushSuggestion(
          "Test conditions are not repeating cleanly",
          "Run-to-run spread is high enough that noise can hide or mimic real performance changes.",
          "High",
          `Before spread CV: ${formatNumber(before.consistency.avgFpsCv * 100, 1)}%, After spread CV: ${formatNumber(after.consistency.avgFpsCv * 100, 1)}%.`,
          true
        );
      }
      if (comparison.label === "Inconclusive / Low Confidence") {
        pushSuggestion(
          "The evidence is too weak for a safe verdict",
          "The groups overlap heavily or the samples are too noisy, so another capture pass is safer than forcing a conclusion.",
          "High",
          comparison.confidence.reasons.join(", "),
          true
        );
      }
    } else if (analysis.mode === "single" && analysis.singleSample) {
      const metrics = analysis.singleSample.analysis.metrics;
      const reliability = analysis.singleSample.analysis.reliability;
      if (metrics.durationSec < 45 || metrics.frameCount < 8000) {
        pushSuggestion(
          "Capture is too short for strong percentile claims",
          "Short runs can make low-percentile metrics swing too much between attempts.",
          "High",
          `Duration ${formatNumber(metrics.durationSec, 1)}s, frames ${formatShortNumber(metrics.frameCount)}.`,
          true
        );
      }
      if (metrics.avgFps && metrics.p1Low && metrics.p1Low / metrics.avgFps < 0.6) {
        pushSuggestion(
          "Smoothness trails the average",
          "The average FPS is materially higher than the 1% low, which often means the run looks stronger on paper than it feels in play.",
          "Medium",
          `1% low is ${formatNumber((metrics.p1Low / metrics.avgFps) * 100, 1)}% of average FPS.`,
          false
        );
      }
      if (reliability.score < 70) {
        pushSuggestion(
          "Re-capture before trusting this sample",
          "The sample validity score is too weak for it to carry a serious decision on its own.",
          "High",
          reliability.notes.join(" "),
          true
        );
      }
    }

    if (!suggestions.length) {
      pushSuggestion(
        "No specific troubleshooting pattern detected",
        "The data does not currently point to one strong root-cause pattern beyond the verdict itself.",
        "Low",
        "No rule-based pattern cleared the confidence threshold.",
        false
      );
    }
    return suggestions;
  }

  function runSessionAnalysis() {
    state.samples.forEach((sample) => {
      sample.analysis = mergeAnalyses(sample);
    });

    const validSamples = state.samples.filter((sample) => sample.analysis);
    const beforeSamples = validSamples.filter((sample) => sample.role === "before");
    const afterSamples = validSamples.filter((sample) => sample.role === "after");
    const neutralSamples = validSamples.filter((sample) => sample.role === "neutral");
    const before = analyzeGroup("Before", beforeSamples);
    const after = analyzeGroup("After", afterSamples);
    let mode = "single";
    let comparison = null;
    let singleSample = null;
    if (before && after) {
      mode = "comparison";
      comparison = analyzeComparison(before, after);
    } else if (validSamples.length) {
      singleSample = validSamples[0];
      comparison = analyzeSingleSample(singleSample);
    }

    const troubleshooting = buildTroubleshooting({ mode, before, after, comparison, singleSample });
    state.analysis = { mode, before, after, neutralSamples, comparison, singleSample, troubleshooting, validSamples };
  }

  async function analyzeFileObject(fileObject) {
    const text = await fileObject.text();
    const parsed = parseCsv(text);
    const kind = inferFileKind(parsed.headers);
    if (kind === "unknown") {
      return {
        ok: false,
        error: `Unsupported CSV schema in ${fileObject.name}. Required timing columns such as MsBetweenPresents, TimeInSeconds, or summary columns like Average FPS were not found.`
      };
    }
    return { ok: true, kind, parsed };
  }

  async function intakeFiles(files) {
    const messages = [];
    for (const fileObject of files) {
      const analyzed = await analyzeFileObject(fileObject);
      if (!analyzed.ok) {
        messages.push(analyzed.error);
        continue;
      }
      const stem = trimmedStem(fileObject.name);
      let sample = findSampleByStem(stem);
      if (!sample || (analyzed.kind === "raw" && sample.rawAnalysis) || (analyzed.kind === "stats" && sample.statsAnalysis)) {
        sample = createSampleBase(fileObject.name);
        state.samples.push(sample);
      }
      if (analyzed.kind === "raw") {
        sample.rawFileName = fileObject.name;
        sample.rawAnalysis = analyzeRawSample(analyzed.parsed, fileObject);
        sample.name = sample.rawAnalysis.processName || sample.name;
      } else {
        sample.statsFileName = fileObject.name;
        sample.statsAnalysis = analyzeStatsOnlySample(analyzed.parsed, fileObject);
      }
    }

    if (messages.length) {
      setBanner("warn", messages.join(" "));
    } else if (state.samples.length) {
      setBanner("info", "Files loaded successfully. Review group assignment, then run analysis or let the tool refresh automatically.");
    } else {
      setBanner("info", "No usable files were loaded.");
    }

    runSessionAnalysis();
    render();
  }

  function clearAll() {
    state.samples = [];
    state.analysis = null;
    state.replaceTargetId = null;
    setBanner("info", "Session cleared.");
    render();
  }

  function removeSample(sampleId) {
    state.samples = state.samples.filter((sample) => sample.id !== sampleId);
    runSessionAnalysis();
    render();
  }

  function deriveSessionStatus() {
    const sampleCount = state.samples.filter((sample) => sample.rawAnalysis || sample.statsAnalysis).length;
    const statsCount = state.samples.filter((sample) => sample.statsAnalysis).length;
    dom.loadedSampleCount.textContent = String(sampleCount);
    dom.loadedStatsCount.textContent = String(statsCount);
    if (!sampleCount) {
      dom.sessionStateLabel.textContent = "Waiting";
      dom.sessionStateText.textContent = "Load at least one valid PresentMon export to start.";
      return;
    }
    if (!state.analysis || !state.analysis.validSamples.length) {
      dom.sessionStateLabel.textContent = "Validation";
      dom.sessionStateText.textContent = "Files were loaded, but none produced usable analysis data.";
      return;
    }
    if (state.analysis.mode === "comparison") {
      dom.sessionStateLabel.textContent = "Compare";
      dom.sessionStateText.textContent = `${state.analysis.before.samples.length} before sample(s) vs ${state.analysis.after.samples.length} after sample(s).`;
    } else {
      dom.sessionStateLabel.textContent = "Single";
      dom.sessionStateText.textContent = "Single-sample validity analysis is active.";
    }
  }

  /* RENDERING */

  function renderSampleList() {
    if (!state.samples.length) {
      dom.sampleList.innerHTML = `
        <div class="empty-state">
          <div>
            <h3>No samples in the session</h3>
            <p>
              Drop PresentMon raw exports and optional <span class="mono">-stats.csv</span> files into the intake area.
              Every sample appears here with its group assignment, reliability preview, and replacement controls.
            </p>
          </div>
        </div>
      `;
      return;
    }

    dom.sampleList.innerHTML = state.samples.map((sample) => {
      const analysis = sample.analysis || sample.rawAnalysis || sample.statsAnalysis;
      const reliability = analysis?.reliability;
      const issueCount = analysis?.issues?.length || 0;
      const group = datasetMeta(sample.role);
      const badges = [];
      badges.push(`<span class="badge info">${sample.rawAnalysis ? "Raw loaded" : "No raw export"}</span>`);
      badges.push(`<span class="badge ${sample.statsAnalysis ? "good" : "warn"}">${sample.statsAnalysis ? "Stats paired" : "No stats pair"}</span>`);
      if (reliability) {
        badges.push(`<span class="badge ${reliability.className}">${reliability.label} ${reliability.score}/100</span>`);
      }
      if (issueCount) {
        badges.push(`<span class="badge warn">${issueCount} issue${issueCount === 1 ? "" : "s"} noted</span>`);
      }
      return `
        <div class="sample-card sample-card--${group.className}">
          <div class="sample-head">
            <div>
              <h3 class="sample-title">${escapeHtml(sample.name)}</h3>
              <div class="sample-filename">${escapeHtml(sample.rawFileName || sample.statsFileName || sample.stem)}</div>
            </div>
            <div class="dataset-pill dataset-pill--${group.className}">
              <span class="dataset-pill-label">${group.label}</span>
              <span class="dataset-pill-sub">${group.explanation}</span>
            </div>
          </div>
          <div class="sample-form">
            <div class="field">
              <label for="sample-name-${sample.id}">Sample Name</label>
              <input id="sample-name-${sample.id}" type="text" value="${escapeHtml(sample.name)}" data-sample-name="${sample.id}">
            </div>
            <div class="field">
              <label for="sample-role-${sample.id}">Group</label>
              <select id="sample-role-${sample.id}" data-sample-role="${sample.id}">
                <option value="before" ${sample.role === "before" ? "selected" : ""}>Before</option>
                <option value="after" ${sample.role === "after" ? "selected" : ""}>After</option>
                <option value="neutral" ${sample.role === "neutral" ? "selected" : ""}>Neutral</option>
              </select>
            </div>
            <div class="field">
              <label>Files</label>
              <div class="helper-text helper-text-break">${escapeHtml(sample.rawFileName || "No raw export")}<br>${escapeHtml(sample.statsFileName || "No stats companion")}</div>
            </div>
          </div>
          <div class="sample-toolbar">
            <div class="sample-badges">${badges.join("")}</div>
            <div class="sample-actions">
              <button class="mini-btn" type="button" data-replace-sample="${sample.id}">Replace</button>
              <button class="mini-btn" type="button" data-remove-sample="${sample.id}">Remove</button>
            </div>
          </div>
          ${analysis ? `
            <div class="sample-meta-row">
              <span class="badge">${formatNumber(analysis.metrics.durationSec, 1)}s</span>
              <span class="badge">${formatShortNumber(analysis.metrics.frameCount)} frames</span>
              <span class="badge">${formatNumber(analysis.metrics.avgFps, 1)} FPS avg</span>
              <span class="badge">${formatNumber(analysis.metrics.p1Low, 1)} FPS 1% low</span>
            </div>
          ` : ""}
        </div>
      `;
    }).join("");
  }

  function metricCardMarkup(metricKey, currentValue, changeInfo, note) {
    const metric = metricCatalog[metricKey];
    const unit = metric.unit || "";
    const tone = semanticTone(changeInfo);
    const priority = metricPriority(metricKey);
    const beforeValue = changeInfo?.beforeValue;
    const afterValue = changeInfo?.afterValue ?? currentValue;
    const deltaText = changeInfo ? `${tone.arrow} ${formatPercent(changeInfo.pct ?? 0, 1)}` : "Standalone sample";
    const explainText = changeInfo
      ? `${tone.summary}. ${changeInfo.strength > 0.85 ? "Signal is strong." : changeInfo.strength < -0.85 ? "Negative signal is strong." : "Effect is mild or noise-limited."}`
      : "No comparison baseline is loaded.";
    return `
      <div class="metric-card metric-card--${priority} metric-card--${tone.className}">
        <div class="metric-head">
          <div>
            <div class="metric-kicker">${priority === "primary" ? "Primary driver" : "Supporting metric"}</div>
            <div class="metric-label">${escapeHtml(slugMetricName(metricKey))}</div>
          </div>
          <button type="button" class="info-btn"
            data-doc-target="${metricKey}"
            data-tip-beginner="${escapeHtml(metric.beginnerExplanation)}"
            data-tip-technical="${escapeHtml(metric.technicalExplanation)}">i</button>
        </div>
        ${changeInfo ? `
          <div class="metric-compare">
            <div class="metric-lane metric-lane--before">
              <span class="dataset-chip dataset-chip--before">Before</span>
              <strong>${formatNumber(beforeValue, unit === "ms" ? 2 : 1)}</strong>
              <span>${escapeHtml(unit)}</span>
            </div>
            <div class="metric-lane metric-lane--after">
              <span class="dataset-chip dataset-chip--after">After</span>
              <strong>${formatNumber(afterValue, unit === "ms" ? 2 : 1)}</strong>
              <span>${escapeHtml(unit)}</span>
            </div>
          </div>
        ` : `
          <div class="metric-value-stack">
            <div class="metric-value">${formatNumber(currentValue, unit === "ms" ? 2 : 1)}</div>
            <div class="metric-unit-line">${escapeHtml(unit || "Sample value")}</div>
          </div>
        `}
        <div class="metric-change">
          <span class="delta delta--${tone.className}">${escapeHtml(deltaText)}</span>
          <span class="metric-change-label">${escapeHtml(tone.label)}</span>
        </div>
        <div class="metric-note">${escapeHtml(note)}</div>
        <div class="metric-explain">${escapeHtml(explainText)}</div>
      </div>
    `;
  }

  function renderReliabilityCard(sample) {
    const reliability = sample.analysis.reliability;
    return `
      <div class="reliability-card">
        <div class="reliability-head">
          <div>
            <h3 class="reliability-title">${escapeHtml(sample.name)}</h3>
            <div class="helper-text">${escapeHtml(sample.role.toUpperCase())} • ${escapeHtml(sample.analysis.processName || sample.name)}</div>
          </div>
          <div class="score-badge ${reliability.className}">${reliability.score}</div>
        </div>
        <div class="evidence-row">
          <span class="badge ${reliability.className}">${escapeHtml(reliability.label)}</span>
          <span class="badge info">${formatNumber(sample.analysis.metrics.durationSec, 1)} s</span>
          <span class="badge info">${formatShortNumber(sample.analysis.metrics.frameCount)} frames</span>
          <span class="badge info">${formatNumber((reliability.completeness || 0) * 100, 1)}% timing completeness</span>
        </div>
        <ul class="issue-list">
          ${reliability.notes.map((note) => `<li>${escapeHtml(note)}</li>`).join("")}
        </ul>
      </div>
    `;
  }

  function renderComparisonTable(before, after, comparison) {
    const rows = comparison.signals.map((signal) => {
      const metric = metricCatalog[signal.key];
      const tone = semanticTone(signal);
      const interpretation = signal.strength > 0.85
        ? "Signal clears the noise floor with strong support."
        : signal.strength > 0.3
          ? "After trends better, but the effect is moderate."
          : signal.strength < -0.85
            ? "Before remains clearly safer on this metric."
            : signal.strength < -0.3
              ? "After trends worse, but not decisively."
              : "The difference stays inside practical noise.";
      return `
        <div class="comparison-row comparison-row--${tone.className}">
          <div class="comparison-cell comparison-cell--metric">
            <span class="comparison-overline">${metricPriority(signal.key) === "primary" ? "Primary" : "Secondary"}</span>
            <strong>${escapeHtml(state.viewMode === "beginner" ? metric.beginnerName : metric.technicalName)}</strong>
            <span class="tiny">${escapeHtml(signal.higherIsBetter ? "Higher is better" : "Lower is better")}</span>
          </div>
          <div class="comparison-cell identity-cell identity-cell--before">
            <span class="dataset-chip dataset-chip--before">Before</span>
            <strong>${formatNumber(signal.beforeValue, metric.unit === "ms" ? 2 : 1)}</strong>
            <span>${escapeHtml(metric.unit || "value")}</span>
          </div>
          <div class="comparison-cell identity-cell identity-cell--after">
            <span class="dataset-chip dataset-chip--after">After</span>
            <strong>${formatNumber(signal.afterValue, metric.unit === "ms" ? 2 : 1)}</strong>
            <span>${escapeHtml(metric.unit || "value")}</span>
          </div>
          <div class="comparison-cell comparison-cell--delta">
            <span class="delta delta--${tone.className}">${tone.arrow} ${formatPercent(signal.pct || 0, 1)}</span>
            <span class="comparison-delta-text">${escapeHtml(tone.label)}</span>
          </div>
          <div class="comparison-cell comparison-cell--interpretation">
            <strong>${escapeHtml(tone.summary)}</strong>
            <span>${escapeHtml(interpretation)}</span>
          </div>
        </div>
      `;
    }).join("");

    return `
      <section class="section-card">
        <div class="section-title-row">
          <div>
            <div class="section-title">Before vs After Table</div>
            <h2 class="section-heading">Aggregate Metrics, Change Size, and Interpretation</h2>
          </div>
        </div>
        <div class="comparison-table">
          <div class="comparison-table-head">
            <span>Metric</span>
            <span>Before</span>
            <span>After</span>
            <span>Delta</span>
            <span>Interpretation</span>
          </div>
          <div class="comparison-table-body">
            ${rows}
          </div>
        </div>
      </section>
    `;
  }

  function renderStandaloneDetails(singleSample) {
    if (!singleSample) {
      return "";
    }
    const metrics = singleSample.analysis.metrics;
    return `
      <div class="aggregation-grid">
        <div class="aggregation-card">
          <h4>Validity decision</h4>
          <p>
            The sample received a <strong>${escapeHtml(singleSample.analysis.reliability.label)}</strong> rating because
            duration, frame count, timing completeness, pacing variability, and outlier behavior were evaluated together.
          </p>
        </div>
        <div class="aggregation-card">
          <h4>Primary metrics used</h4>
          <p>
            Average FPS ${formatNumber(metrics.avgFps, 1)}, 1% low ${formatNumber(metrics.p1Low, 1)}, 99th percentile frametime
            ${formatNumber(metrics.p99Frametime, 2)} ms, and frametime CV ${formatNumber(metrics.frametimeCv, 3)}.
          </p>
        </div>
      </div>
    `;
  }

  function renderAggregationDetails(before, after) {
    const buildGroupCard = (group) => {
      const sampleRows = group.samples.map((sample, index) => {
        const outlier = group.outliers[index];
        return `
          <tr>
            <td>${escapeHtml(sample.name)}</td>
            <td class="mono">${formatNumber(group.weights[index], 2)}</td>
            <td>${outlier.isOutlier ? "Down-weighted" : "Full weight"}</td>
            <td>${escapeHtml(outlier.reasons.join(", ") || "No strong outlier signal.")}</td>
          </tr>
        `;
      }).join("");

      return `
        <div class="aggregation-card">
          <h4>${escapeHtml(group.name)} group merge</h4>
          <p>
            Group metrics use reliability-weighted means. Duration increases influence modestly, while outlier runs receive a
            penalty instead of disappearing silently.
          </p>
          <div class="evidence-row">
            <span class="badge info">${formatNumber(group.metrics.avgFps, 1)} FPS aggregate</span>
            <span class="badge info">${formatNumber(group.consistency.avgFpsCv * 100, 1)}% avg FPS spread</span>
            <span class="badge info">${formatNumber(group.consistency.p1Cv * 100, 1)}% 1% low spread</span>
            <span class="badge ${group.consistency.reliabilityAvg >= 80 ? "good" : group.consistency.reliabilityAvg >= 65 ? "warn" : "bad"}">${formatNumber(group.consistency.reliabilityAvg, 0)} reliability avg</span>
          </div>
          <div class="table-wrap" style="margin-top:12px;">
            <table>
              <thead>
                <tr>
                  <th>Sample</th>
                  <th>Merge Weight</th>
                  <th>Outlier Handling</th>
                  <th>Reason</th>
                </tr>
              </thead>
              <tbody>${sampleRows}</tbody>
            </table>
          </div>
        </div>
      `;
    };

    return `
      <div class="aggregation-grid">
        ${buildGroupCard(before)}
        ${buildGroupCard(after)}
      </div>
      <div class="footer-note">
        Means are used for aggregate averages and dispersion metrics. Weighted medians are also tracked internally to keep
        one noisy sample from silently dominating interpretation.
      </div>
    `;
  }

  function renderSampleTable(samples, before, after) {
    const rows = samples.map((sample) => {
      const metrics = sample.analysis.metrics;
      const group = datasetMeta(sample.role);
      let notes = sample.analysis.reliability.notes.slice(0, 2).join(" ");
      if (sample.role === "before" && before) {
        const index = before.samples.findIndex((entry) => entry.id === sample.id);
        if (index >= 0 && before.outliers[index].isOutlier) {
          notes += ` Group note: ${before.outliers[index].reasons.join(", ")}.`;
        }
      }
      if (sample.role === "after" && after) {
        const index = after.samples.findIndex((entry) => entry.id === sample.id);
        if (index >= 0 && after.outliers[index].isOutlier) {
          notes += ` Group note: ${after.outliers[index].reasons.join(", ")}.`;
        }
      }
      return `
        <div class="sample-breakdown-row sample-breakdown-row--${group.className}">
          <div class="sample-breakdown-main">
            <div class="dataset-pill dataset-pill--${group.className}">
              <span class="dataset-pill-label">${group.label}</span>
              <span class="dataset-pill-sub">${group.explanation}</span>
            </div>
            <div>
              <h3>${escapeHtml(sample.name)}</h3>
              <p>${escapeHtml(notes)}</p>
            </div>
          </div>
          <div class="sample-stat-grid">
            <div class="sample-stat-card"><span>Duration</span><strong>${formatNumber(metrics.durationSec, 1)} s</strong></div>
            <div class="sample-stat-card"><span>Frames</span><strong>${formatShortNumber(metrics.frameCount)}</strong></div>
            <div class="sample-stat-card"><span>Avg FPS</span><strong>${formatNumber(metrics.avgFps, 1)}</strong></div>
            <div class="sample-stat-card"><span>1% Low</span><strong>${formatNumber(metrics.p1Low, 1)}</strong></div>
            <div class="sample-stat-card"><span>Avg FT</span><strong>${formatNumber(metrics.avgFrametime, 2)} ms</strong></div>
            <div class="sample-stat-card"><span>Reliability</span><strong class="sample-reliability-text sample-reliability-text--${sample.analysis.reliability.className}">${escapeHtml(sample.analysis.reliability.label)}</strong></div>
          </div>
        </div>
      `;
    }).join("");

    return `
      <div class="sample-breakdown-table">
        ${rows}
      </div>
    `;
  }

  function renderDocumentation() {
    docSections.metrics.body = Object.entries(metricCatalog).map(([key, metric]) => `
      <div class="doc-card" id="doc-${key}">
        <h4>${escapeHtml(metric.technicalName)}</h4>
        <p><strong>Beginner label:</strong> ${escapeHtml(metric.beginnerName)}</p>
        <p>${escapeHtml(metric.beginnerExplanation)}</p>
        <p>${escapeHtml(metric.technicalExplanation)}</p>
      </div>
    `).join("");

    const nav = Object.entries(docSections).map(([key, section]) => `
      <button type="button" class="${state.docSection === key ? "active" : ""}" data-doc-section="${key}">
        <span class="doc-nav-title">${escapeHtml(section.title)}</span>
        <span class="doc-nav-copy tiny">${escapeHtml(key === "metrics" ? "Metric-by-metric reference." : "Open this section in the help panel.")}</span>
      </button>
    `).join("");

    return `
      <div class="doc-layout">
        <aside class="doc-nav" aria-label="Documentation sections">${nav}</aside>
        <div class="doc-body" role="region" aria-live="polite">${docSections[state.docSection].body}</div>
      </div>
    `;
  }

  function renderChartSection(mode, before, after, singleSample) {
    const chartCards = [
      `
        <div class="chart-card">
          <h3 class="chart-title">FPS Distribution</h3>
          <p class="chart-sub">Frame-level FPS distribution by group or sample. Hover bars for beginner or technical tooltips.</p>
          <div class="chart-host" id="chart-fps-distribution"></div>
        </div>
      `,
      `
        <div class="chart-card">
          <h3 class="chart-title">Frametime Distribution</h3>
          <p class="chart-sub">Tail heaviness and pacing spread are more visible here than in average FPS alone.</p>
          <div class="chart-host" id="chart-frametime-distribution"></div>
        </div>
      `
    ];

    if (mode === "comparison" && before && after) {
      chartCards.push(
        `
          <div class="chart-card">
            <h3 class="chart-title">Before vs After Metric Delta</h3>
            <p class="chart-sub">Directed percent change across the main verdict metrics.</p>
            <div class="chart-host" id="chart-comparison-bars"></div>
          </div>
        `,
        `
          <div class="chart-card">
            <h3 class="chart-title">Sample Consistency Plot</h3>
            <p class="chart-sub">Each point shows one run. Large spread means the scenario is noisy.</p>
            <div class="chart-host" id="chart-consistency"></div>
          </div>
        `,
        `
          <div class="chart-card">
            <h3 class="chart-title">Group Spread Visualization</h3>
            <p class="chart-sub">Min, median, and max sample averages help show overlap between groups.</p>
            <div class="chart-host" id="chart-spread"></div>
          </div>
        `
      );
    } else if (singleSample) {
      chartCards.push(`
        <div class="chart-card">
          <h3 class="chart-title">Percentile Snapshot</h3>
          <p class="chart-sub">A compact view of the average, 1% low, 0.1% low, and tail frametimes.</p>
          <div class="chart-host" id="chart-percentiles"></div>
        </div>
      `);
    }

    return `
      <section class="section-card">
        <div class="section-title-row">
          <div>
            <div class="section-title">Charts</div>
            <h2 class="section-heading">Professional Visuals, Not Dashboard Filler</h2>
          </div>
        </div>
        <div class="split-grid">${chartCards.join("")}</div>
      </section>
    `;
  }

  function renderResults() {
    if (!state.analysis || !state.analysis.validSamples.length) {
      dom.resultsHost.innerHTML = `
        <section class="panel">
          <div class="empty-state">
            <div>
              <h3>Analysis output will appear here</h3>
              <p>
                Once at least one valid sample is loaded, the tool will render the verdict panel, key metrics,
                reliability analysis, merge details, charts, troubleshooting suggestions, and embedded documentation.
              </p>
            </div>
          </div>
        </section>
      `;
      return;
    }

    const { mode, comparison, before, after, neutralSamples, singleSample, troubleshooting, validSamples } = state.analysis;
    const executive = comparison;
    const processName = mode === "comparison"
      ? before?.samples[0]?.analysis?.processName || after?.samples[0]?.analysis?.processName || "Mixed session"
      : singleSample?.analysis?.processName || validSamples[0]?.analysis?.processName || "Standalone sample";
    const validityCounts = validSamples.reduce((acc, sample) => {
      const label = sample.analysis.reliability.label;
      acc[label] = (acc[label] || 0) + 1;
      return acc;
    }, {});

    const summaryPills = [
      { label: "Process", value: processName, sub: "Derived from the raw export where available." },
      { label: "Loaded Samples", value: String(validSamples.length), sub: `${before?.samples.length || 0} before, ${after?.samples.length || 0} after, ${neutralSamples.length} neutral.` },
      { label: "Mode", value: mode === "comparison" ? "Before vs After" : "Single Sample", sub: mode === "comparison" ? "Group aggregation is active." : "Reliability-first standalone readout." },
      { label: "Validity Mix", value: Object.entries(validityCounts).map(([key, value]) => `${value} ${key}`).join(" / "), sub: "Duration, frame count, variance, and completeness all contribute." },
      { label: "Analysis Status", value: executive.label, sub: executive.confidence ? `${executive.confidence.label}, score ${executive.confidence.score}/100.` : "" }
    ];

    let metricCards = "";
    if (mode === "comparison" && before && after && comparison) {
      const signalMap = Object.fromEntries(comparison.signals.map((signal) => [signal.key, signal]));
      metricCards = [
        ["avgFps", after.metrics.avgFps, signalMap.avgFps, "Weighted group result with run-to-run spread considered."],
        ["p1Low", after.metrics.p1Low, signalMap.p1Low, "Low-percentile behavior is treated as first-class evidence."],
        ["p01Low", after.metrics.p01Low, signalMap.p01Low, "Extreme tail metric. Interpreted cautiously on small captures."],
        ["avgFrametime", after.metrics.avgFrametime, signalMap.avgFrametime, "Lower is better. Improvement means less time per frame."],
        ["frametimeCv", after.metrics.frametimeCv, signalMap.frametimeCv, "Normalized stability indicator. Lower means smoother pacing."]
      ].map(([metricKey, value, signal, note]) => metricCardMarkup(metricKey, value, signal, note)).join("");
    } else if (singleSample) {
      metricCards = [
        ["avgFps", singleSample.analysis.metrics.avgFps, null, "Overall throughput for this sample."],
        ["p1Low", singleSample.analysis.metrics.p1Low, null, "Worst meaningful portion of the sample."],
        ["p01Low", singleSample.analysis.metrics.p01Low, null, "Extreme tail. Needs enough frames to be trustworthy."],
        ["avgFrametime", singleSample.analysis.metrics.avgFrametime, null, "Average time per frame."],
        ["frametimeCv", singleSample.analysis.metrics.frametimeCv, null, "Frame pacing stability across the capture."]
      ].map(([metricKey, value, signal, note]) => metricCardMarkup(metricKey, value, signal, note)).join("");
    }

    const reliabilityMarkup = validSamples.map((sample) => renderReliabilityCard(sample)).join("");
    const sampleTable = renderSampleTable(validSamples, before, after);
    const metricTable = mode === "comparison" && before && after && comparison ? renderComparisonTable(before, after, comparison) : "";
    const aggregationMarkup = mode === "comparison" && before && after ? renderAggregationDetails(before, after) : renderStandaloneDetails(singleSample);
    const chartMarkup = renderChartSection(mode, before, after, singleSample);
    const troubleshootingMarkup = troubleshooting.map((suggestion) => `
      <div class="suggestion-card">
        <div class="section-title">${escapeHtml(suggestion.confidence)} likelihood</div>
        <h3 class="chart-title">${escapeHtml(suggestion.title)}</h3>
        <p class="chart-sub">${escapeHtml(suggestion.explanation)}</p>
        <div class="evidence-row">
          <span class="badge info">${escapeHtml(suggestion.evidence)}</span>
          <span class="badge ${suggestion.retestFirst ? "warn" : "good"}">${suggestion.retestFirst ? "Re-test first" : "No immediate re-test required"}</span>
        </div>
      </div>
    `).join("");

    dom.resultsHost.innerHTML = `
      <section class="section-card">
        <div class="summary-bar">
          ${summaryPills.map((item) => `
            <div class="summary-pill">
              <div class="summary-pill-label">${escapeHtml(item.label)}</div>
              <div class="summary-pill-value">${escapeHtml(item.value)}</div>
              <div class="summary-pill-sub">${escapeHtml(item.sub)}</div>
            </div>
          `).join("")}
        </div>
        ${mode === "comparison" ? `
          <div class="comparison-legend-strip">
            <div class="comparison-legend-card comparison-legend-card--before">
              <span class="dataset-chip dataset-chip--before">Before</span>
              <strong>Baseline state</strong>
              <span>All baseline cards, cells, and chart series use the blue identity.</span>
            </div>
            <div class="comparison-legend-card comparison-legend-card--after">
              <span class="dataset-chip dataset-chip--after">After</span>
              <strong>Changed state</strong>
              <span>All changed-state cards, cells, and chart series use the teal identity.</span>
            </div>
            <div class="comparison-legend-card comparison-legend-card--semantic">
              <span class="delta delta--positive">▲ Better</span>
              <span class="delta delta--negative">▼ Worse</span>
              <span class="delta delta--neutral">• Neutral</span>
            </div>
          </div>
        ` : ""}
      </section>

      <section class="section-card">
        <div class="section-title-row">
          <div>
            <div class="section-title">Executive Verdict</div>
            <h2 class="section-heading">${escapeHtml(executive.label)}</h2>
            <p class="section-sub">
              ${escapeHtml(mode === "comparison"
                ? "The verdict is driven by weighted performance metrics, sample quality, run consistency, and metric conflicts."
                : "This verdict evaluates whether the sample itself is strong enough to trust as evidence.")}
            </p>
          </div>
        </div>
        <div class="verdict-panel">
          <div class="verdict-hero">
            <div class="verdict-kicker">${mode === "comparison" ? "Before aggregate vs After aggregate" : "Standalone capture validity"}</div>
            <h3 class="verdict-title">${escapeHtml(executive.label)}</h3>
            <div class="verdict-subtitle">${escapeHtml(executive.recommendedAction)}</div>
            <div class="confidence-strip">
              <span class="confidence-score">${escapeHtml(executive.confidence.label)}</span>
              <span>${escapeHtml(`${executive.confidence.score}/100`)}</span>
            </div>
          </div>
          <div class="verdict-grid">
            <div class="verdict-box">
              <h4>Top Supporting Reasons</h4>
              <ul>${executive.reasons.map((reason) => `<li>${escapeHtml(reason)}</li>`).join("")}</ul>
            </div>
            <div class="verdict-box">
              <h4>Confidence Drivers</h4>
              <ul>${(executive.confidence.reasons || []).map((reason) => `<li>${escapeHtml(reason)}</li>`).join("")}</ul>
            </div>
            <div class="verdict-box">
              <h4>Recommended Action</h4>
              <ul><li>${escapeHtml(executive.recommendedAction)}</li></ul>
            </div>
            <div class="verdict-box">
              <h4>Analysis Scope</h4>
              <ul><li>${escapeHtml(mode === "comparison" ? "Aggregated groups use reliability-weighted merging and outlier penalties." : "Single-sample mode focuses on validity, pacing quality, and capture sufficiency.")}</li></ul>
            </div>
          </div>
        </div>
      </section>

      <section class="section-card">
        <div class="section-title-row">
          <div>
            <div class="section-title">Key Metrics</div>
            <h2 class="section-heading">Fast Readout for the Main Performance Drivers</h2>
          </div>
        </div>
        <div class="metric-grid">${metricCards}</div>
      </section>

      ${metricTable}

      <section class="section-card">
        <div class="section-title-row">
          <div>
            <div class="section-title">Reliability</div>
            <h2 class="section-heading">Sample Validity and Capture Quality</h2>
          </div>
        </div>
        <div class="sample-evidence-list">${reliabilityMarkup}</div>
      </section>

      <section class="section-card">
        <div class="section-title-row">
          <div>
            <div class="section-title">Merge Logic</div>
            <h2 class="section-heading">${mode === "comparison" ? "How Group Aggregates Were Built" : "How This Sample Was Interpreted"}</h2>
          </div>
        </div>
        ${aggregationMarkup}
      </section>

      <section class="section-card">
        <div class="section-title-row">
          <div>
            <div class="section-title">Per-Sample Breakdown</div>
            <h2 class="section-heading">Every Loaded Sample Stays Visible</h2>
          </div>
        </div>
        ${sampleTable}
      </section>

      ${chartMarkup}

      <section class="section-card">
        <div class="section-title-row">
          <div>
            <div class="section-title">Troubleshooting</div>
            <h2 class="section-heading">Pattern-Based Suggestions</h2>
            <p class="section-sub">Suggestions appear only when the loaded data supports a real pattern.</p>
          </div>
        </div>
        <div class="suggestion-list">${troubleshootingMarkup}</div>
      </section>

      <section class="section-card docs-section">
        <div class="section-title-row">
          <div>
            <div class="section-title">Explain Mode</div>
            <h2 class="section-heading">Built-In Documentation and Interpretation Guide</h2>
          </div>
        </div>
        ${renderDocumentation()}
      </section>
    `;

    attachDocButtons();
    renderCharts();
  }

  function attachDocButtons() {
    document.querySelectorAll("[data-doc-target]").forEach((button) => {
      button.addEventListener("click", () => {
        state.docSection = "metrics";
        renderResults();
        const target = document.getElementById(`doc-${button.getAttribute("data-doc-target")}`);
        target?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });

    document.querySelectorAll("[data-doc-section]").forEach((button) => {
      button.addEventListener("click", () => {
        state.docSection = button.getAttribute("data-doc-section");
        renderResults();
      });
    });

    bindTooltipTargets();
  }

  function bindTooltipTargets() {
    document.querySelectorAll("[data-tip-beginner]").forEach((element) => {
      element.addEventListener("mouseenter", (event) => showTooltip(event.currentTarget));
      element.addEventListener("mousemove", (event) => moveTooltip(event));
      element.addEventListener("mouseleave", hideTooltip);
    });
  }

  function showTooltip(element) {
    const content = state.viewMode === "beginner"
      ? element.getAttribute("data-tip-beginner")
      : element.getAttribute("data-tip-technical");
    if (!content) {
      return;
    }
    dom.tooltip.innerHTML = content;
    dom.tooltip.classList.add("visible");
  }

  function moveTooltip(event) {
    dom.tooltip.style.left = `${event.clientX + 14}px`;
    dom.tooltip.style.top = `${event.clientY + 14}px`;
  }

  function hideTooltip() {
    dom.tooltip.classList.remove("visible");
  }

  function renderCharts() {
    if (!state.analysis) {
      return;
    }

    const { mode, before, after, singleSample, comparison } = state.analysis;
    renderDistributionChart(
      document.getElementById("chart-fps-distribution"),
      mode === "comparison"
        ? [
            { label: "Before", values: before.frameTimes.map((value) => 1000 / value), color: "#3da2ff" },
            { label: "After", values: after.frameTimes.map((value) => 1000 / value), color: "#4fd1c5" }
          ]
        : [{ label: singleSample.name, values: singleSample.analysis.fpsSeries, color: "#3da2ff" }],
      "FPS"
    );

    renderDistributionChart(
      document.getElementById("chart-frametime-distribution"),
      mode === "comparison"
        ? [
            { label: "Before", values: before.frameTimes, color: "#3da2ff" },
            { label: "After", values: after.frameTimes, color: "#4fd1c5" }
          ]
        : [{ label: singleSample.name, values: singleSample.analysis.frameTimes, color: "#3da2ff" }],
      "ms"
    );

    if (mode === "comparison" && before && after && comparison) {
      renderComparisonBarChart(document.getElementById("chart-comparison-bars"), comparison.signals);
      renderConsistencyChart(document.getElementById("chart-consistency"), before, after);
      renderSpreadChart(document.getElementById("chart-spread"), before, after);
    } else if (singleSample) {
      renderSinglePercentileChart(document.getElementById("chart-percentiles"), singleSample.analysis.metrics);
    }
  }

  function renderDistributionChart(host, seriesList, unit) {
    if (!host) {
      return;
    }
    const width = 760;
    const height = 250;
    const padding = { top: 18, right: 20, bottom: 30, left: 44 };
    const allValues = seriesList.flatMap((series) => series.values.filter(Number.isFinite));
    if (!allValues.length) {
      host.innerHTML = `<div class="empty-state"><p>No chart data available.</p></div>`;
      return;
    }

    const capMax = percentile(allValues, 0.995) || Math.max(...allValues);
    const filteredSeries = seriesList.map((series) => ({
      ...series,
      bins: createHistogram(series.values.filter((value) => Number.isFinite(value) && value <= capMax), 28)
    }));
    const maxCount = Math.max(...filteredSeries.flatMap((series) => series.bins.map((bin) => bin.count)));
    const minX = Math.min(...filteredSeries.map((series) => series.bins[0]?.x0 ?? 0));
    const maxX = Math.max(...filteredSeries.map((series) => series.bins.at(-1)?.x1 ?? 0));
    const innerWidth = width - padding.left - padding.right;
    const innerHeight = height - padding.top - padding.bottom;
    const xScale = (value) => padding.left + ((value - minX) / (maxX - minX || 1)) * innerWidth;
    const yScale = (value) => padding.top + innerHeight - (value / (maxCount || 1)) * innerHeight;

    const gridLines = Array.from({ length: 4 }, (_, index) => {
      const y = padding.top + (innerHeight / 3) * index;
      return `<line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="rgba(255,255,255,0.08)" stroke-width="1" />`;
    }).join("");

    const seriesMarkup = filteredSeries.map((series) => {
      return series.bins.map((bin) => {
        const x = xScale(bin.x0);
        const x1 = xScale(bin.x1);
        const y = yScale(bin.count);
        const barWidth = Math.max(1.8, x1 - x - 1.6);
        const tipBeginner = `${series.label}: ${bin.count} frames between ${formatNumber(bin.x0, 1)} and ${formatNumber(bin.x1, 1)} ${unit}.`;
        const tipTechnical = `${series.label}: histogram bin ${formatNumber(bin.x0, 2)}-${formatNumber(bin.x1, 2)} ${unit}, count ${bin.count}.`;
        return `
          <rect
            x="${x + 0.8}"
            y="${y}"
            width="${barWidth}"
            height="${padding.top + innerHeight - y}"
            fill="${series.color}"
            fill-opacity="0.35"
            stroke="${series.color}"
            stroke-opacity="0.75"
            data-tip-beginner="${escapeHtml(tipBeginner)}"
            data-tip-technical="${escapeHtml(tipTechnical)}"
          />
        `;
      }).join("");
    }).join("");

    const xTicks = Array.from({ length: 5 }, (_, index) => {
      const value = minX + ((maxX - minX) / 4) * index;
      const x = xScale(value);
      return `<text x="${x}" y="${height - 10}" fill="rgba(231,238,245,0.75)" font-size="11" text-anchor="middle">${formatNumber(value, unit === "ms" ? 2 : 0)}</text>`;
    }).join("");

    host.innerHTML = `
      ${baseSvg(width, height)}
        ${gridLines}
        <line x1="${padding.left}" y1="${padding.top + innerHeight}" x2="${width - padding.right}" y2="${padding.top + innerHeight}" stroke="rgba(255,255,255,0.15)" />
        ${seriesMarkup}
        ${xTicks}
      </svg>
      <div class="chart-legend">
        ${seriesList.map((series) => `<span class="legend-item"><span class="legend-swatch" style="background:${series.color};"></span>${escapeHtml(series.label)}</span>`).join("")}
      </div>
    `;
  }

  function renderComparisonBarChart(host, signals) {
    if (!host) {
      return;
    }
    const width = 760;
    const height = 260;
    const padding = { top: 18, right: 20, bottom: 24, left: 170 };
    const innerWidth = width - padding.left - padding.right;
    const rowHeight = 36;
    const zeroX = padding.left + innerWidth / 2;
    const maxAbs = Math.max(10, ...signals.map((signal) => Math.abs(signal.pct || 0)));

    const rows = signals.map((signal, index) => {
      const y = padding.top + index * rowHeight;
      const widthAbs = (Math.abs(signal.pct || 0) / maxAbs) * (innerWidth / 2 - 12);
      const positive = (signal.pct || 0) >= 0;
      const x = positive ? zeroX : zeroX - widthAbs;
      const color = signal.strength >= 0 ? "#4fd1c5" : "#ff7b7b";
      const tipBeginner = `${slugMetricName(signal.key)} changed ${formatPercent(signal.pct || 0, 1)} in favor of ${signal.strength >= 0 ? "After" : "Before"}.`;
      const tipTechnical = `${signal.key}: directed percent delta ${formatPercent(signal.pct || 0, 1)}, normalized strength ${formatNumber(signal.strength, 2)}.`;
      return `
        <text x="${padding.left - 12}" y="${y + 18}" fill="rgba(231,238,245,0.82)" font-size="12" text-anchor="end">${escapeHtml(slugMetricName(signal.key))}</text>
        <rect x="${x}" y="${y + 6}" width="${widthAbs}" height="16" rx="8"
          fill="${color}" fill-opacity="0.68" stroke="${color}"
          data-tip-beginner="${escapeHtml(tipBeginner)}"
          data-tip-technical="${escapeHtml(tipTechnical)}"></rect>
        <text x="${positive ? x + widthAbs + 8 : x - 8}" y="${y + 18}" fill="rgba(231,238,245,0.82)" font-size="12"
          text-anchor="${positive ? "start" : "end"}">${formatPercent(signal.pct || 0, 1)}</text>
      `;
    }).join("");

    host.innerHTML = `
      ${baseSvg(width, height)}
        <line x1="${zeroX}" y1="${padding.top - 4}" x2="${zeroX}" y2="${height - padding.bottom}" stroke="rgba(255,255,255,0.16)" stroke-dasharray="4 5" />
        <text x="${zeroX - 60}" y="${height - 6}" fill="rgba(255,255,255,0.5)" font-size="11" text-anchor="middle">Better for Before</text>
        <text x="${zeroX + 60}" y="${height - 6}" fill="rgba(255,255,255,0.5)" font-size="11" text-anchor="middle">Better for After</text>
        ${rows}
      </svg>
    `;
  }

  function renderConsistencyChart(host, before, after) {
    if (!host) {
      return;
    }
    const width = 760;
    const height = 250;
    const padding = { top: 20, right: 26, bottom: 30, left: 44 };
    const allSamples = [...before.samples.map((sample) => ({ group: "Before", sample, color: "#3da2ff" })), ...after.samples.map((sample) => ({ group: "After", sample, color: "#4fd1c5" }))];
    const maxAvg = Math.max(...allSamples.map((entry) => entry.sample.analysis.metrics.avgFps || 0));
    const maxX = allSamples.length + 1;
    const innerWidth = width - padding.left - padding.right;
    const innerHeight = height - padding.top - padding.bottom;
    const xScale = (index) => padding.left + (index / maxX) * innerWidth;
    const yScale = (value) => padding.top + innerHeight - (value / (maxAvg || 1)) * innerHeight;

    const points = allSamples.map((entry, index) => {
      const x = xScale(index + 1);
      const avgY = yScale(entry.sample.analysis.metrics.avgFps || 0);
      const lowY = yScale(entry.sample.analysis.metrics.p1Low || entry.sample.analysis.metrics.avgFps || 0);
      const tipBeginner = `${entry.group} sample ${entry.sample.name}: avg ${formatNumber(entry.sample.analysis.metrics.avgFps, 1)} FPS, 1% low ${formatNumber(entry.sample.analysis.metrics.p1Low, 1)} FPS.`;
      const tipTechnical = `${entry.group} ${entry.sample.name}: avg FPS ${formatNumber(entry.sample.analysis.metrics.avgFps, 2)}, 1% low ${formatNumber(entry.sample.analysis.metrics.p1Low, 2)}, reliability ${entry.sample.analysis.reliability.score}.`;
      return `
        <line x1="${x}" y1="${avgY}" x2="${x}" y2="${lowY}" stroke="${entry.color}" stroke-width="2" stroke-opacity="0.75"></line>
        <circle cx="${x}" cy="${avgY}" r="6" fill="${entry.color}" data-tip-beginner="${escapeHtml(tipBeginner)}" data-tip-technical="${escapeHtml(tipTechnical)}"></circle>
        <circle cx="${x}" cy="${lowY}" r="4" fill="${entry.color}" fill-opacity="0.45"></circle>
        <text x="${x}" y="${height - 10}" fill="rgba(255,255,255,0.68)" font-size="11" text-anchor="middle">${index + 1}</text>
      `;
    }).join("");

    host.innerHTML = `
      ${baseSvg(width, height)}
        <line x1="${padding.left}" y1="${height - padding.bottom}" x2="${width - padding.right}" y2="${height - padding.bottom}" stroke="rgba(255,255,255,0.14)" />
        <line x1="${padding.left}" y1="${padding.top}" x2="${padding.left}" y2="${height - padding.bottom}" stroke="rgba(255,255,255,0.14)" />
        ${points}
      </svg>
      <div class="chart-legend">
        <span class="legend-item"><span class="legend-swatch" style="background:#3da2ff;"></span>Before samples</span>
        <span class="legend-item"><span class="legend-swatch" style="background:#4fd1c5;"></span>After samples</span>
        <span class="legend-item">Vertical line = gap between average FPS and 1% low.</span>
      </div>
    `;
  }

  function renderSpreadChart(host, before, after) {
    if (!host) {
      return;
    }
    const width = 760;
    const height = 220;
    const padding = { top: 28, right: 24, bottom: 28, left: 70 };
    const groups = [before, after];
    const values = groups.flatMap((group) => group.samples.map((sample) => sample.analysis.metrics.avgFps || 0));
    const min = Math.min(...values);
    const max = Math.max(...values);
    const innerWidth = width - padding.left - padding.right;
    const xScale = (value) => padding.left + ((value - min) / (max - min || 1)) * innerWidth;

    const groupMarkup = groups.map((group, index) => {
      const y = padding.top + index * 70;
      const values = group.samples.map((sample) => sample.analysis.metrics.avgFps || 0).sort((a, b) => a - b);
      const boxStart = xScale(percentile(values, 0.25) || values[0]);
      const boxEnd = xScale(percentile(values, 0.75) || values[values.length - 1]);
      const med = xScale(median(values) || values[0]);
      const minX = xScale(values[0]);
      const maxX = xScale(values[values.length - 1]);
      const color = index === 0 ? "#3da2ff" : "#4fd1c5";
      const tipBeginner = `${group.name}: min ${formatNumber(values[0], 1)}, median ${formatNumber(median(values), 1)}, max ${formatNumber(values[values.length - 1], 1)} FPS.`;
      const tipTechnical = `${group.name}: Q1 ${formatNumber(percentile(values, 0.25), 1)}, median ${formatNumber(median(values), 1)}, Q3 ${formatNumber(percentile(values, 0.75), 1)} FPS.`;
      return `
        <text x="${padding.left - 14}" y="${y + 18}" fill="rgba(255,255,255,0.82)" font-size="13" text-anchor="end">${group.name}</text>
        <line x1="${minX}" y1="${y + 14}" x2="${maxX}" y2="${y + 14}" stroke="${color}" stroke-width="3" stroke-opacity="0.6"></line>
        <rect x="${boxStart}" y="${y}" width="${Math.max(2, boxEnd - boxStart)}" height="28" rx="12" fill="${color}" fill-opacity="0.22" stroke="${color}"
          data-tip-beginner="${escapeHtml(tipBeginner)}" data-tip-technical="${escapeHtml(tipTechnical)}"></rect>
        <line x1="${med}" y1="${y}" x2="${med}" y2="${y + 28}" stroke="${color}" stroke-width="3"></line>
      `;
    }).join("");

    host.innerHTML = `${baseSvg(width, height)}${groupMarkup}</svg>`;
  }

  function renderSinglePercentileChart(host, metrics) {
    if (!host) {
      return;
    }
    const entries = [
      { label: "Avg FPS", value: metrics.avgFps, color: "#3da2ff" },
      { label: "1% Low", value: metrics.p1Low, color: "#4fd1c5" },
      { label: "0.1% Low", value: metrics.p01Low || 0, color: "#f6c56f" },
      { label: "P95 FT", value: metrics.p95Frametime, color: "#ff7b7b" },
      { label: "P99 FT", value: metrics.p99Frametime, color: "#ff9a5c" }
    ].filter((entry) => Number.isFinite(entry.value));
    const width = 760;
    const height = 250;
    const padding = { top: 18, right: 20, bottom: 40, left: 50 };
    const maxValue = Math.max(...entries.map((entry) => entry.value));
    const innerWidth = width - padding.left - padding.right;
    const innerHeight = height - padding.top - padding.bottom;

    const bars = entries.map((entry, index) => {
      const barWidth = innerWidth / entries.length - 26;
      const x = padding.left + index * (innerWidth / entries.length) + 12;
      const barHeight = (entry.value / (maxValue || 1)) * innerHeight;
      const y = padding.top + innerHeight - barHeight;
      const tipBeginner = `${entry.label}: ${formatNumber(entry.value, entry.label.includes("FT") ? 2 : 1)} ${entry.label.includes("FT") ? "ms" : "FPS"}.`;
      const tipTechnical = `${entry.label}: ${formatNumber(entry.value, entry.label.includes("FT") ? 2 : 1)} ${entry.label.includes("FT") ? "milliseconds" : "frames per second"}.`;
      return `
        <rect x="${x}" y="${y}" width="${barWidth}" height="${barHeight}" rx="12" fill="${entry.color}" fill-opacity="0.72"
          data-tip-beginner="${escapeHtml(tipBeginner)}" data-tip-technical="${escapeHtml(tipTechnical)}"></rect>
        <text x="${x + barWidth / 2}" y="${height - 14}" fill="rgba(255,255,255,0.75)" font-size="11" text-anchor="middle">${entry.label}</text>
        <text x="${x + barWidth / 2}" y="${y - 8}" fill="rgba(255,255,255,0.85)" font-size="11" text-anchor="middle">${formatNumber(entry.value, entry.label.includes("FT") ? 2 : 1)}</text>
      `;
    }).join("");

    host.innerHTML = `${baseSvg(width, height)}${bars}</svg>`;
  }

  function render() {
    deriveSessionStatus();
    renderSampleList();
    renderResults();
    bindSampleControls();
  }

  function bindSampleControls() {
    document.querySelectorAll("[data-sample-name]").forEach((input) => {
      input.addEventListener("input", (event) => {
        const sample = state.samples.find((entry) => entry.id === Number(event.target.getAttribute("data-sample-name")));
        if (sample) {
          sample.name = event.target.value;
          runSessionAnalysis();
          renderResults();
        }
      });
    });

    document.querySelectorAll("[data-sample-role]").forEach((select) => {
      select.addEventListener("change", (event) => {
        const sample = state.samples.find((entry) => entry.id === Number(event.target.getAttribute("data-sample-role")));
        if (sample) {
          sample.role = event.target.value;
          runSessionAnalysis();
          render();
        }
      });
    });

    document.querySelectorAll("[data-remove-sample]").forEach((button) => {
      button.addEventListener("click", () => removeSample(Number(button.getAttribute("data-remove-sample"))));
    });

    document.querySelectorAll("[data-replace-sample]").forEach((button) => {
      button.addEventListener("click", () => {
        state.replaceTargetId = Number(button.getAttribute("data-replace-sample"));
        dom.replaceInput.click();
      });
    });
  }

  /* EVENTS */

  async function applyReplaceFile(fileObject) {
    const sample = state.samples.find((entry) => entry.id === state.replaceTargetId);
    if (!sample) {
      return;
    }
    state.samples = state.samples.filter((entry) => entry.id !== sample.id);
    state.nextId = Math.max(state.nextId, sample.id + 1);
    const replacement = createSampleBase(fileObject.name);
    replacement.role = sample.role;
    replacement.name = sample.name;
    replacement.id = sample.id;
    replacement.stem = trimmedStem(fileObject.name);
    state.samples.push(replacement);
    state.samples.sort((a, b) => a.id - b.id);
    await intakeFiles([fileObject]);
  }

  function loadProvidedExample() {
    setBanner("info", `Use Choose Files to load the provided Downloads files: ${providedExampleFiles.join(" and ")}.`);
  }

  function bindGlobalEvents() {
    dom.fileInput.addEventListener("change", async (event) => {
      const files = Array.from(event.target.files || []);
      if (files.length) {
        await intakeFiles(files);
        dom.fileInput.value = "";
      }
    });

    dom.replaceInput.addEventListener("change", async (event) => {
      const file = event.target.files?.[0];
      if (file) {
        await applyReplaceFile(file);
        dom.replaceInput.value = "";
      }
    });

    dom.uploadZone.addEventListener("dragover", (event) => {
      event.preventDefault();
      dom.uploadZone.classList.add("dragging");
    });

    dom.uploadZone.addEventListener("dragleave", () => {
      dom.uploadZone.classList.remove("dragging");
    });

    dom.uploadZone.addEventListener("drop", async (event) => {
      event.preventDefault();
      dom.uploadZone.classList.remove("dragging");
      const files = Array.from(event.dataTransfer?.files || []).filter((file) => file.name.toLowerCase().endsWith(".csv"));
      if (files.length) {
        await intakeFiles(files);
      }
    });

    dom.runAnalysisBtn.addEventListener("click", () => {
      runSessionAnalysis();
      render();
      setBanner("info", "Analysis refreshed.");
    });

    dom.clearAllBtn.addEventListener("click", clearAll);
    dom.loadProvidedExampleBtn.addEventListener("click", loadProvidedExample);

    document.querySelectorAll("[data-view-mode]").forEach((button) => {
      button.addEventListener("click", () => {
        state.viewMode = button.getAttribute("data-view-mode");
        document.querySelectorAll("[data-view-mode]").forEach((entry) => {
          entry.classList.toggle("active", entry === button);
        });
        renderResults();
      });
    });
  }

  bindGlobalEvents();
  render();
})();
