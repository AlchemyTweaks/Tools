﻿<#
.SYNOPSIS
    Disk Benchmark Tool v2.1  |  Powered by Microsoft DiskSpd
    Fixed: PSCustomObject parsing, disk auto-detection, latency collection,
           validity scoring, and JSON export completeness.

.PARAMETER DiskType
    SSD | NVMe | HDD

.PARAMETER DriveLetter
    Drive letter to benchmark (e.g. C  D  E). Leave empty to get interactive picker.

.PARAMETER Label
    Short label for this snapshot, e.g. Before or After_driver_update

.PARAMETER OutputPath
    Where to save the JSON result. Default: Desktop.

.PARAMETER DiskspdPath
    Optional explicit path to diskspd.exe.

.PARAMETER SkipWarmup
    Skip warmup phase. NOT recommended.

.EXAMPLE
    .\DiskBenchmark.ps1 -DiskType NVMe -DriveLetter C -Label Before
    .\DiskBenchmark.ps1 -DiskType SSD  -DriveLetter D
    .\DiskBenchmark.ps1 -DiskType HDD
#>

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("SSD","NVMe","HDD")]
    [string]$DiskType,

    [string]$DriveLetter  = "",
    [string]$Label        = ("Test_" + (Get-Date -Format "yyyyMMdd_HHmm")),
    [string]$OutputPath   = "",
    [string]$DiskspdPath  = "",
    [switch]$SkipWarmup
)

# ==============================================================
#  0. SELF-ELEVATION
# ==============================================================
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltinRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "  Requesting Administrator privileges (UAC prompt will appear)..." -ForegroundColor Yellow
    $argList  = "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Definition)`""
    $argList += " -DiskType `"$DiskType`""
    if ($DriveLetter  -ne "") { $argList += " -DriveLetter `"$DriveLetter`"" }
    if ($Label        -ne "") { $argList += " -Label `"$Label`"" }
    if ($OutputPath   -ne "") { $argList += " -OutputPath `"$OutputPath`"" }
    if ($DiskspdPath  -ne "") { $argList += " -DiskspdPath `"$DiskspdPath`"" }
    if ($SkipWarmup)          { $argList += " -SkipWarmup" }

    $si      = New-Object System.Diagnostics.ProcessStartInfo
    $si.FileName  = "powershell.exe"
    $si.Arguments = $argList
    $si.Verb      = "runas"
    try   { [System.Diagnostics.Process]::Start($si) | Out-Null }
    catch { Write-Host "  Elevation cancelled. Run as Administrator manually." -ForegroundColor Red
            Write-Host "  Press any key to exit..."
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") }
    exit
}

# ==============================================================
#  1. SAFE ENVIRONMENT
# ==============================================================
$ErrorActionPreference = "Continue"
$ProgressPreference    = "SilentlyContinue"
$WarningPreference     = "SilentlyContinue"

# Script directory  -  triple fallback
$scriptDir = $PSScriptRoot
if ([string]::IsNullOrEmpty($scriptDir)) {
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
}
if ([string]::IsNullOrEmpty($scriptDir)) { $scriptDir = $env:USERPROFILE }

# Output path
if ([string]::IsNullOrEmpty($OutputPath)) {
    $OutputPath = [Environment]::GetFolderPath("Desktop")
    if ([string]::IsNullOrEmpty($OutputPath) -or -not (Test-Path $OutputPath)) {
        $OutputPath = $env:USERPROFILE
    }
}
if (-not (Test-Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
}

# ==============================================================
#  2. UI HELPERS
# ==============================================================
function Write-Divider { Write-Host ("=" * 66) -ForegroundColor DarkGray }
function Write-Header  {
    param([string]$T)
    Write-Host ""
    Write-Divider
    Write-Host "  $T" -ForegroundColor Cyan
    Write-Divider
}
function Write-OK   { param([string]$T) Write-Host "  [ OK ] $T" -ForegroundColor Green }
function Write-WARN { param([string]$T) Write-Host "  [ !! ] $T" -ForegroundColor Yellow }
function Write-FAIL { param([string]$T) Write-Host "  [ XX ] $T" -ForegroundColor Red }
function Write-INFO { param([string]$T) Write-Host "         $T" -ForegroundColor Gray }
function Write-STEP { param([string]$T) Write-Host "   -->  $T"  -ForegroundColor White }

function Write-Check {
    param([string]$Label, [bool]$Pass, [string]$Detail = "")
    if ($Pass) { Write-Host "  [ OK ] $Label" -ForegroundColor Green -NoNewline }
    else       { Write-Host "  [ !! ] $Label" -ForegroundColor Red   -NoNewline }
    if ($Detail -ne "") { Write-Host "  --  $Detail" -ForegroundColor Gray } else { Write-Host "" }
}

# ==============================================================
#  3. DISK PROFILES
# ==============================================================
$profiles = @{
    SSD = @{
        Name             = "SATA SSD"
        WarmupSec        = 30
        TestSec          = 30
        Runs             = 3
        FileSize         = "1G"
        SeqBlock         = "128K"
        QueueDepth       = 32
        Threads          = 1
        MinSeqReadMBs    = 400
        MinSeqWriteMBs   = 300
        MinIOPS          = 20000
        MaxLatMs         = 0.5
        ExpectedReadMBs  = 550
        ExpectedWriteMBs = 520
    }
    NVMe = @{
        Name             = "NVMe PCIe SSD"
        WarmupSec        = 60
        TestSec          = 30
        Runs             = 5
        FileSize         = "4G"
        SeqBlock         = "128K"
        QueueDepth       = 32
        Threads          = 4
        MinSeqReadMBs    = 1500
        MinSeqWriteMBs   = 1000
        MinIOPS          = 100000
        MaxLatMs         = 0.1
        ExpectedReadMBs  = 3500
        ExpectedWriteMBs = 3000
    }
    HDD = @{
        Name             = "Mechanical HDD"
        WarmupSec        = 15
        TestSec          = 30
        Runs             = 3
        FileSize         = "512M"
        SeqBlock         = "64K"
        QueueDepth       = 4
        Threads          = 1
        MinSeqReadMBs    = 80
        MinSeqWriteMBs   = 60
        MinIOPS          = 80
        MaxLatMs         = 15.0
        ExpectedReadMBs  = 150
        ExpectedWriteMBs = 130
    }
}
$prof = $profiles[$DiskType]

# ==============================================================
#  4. BANNER
# ==============================================================
Clear-Host
Write-Host ""
Write-Host "  +----------------------------------------------------+" -ForegroundColor Cyan
Write-Host "  |          DISK BENCHMARK TOOL  v2.1                |" -ForegroundColor Cyan
Write-Host "  |          Powered by Microsoft DiskSpd             |" -ForegroundColor Cyan
Write-Host "  +----------------------------------------------------+" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Disk Type  : $DiskType ($($prof.Name))" -ForegroundColor White
Write-Host "  Label      : $Label"                    -ForegroundColor White
Write-Host "  Output     : $OutputPath"               -ForegroundColor White
Write-Host "  Privileges : Administrator"             -ForegroundColor Green
Write-Host ""

# ==============================================================
#  5. DISK DETECTION  (enumerate all drives with name + size)
# ==============================================================
Write-Header "Step 1/6 -- Detecting available drives"

function Get-DriveList {
    $drives = @()

    # Method A: Win32_LogicalDisk
    try {
        $disks = Get-WmiObject -Class Win32_LogicalDisk -ErrorAction Stop |
                 Where-Object { $_.DriveType -eq 3 -or $_.DriveType -eq 2 }
        foreach ($d in $disks) {
            $letter  = $d.DeviceID.TrimEnd(':').TrimEnd('\')
            $freeMB  = if ($d.FreeSpace)  { [math]::Round($d.FreeSpace  / 1GB, 1) } else { 0 }
            $totalMB = if ($d.Size)       { [math]::Round($d.Size       / 1GB, 1) } else { 0 }
            $label   = if ($d.VolumeName -and $d.VolumeName.Trim() -ne "") { $d.VolumeName } else { "No Label" }

            # Try to get physical model via Win32_DiskPartition chain
            $model = ""
            try {
                $assoc = Get-WmiObject -Query "ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='$($d.DeviceID)'} WHERE AssocClass=Win32_LogicalDiskToPartition" -ErrorAction Stop
                foreach ($part in $assoc) {
                    $diskAssoc = Get-WmiObject -Query "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($part.DeviceID)'} WHERE AssocClass=Win32_DiskDriveToDiskPartition" -ErrorAction Stop
                    if ($diskAssoc.Model) { $model = $diskAssoc.Model.Trim(); break }
                }
            } catch {}

            $drives += [PSCustomObject]@{
                Letter  = $letter
                Path    = $letter + ":\"
                Label   = $label
                Model   = $model
                FreGB   = $freeMB
                TotalGB = $totalMB
            }
        }
    } catch {}

    # Method B: fallback via Get-PSDrive if WMI failed
    if ($drives.Count -eq 0) {
        try {
            Get-PSDrive -PSProvider FileSystem -ErrorAction Stop | ForEach-Object {
                $drives += [PSCustomObject]@{
                    Letter  = $_.Name
                    Path    = $_.Root
                    Label   = "Drive $($_.Name)"
                    Model   = ""
                    FreGB   = [math]::Round($_.Free  / 1GB, 1)
                    TotalGB = [math]::Round(($_.Used + $_.Free) / 1GB, 1)
                }
            }
        } catch {}
    }
    return $drives
}

$availableDrives = Get-DriveList

if ($availableDrives.Count -eq 0) {
    Write-FAIL "No drives detected. Cannot continue."
    Read-Host "Press Enter to exit"; exit 1
}

Write-Host ""
Write-Host "  Available drives on this system:" -ForegroundColor White
Write-Host ""
Write-Host ("  {0,-5} {1,-14} {2,-8} {3,-10} {4}" -f "Drive","Volume Label","Free","Total","Model / Device") -ForegroundColor DarkGray
Write-Host ("  " + ("-" * 62)) -ForegroundColor DarkGray

$idx = 1
$driveMenu = @{}
foreach ($d in $availableDrives) {
    $model  = if ($d.Model -ne "") { $d.Model } else { "(model unknown)" }
    $free   = "$($d.FreGB) GB"
    $total  = "$($d.TotalGB) GB"
    Write-Host ("  [{0}]  {1,-14} {2,-8} {3,-10} {4}" -f `
        $idx, "$($d.Letter): $($d.Label)", $free, $total, $model) -ForegroundColor White
    $driveMenu[$idx.ToString()] = $d
    $idx++
}
Write-Host ""

# If DriveLetter was supplied via parameter, match it; otherwise prompt
$selectedDrive = $null

if ($DriveLetter -ne "") {
    $dl = $DriveLetter.TrimEnd(':').TrimEnd('\').Trim().ToUpper()
    foreach ($d in $availableDrives) {
        if ($d.Letter.ToUpper() -eq $dl) { $selectedDrive = $d; break }
    }
    if ($null -eq $selectedDrive) {
        Write-WARN "Drive $dl`:\ not found in detected drives. Available: $($availableDrives.Letter -join ', ')"
        Write-Host ""
    }
}

if ($null -eq $selectedDrive) {
    # Interactive picker
    $choice = ""
    while ($null -eq $selectedDrive) {
        $choice = (Read-Host "  Select drive number (or type the letter directly, e.g. C)").Trim()
        if ($driveMenu.ContainsKey($choice)) {
            $selectedDrive = $driveMenu[$choice]
        } else {
            # Try matching by letter
            $letter = $choice.TrimEnd(':').TrimEnd('\').ToUpper()
            foreach ($d in $availableDrives) {
                if ($d.Letter.ToUpper() -eq $letter) { $selectedDrive = $d; break }
            }
            if ($null -eq $selectedDrive) {
                Write-WARN "Invalid choice '$choice'. Try again."
            }
        }
    }
}

$DriveLetter = $selectedDrive.Letter.ToUpper()
$drivePath   = $selectedDrive.Path
Write-Host ""
Write-OK "Selected drive: $drivePath  |  $($selectedDrive.Label)  |  $($selectedDrive.Model)"

# ==============================================================
#  6. DISKSPD LOCATE / AUTO-DOWNLOAD
# ==============================================================
Write-Header "Step 2/6 -- Locating DiskSpd"

function Find-Diskspd {
    param([string]$Manual, [string]$SDir)
    $candidates = @()
    if ($Manual -ne "") { $candidates += $Manual }
    $candidates += @(
        (Join-Path $SDir "diskspd.exe"),
        "diskspd.exe",
        (Join-Path $env:USERPROFILE "Downloads\diskspd.exe"),
        (Join-Path $env:USERPROFILE "Desktop\diskspd.exe"),
        "C:\Tools\diskspd.exe",
        (Join-Path $env:ProgramFiles "DiskSpd\diskspd.exe")
    )
    foreach ($c in $candidates) {
        if ($c -ne "" -and (Test-Path $c -ErrorAction SilentlyContinue)) { return $c }
    }
    try { $gc = Get-Command diskspd.exe -ErrorAction Stop; return $gc.Source } catch {}
    return ""
}

function Download-Diskspd {
    param([string]$SaveTo)
    Write-WARN "DiskSpd not found  -  downloading from Microsoft GitHub..."
    Write-INFO  "https://github.com/microsoft/diskspd/releases/latest"
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

    try {
        $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/microsoft/diskspd/releases/latest" `
               -UseBasicParsing -Headers @{"User-Agent"="DiskBenchmark/2.1"} -ErrorAction Stop
    } catch {
        Write-FAIL "Cannot reach GitHub API: $($_.Exception.Message)"
        return ""
    }

    $asset = $rel.assets | Where-Object { $_.name -match "(?i)\.zip$" } | Select-Object -First 1
    if (-not $asset) { Write-FAIL "No ZIP in release '$($rel.tag_name)'."; return "" }

    $zipTemp = Join-Path $env:TEMP "diskspd_dl.zip"
    $exDir   = Join-Path $env:TEMP "diskspd_ex"
    $assetSizeKB = [math]::Round($asset.size / 1024)
    Write-STEP "Downloading $($asset.name)  ($assetSizeKB KB)..."

    try { (New-Object System.Net.WebClient).DownloadFile($asset.browser_download_url, $zipTemp) }
    catch { Write-FAIL "Download failed: $($_.Exception.Message)"; return "" }

    if (-not (Test-Path $zipTemp) -or (Get-Item $zipTemp).Length -lt 1000) {
        Write-FAIL "Download incomplete."; return ""
    }
    $dlSizeKB = [math]::Round((Get-Item $zipTemp).Length / 1024)
    Write-OK "Downloaded ($dlSizeKB KB)"

    if (Test-Path $exDir) { Remove-Item $exDir -Recurse -Force -ErrorAction SilentlyContinue }
    $ok = $false
    try { Add-Type -AssemblyName System.IO.Compression.FileSystem -EA Stop
          [System.IO.Compression.ZipFile]::ExtractToDirectory($zipTemp, $exDir); $ok=$true } catch {}
    if (-not $ok) {
        try { Expand-Archive -Path $zipTemp -DestinationPath $exDir -Force -EA Stop; $ok=$true } catch {}
    }
    if (-not $ok) { Write-FAIL "Extraction failed."; Remove-Item $zipTemp -Force -EA SilentlyContinue; return "" }

    $arch = "amd64"
    if (-not [Environment]::Is64BitOperatingSystem) { $arch = "x86" }
    try { if ([System.Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture -eq
              [System.Runtime.InteropServices.Architecture]::Arm64) { $arch = "ARM64" } } catch {}

    $exePath = ""
    foreach ($candidate in @((Join-Path $exDir "$arch\diskspd.exe"), (Join-Path $exDir "diskspd.exe"))) {
        if (Test-Path $candidate) { $exePath = $candidate; break }
    }
    if ($exePath -eq "") {
        $found = Get-ChildItem -Path $exDir -Filter "diskspd.exe" -Recurse -EA SilentlyContinue | Select-Object -First 1
        if ($found) { $exePath = $found.FullName }
    }
    if ($exePath -eq "") { Write-FAIL "diskspd.exe not found in ZIP."; return "" }

    $dest = Join-Path $SaveTo "diskspd.exe"
    try { Copy-Item $exePath -Destination $dest -Force -EA Stop }
    catch { Write-WARN "Cannot save to script folder  -  using temp location."; $dest = $exePath }

    Remove-Item $zipTemp -Force -EA SilentlyContinue
    if ($dest -ne $exePath) { Remove-Item $exDir -Recurse -Force -EA SilentlyContinue }
    Write-OK "DiskSpd installed: $dest"
    return $dest
}

$diskspdExe = Find-Diskspd -Manual $DiskspdPath -SDir $scriptDir
if ($diskspdExe -eq "") { $diskspdExe = Download-Diskspd -SaveTo $scriptDir }

if ($diskspdExe -eq "" -or -not (Test-Path $diskspdExe -EA SilentlyContinue)) {
    Write-FAIL "DiskSpd unavailable. Cannot benchmark."
    Write-INFO "Manual: https://github.com/microsoft/diskspd/releases  ->  place diskspd.exe next to this script"
    Write-Host ""; Write-Host "  Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown"); exit 1
}
Write-OK "DiskSpd ready: $diskspdExe"

# ==============================================================
#  7. PRE-FLIGHT CHECKS
# ==============================================================
Write-Header "Step 3/6 -- Pre-flight validity checks"

$issues   = New-Object System.Collections.Generic.List[string]
$warnings = New-Object System.Collections.Generic.List[string]

# Drive accessible
$driveOK = Test-Path $drivePath
Write-Check "Drive $drivePath accessible" $driveOK
if (-not $driveOK) {
    Write-FAIL "Drive $drivePath is not accessible. Aborting."
    Read-Host "Press Enter to exit"; exit 1
}

# Free space
$freeSpaceOK = $true; $freeMB = 0
try {
    $driveObj = Get-WmiObject -Query "SELECT FreeSpace FROM Win32_LogicalDisk WHERE DeviceID='${DriveLetter}:'" -EA Stop
    $freeMB   = [math]::Round($driveObj.FreeSpace / 1MB)
    $freeSpaceOK = ($freeMB -gt 2048)
    Write-Check "Free space  ($freeMB MB available, need 2048 MB)" $freeSpaceOK
    if (-not $freeSpaceOK) { $issues.Add("Low free space: $freeMB MB (need 2 GB)") }
} catch { Write-WARN "Cannot read free space (non-critical)" }

# Power plan
$powerPlanOK = $true
try {
    $pp = (powercfg /getactivescheme 2>$null)
    $powerPlanOK = ($pp -match "High performance|8c5e7fda|Ultimate|Balanced")
    Write-Check "Power plan (High Performance / Balanced)" $powerPlanOK
    if (-not $powerPlanOK) {
        $warnings.Add("Power Saver active  -  may throttle disk I/O")
        Write-INFO "Fix: Control Panel -> Power Options -> High Performance"
    }
} catch { Write-WARN "Cannot check power plan (non-critical)" }

# CPU load
$cpuOK = $true; $cpuLoad = 0
try {
    $cpuLoad = [math]::Round((Get-WmiObject Win32_Processor -EA Stop |
               Measure-Object -Property LoadPercentage -Average).Average)
    $cpuOK   = ($cpuLoad -lt 30)
    Write-Check "CPU load low  ($cpuLoad%)" $cpuOK
    if (-not $cpuOK) {
        $warnings.Add("CPU load $cpuLoad%  -  close browsers / background apps")
        Write-INFO "Fix: Close browsers, antivirus scans, Windows Update"
    }
} catch { Write-WARN "Cannot read CPU load (non-critical)" }

# Background disk I/O
$diskIOOK = $true
try {
    $ctr  = Get-Counter "\PhysicalDisk(_Total)\Disk Bytes/sec" -EA Stop
    $bgIO = [math]::Round($ctr.CounterSamples[0].CookedValue / 1MB, 1)
    $diskIOOK = ($bgIO -lt 50)
    Write-Check "Background disk I/O low  ($bgIO MB/s)" $diskIOOK
    if (-not $diskIOOK) {
        $warnings.Add("Background I/O $bgIO MB/s  -  pause cloud sync / Windows Update")
        Write-INFO "Fix: Pause OneDrive/Dropbox, antivirus scan"
    }
} catch { Write-WARN "Cannot read disk counters (non-critical)" }

Write-Host ""
if ($issues.Count -gt 0) {
    Write-Host "  CRITICAL  -  results will be unreliable:" -ForegroundColor Red
    foreach ($i in $issues) { Write-FAIL $i }
    Write-Host ""
    $ans = Read-Host "  Continue anyway? (Y/N)"
    if ($ans -notmatch "^[Yy]") { exit 1 }
}
if ($warnings.Count -gt 0) {
    Write-Host "  WARNINGS  -  results may be slightly affected:" -ForegroundColor Yellow
    foreach ($w in $warnings) { Write-WARN $w }
    Write-STEP "Waiting 5 seconds before starting..."; Start-Sleep -Seconds 5
}
if ($issues.Count -eq 0 -and $warnings.Count -eq 0) {
    Write-OK "All checks passed  -  results will be reliable"
}

# ==============================================================
#  8. WARMUP
# ==============================================================
Write-Header "Step 4/6 -- Warmup"

$testFile   = Join-Path $drivePath "_diskbench_tmp_.dat"
$warmupDone = $false

if (-not $SkipWarmup) {
    Write-STEP "Warming up drive for $($prof.WarmupSec)s  -  eliminates cold-start bias..."
    $wuArgs = @("-b128K", "-d$($prof.WarmupSec)", "-o4", "-t1", "-Sh", "-w100",
                "-c$($prof.FileSize)", $testFile)
    try {
        & $diskspdExe @wuArgs 2>&1 | Out-Null
        $warmupDone = $true
        Write-OK "Warmup complete"
    } catch { Write-WARN "Warmup error (non-fatal): $($_.Exception.Message)" }
} else {
    Write-WARN "Warmup skipped  -  first numbers may be 5-15% lower"
}

# ==============================================================
# ==============================================================
#  9. PARSER -- handles current DiskSpd text output
#
#  Current DiskSpd builds typically expose:
#    - per-section tables (Total IO / Read IO / Write IO)
#    - a total: row per section
#    - latency percentiles in a separate %-ile table
#
#  This parser is tolerant of both older and newer column names:
#    MB/s or MiB/s
#    AvgLat(ms) or LatAvg
#    thread rows with or without leading spaces
# ==============================================================
function Parse-Diskspd {
    param([string[]]$Lines)

    $r = [PSCustomObject]@{
        ReadMBs     = [double]0
        WriteMBs    = [double]0
        ReadIOPS    = [double]0
        WriteIOPS   = [double]0
        ReadLatAvg  = [double]0
        WriteLatAvg = [double]0
        ReadP50     = [double]0
        ReadP95     = [double]0
        ReadP99     = [double]0
        WriteP50    = [double]0
        WriteP95    = [double]0
        WriteP99    = [double]0
        Errors      = [int]0
        HasData     = [bool]$false
    }

    if ($null -eq $Lines -or $Lines.Count -eq 0) { return $r }

    function Nx {
        param([AllowNull()][string]$s)
        if ($null -eq $s) { return $null }
        $c = ($s -replace ",","").Trim()
        if ($c -eq "" -or $c -match "^(?i:n/a|nan|null)$") { return $null }
        if ($c -match "^[-+]?[0-9]+(?:\.[0-9]+)?$") { return [double]$c }
        return $null
    }

    function Get-CellNumber {
        param(
            [string[]]$Cells,
            [int]$Index,
            [bool]$IsTotalRow = $false
        )
        $useIndex = if ($IsTotalRow) { $Index - 1 } else { $Index }
        if ($useIndex -lt 0 -or $useIndex -ge $Cells.Count) { return $null }
        return Nx $Cells[$useIndex]
    }

    function Set-PercentileValue {
        param([string]$Label, [double]$ReadMs, [double]$WriteMs)
        $pct = $Label.Trim().ToLower()
        switch -Regex ($pct) {
            "^50(th)?$" {
                if ($null -ne $ReadMs)  { $r.ReadP50  = [math]::Round($ReadMs,  3) }
                if ($null -ne $WriteMs) { $r.WriteP50 = [math]::Round($WriteMs, 3) }
                break
            }
            "^95(th)?$" {
                if ($null -ne $ReadMs)  { $r.ReadP95  = [math]::Round($ReadMs,  3) }
                if ($null -ne $WriteMs) { $r.WriteP95 = [math]::Round($WriteMs, 3) }
                break
            }
            "^99(th)?$" {
                if ($null -ne $ReadMs)  { $r.ReadP99  = [math]::Round($ReadMs,  3) }
                if ($null -ne $WriteMs) { $r.WriteP99 = [math]::Round($WriteMs, 3) }
                break
            }
        }
    }

    $sec = "none"
    $inPercentiles = $false

    # Column indices -- updated when the thread header is seen
    $cBytes   = 1
    $cIOCount = 2
    $cMBs     = 3
    $cIOps    = 4
    $cLatAvg  = 5
    $cLat50   = -1
    $cLat95   = -1
    $cLat99   = -1

    # Duration + fallbacks
    $rDur = [double]0

    # Per-thread accumulators (fallback when total rows are absent)
    $rBytes  = [double]0; $wBytes  = [double]0
    $rIOCnt  = [double]0; $wIOCnt  = [double]0
    $rMBsS   = [double]0; $wMBsS   = [double]0
    $rIOpsS  = [double]0; $wIOpsS  = [double]0
    $rLatS   = [double]0; $wLatS   = [double]0
    $rLatN   = 0;         $wLatN   = 0
    $rP50S   = [double]0; $wP50S   = [double]0
    $rP95S   = [double]0; $wP95S   = [double]0
    $rP99S   = [double]0; $wP99S   = [double]0
    $rP50N   = 0;         $wP50N   = 0
    $rP95N   = 0;         $wP95N   = 0
    $rP99N   = 0;         $wP99N   = 0

    foreach ($line in $Lines) {
        if ($null -eq $line) { continue }
        $l  = $line.ToString()
        $lt = $l.Trim()
        if ($lt -eq "") { continue }

        # Duration line varies slightly by DiskSpd build.
        if ($lt -match "(?i)(?:actual\s+)?test time:\s*([0-9]+(?:\.[0-9]+)?)") {
            $rDur = [double]$Matches[1]
            continue
        }

        # IO section headings
        if ($lt -match "^(?i)(read|write|total)\s+io\s*:?\s*$") {
            $sec = $Matches[1].ToLower()
            $inPercentiles = $false
            continue
        }

        # Latency percentile table header
        if ($lt -match "^%-ile\s*\|") {
            $inPercentiles = $true
            continue
        }

        if ($inPercentiles) {
            if ($lt -match "^[-\s|]+$") { continue }
            if ($lt -notmatch "\|") {
                $inPercentiles = $false
            } else {
                $pts = $lt -split "\|"
                if ($pts.Count -ge 3) {
                    Set-PercentileValue -Label $pts[0] -ReadMs (Nx $pts[1]) -WriteMs (Nx $pts[2])
                    continue
                }
            }
        }

        # Thread table header -- detect the current column layout.
        if ($lt -match "^thread\s*\|") {
            $pts = $lt -split "\|"
            for ($ci = 0; $ci -lt $pts.Count; $ci++) {
                $h = $pts[$ci].Trim().ToLower()
                if ($h -match "bytes")              { $cBytes   = $ci }
                if ($h -match "^i/os$|^ios$")       { $cIOCount = $ci }
                if ($h -match "(?:mi|m)b/s")        { $cMBs     = $ci }
                if ($h -match "i/o per s|iops")     { $cIOps    = $ci }
                if ($h -match "avglat|latavg|lat avg") { $cLatAvg = $ci }
                if ($h -match "50th|lat50")         { $cLat50   = $ci }
                if ($h -match "95th|lat95")         { $cLat95   = $ci }
                if ($h -match "99th|lat99")         { $cLat99   = $ci }
            }
            continue
        }

        if ($lt -match "^[-\s|]+$") { continue }

        $isTotalRow  = ($lt -match "^total:\s*")
        $isThreadRow = ($lt -match "^\d+\s*\|")
        if (-not ($isTotalRow -or $isThreadRow)) {
            if ($lt -match "(\d+)\s+error") { $r.Errors += [int]$Matches[1] }
            continue
        }

        $pts    = $lt -split "\|"
        $bytes  = Get-CellNumber -Cells $pts -Index $cBytes  -IsTotalRow:$isTotalRow
        $ioCnt  = Get-CellNumber -Cells $pts -Index $cIOCount -IsTotalRow:$isTotalRow
        $mbs    = Get-CellNumber -Cells $pts -Index $cMBs    -IsTotalRow:$isTotalRow
        $iops   = Get-CellNumber -Cells $pts -Index $cIOps   -IsTotalRow:$isTotalRow
        $latAvg = Get-CellNumber -Cells $pts -Index $cLatAvg -IsTotalRow:$isTotalRow
        $lat50  = if ($cLat50 -ge 0) { Get-CellNumber -Cells $pts -Index $cLat50 -IsTotalRow:$isTotalRow } else { $null }
        $lat95  = if ($cLat95 -ge 0) { Get-CellNumber -Cells $pts -Index $cLat95 -IsTotalRow:$isTotalRow } else { $null }
        $lat99  = if ($cLat99 -ge 0) { Get-CellNumber -Cells $pts -Index $cLat99 -IsTotalRow:$isTotalRow } else { $null }

        if ($isTotalRow) {
            switch ($sec) {
                "read" {
                    if ($null -ne $mbs)    { $r.ReadMBs    = [math]::Round($mbs,    2) }
                    elseif ($null -ne $bytes -and $rDur -gt 0) { $r.ReadMBs = [math]::Round($bytes / $rDur / 1MB, 2) }

                    if ($null -ne $iops)   { $r.ReadIOPS   = [math]::Round($iops,   0) }
                    elseif ($null -ne $ioCnt -and $rDur -gt 0) { $r.ReadIOPS = [math]::Round($ioCnt / $rDur, 0) }

                    if ($null -ne $latAvg) { $r.ReadLatAvg = [math]::Round($latAvg, 3) }
                    if ($null -ne $lat50)  { $r.ReadP50    = [math]::Round($lat50,  3) }
                    if ($null -ne $lat95)  { $r.ReadP95    = [math]::Round($lat95,  3) }
                    if ($null -ne $lat99)  { $r.ReadP99    = [math]::Round($lat99,  3) }
                }
                "write" {
                    if ($null -ne $mbs)    { $r.WriteMBs    = [math]::Round($mbs,    2) }
                    elseif ($null -ne $bytes -and $rDur -gt 0) { $r.WriteMBs = [math]::Round($bytes / $rDur / 1MB, 2) }

                    if ($null -ne $iops)   { $r.WriteIOPS   = [math]::Round($iops,   0) }
                    elseif ($null -ne $ioCnt -and $rDur -gt 0) { $r.WriteIOPS = [math]::Round($ioCnt / $rDur, 0) }

                    if ($null -ne $latAvg) { $r.WriteLatAvg = [math]::Round($latAvg, 3) }
                    if ($null -ne $lat50)  { $r.WriteP50    = [math]::Round($lat50,  3) }
                    if ($null -ne $lat95)  { $r.WriteP95    = [math]::Round($lat95,  3) }
                    if ($null -ne $lat99)  { $r.WriteP99    = [math]::Round($lat99,  3) }
                }
            }
            continue
        }

        switch ($sec) {
            "read" {
                if ($null -ne $bytes)  { $rBytes += $bytes }
                if ($null -ne $ioCnt)  { $rIOCnt += $ioCnt }
                if ($null -ne $mbs)    { $rMBsS  += $mbs }
                if ($null -ne $iops)   { $rIOpsS += $iops }
                if ($null -ne $latAvg) { $rLatS  += $latAvg; $rLatN++ }
                if ($null -ne $lat50)  { $rP50S  += $lat50;  $rP50N++ }
                if ($null -ne $lat95)  { $rP95S  += $lat95;  $rP95N++ }
                if ($null -ne $lat99)  { $rP99S  += $lat99;  $rP99N++ }
            }
            "write" {
                if ($null -ne $bytes)  { $wBytes += $bytes }
                if ($null -ne $ioCnt)  { $wIOCnt += $ioCnt }
                if ($null -ne $mbs)    { $wMBsS  += $mbs }
                if ($null -ne $iops)   { $wIOpsS += $iops }
                if ($null -ne $latAvg) { $wLatS  += $latAvg; $wLatN++ }
                if ($null -ne $lat50)  { $wP50S  += $lat50;  $wP50N++ }
                if ($null -ne $lat95)  { $wP95S  += $lat95;  $wP95N++ }
                if ($null -ne $lat99)  { $wP99S  += $lat99;  $wP99N++ }
            }
        }
    }

    # Fallbacks when the total: row is absent or incomplete
    if ($r.ReadMBs -le 0) {
        if ($rMBsS -gt 0)      { $r.ReadMBs  = [math]::Round($rMBsS, 2) }
        elseif ($rDur -gt 0 -and $rBytes -gt 0) { $r.ReadMBs = [math]::Round($rBytes / $rDur / 1MB, 2) }
    }
    if ($r.WriteMBs -le 0) {
        if ($wMBsS -gt 0)      { $r.WriteMBs = [math]::Round($wMBsS, 2) }
        elseif ($rDur -gt 0 -and $wBytes -gt 0) { $r.WriteMBs = [math]::Round($wBytes / $rDur / 1MB, 2) }
    }

    if ($r.ReadIOPS -le 0) {
        if ($rIOpsS -gt 0)     { $r.ReadIOPS  = [math]::Round($rIOpsS, 0) }
        elseif ($rDur -gt 0 -and $rIOCnt -gt 0) { $r.ReadIOPS = [math]::Round($rIOCnt / $rDur, 0) }
    }
    if ($r.WriteIOPS -le 0) {
        if ($wIOpsS -gt 0)     { $r.WriteIOPS = [math]::Round($wIOpsS, 0) }
        elseif ($rDur -gt 0 -and $wIOCnt -gt 0) { $r.WriteIOPS = [math]::Round($wIOCnt / $rDur, 0) }
    }

    if ($r.ReadLatAvg -le 0 -and $rLatN -gt 0) {
        $r.ReadLatAvg = [math]::Round($rLatS / $rLatN, 3)
    }
    if ($r.WriteLatAvg -le 0 -and $wLatN -gt 0) {
        $r.WriteLatAvg = [math]::Round($wLatS / $wLatN, 3)
    }

    if ($r.ReadP50 -le 0 -and $rP50N -gt 0) { $r.ReadP50  = [math]::Round($rP50S / $rP50N, 3) }
    if ($r.ReadP95 -le 0 -and $rP95N -gt 0) { $r.ReadP95  = [math]::Round($rP95S / $rP95N, 3) }
    if ($r.ReadP99 -le 0 -and $rP99N -gt 0) { $r.ReadP99  = [math]::Round($rP99S / $rP99N, 3) }
    if ($r.WriteP50 -le 0 -and $wP50N -gt 0) { $r.WriteP50 = [math]::Round($wP50S / $wP50N, 3) }
    if ($r.WriteP95 -le 0 -and $wP95N -gt 0) { $r.WriteP95 = [math]::Round($wP95S / $wP95N, 3) }
    if ($r.WriteP99 -le 0 -and $wP99N -gt 0) { $r.WriteP99 = [math]::Round($wP99S / $wP99N, 3) }

    $r.HasData = ($r.ReadMBs -gt 0 -or $r.WriteMBs -gt 0 -or $r.ReadIOPS -gt 0 -or $r.WriteIOPS -gt 0)
    return $r
}

function Get-SizeBytes {
    param([string]$Spec)

    if ([string]::IsNullOrWhiteSpace($Spec)) { return [int64]0 }
    $s = $Spec.Trim().ToUpper()
    if ($s -notmatch "^([0-9]+(?:\.[0-9]+)?)([KMG]?)B?$") { return [int64]0 }

    $n = [double]$Matches[1]
    $u = $Matches[2]

    switch ($u) {
        "K" { return [int64]([math]::Round($n * 1KB)) }
        "M" { return [int64]([math]::Round($n * 1MB)) }
        "G" { return [int64]([math]::Round($n * 1GB)) }
        default { return [int64]([math]::Round($n)) }
    }
}

function Get-BlockBytesFromArgs {
    param([string[]]$Args)

    foreach ($a in $Args) {
        if ($a -match "^-b(.+)$") {
            return (Get-SizeBytes $Matches[1])
        }
    }
    return [int64]0
}

function Repair-ModeIops {
    param(
        [PSCustomObject]$Result,
        [string]$Mode,
        [int64]$BlockBytes
    )

    if ($null -eq $Result -or $BlockBytes -le 0) { return }

    $mbsProp  = if ($Mode -eq "Read") { "ReadMBs" } else { "WriteMBs" }
    $iopsProp = if ($Mode -eq "Read") { "ReadIOPS" } else { "WriteIOPS" }

    $mbs  = [double]$Result.$mbsProp
    $iops = [double]$Result.$iopsProp
    if ($mbs -le 0) { return }

    # DiskSpd text output occasionally reports an unexpected IOPS field layout.
    # Use bandwidth and known block size as a safe fallback for these fixed tests.
    $derived = [math]::Round(($mbs * 1MB) / $BlockBytes, 0)
    if ($derived -le 0) { return }

    $ratio = if ($iops -gt 0) { $iops / [double]$derived } else { [double]0 }
    if ($iops -le 0 -or $ratio -lt 0.5 -or $ratio -gt 1.5) {
        $Result.$iopsProp = [double]$derived
    }
}

# ==============================================================
#  10. RUN-TESTS -- runs DiskSpd N times, returns averaged result
# ==============================================================
function Run-Tests {
    param(
        [string[]]$DsArgs,
        [string]$Mode,
        [int]$Runs,
        [string]$TestName
    )

    Write-INFO "Args: $($DsArgs -join ' ')"
    Write-Host ""

    $blockBytes = Get-BlockBytesFromArgs -Args $DsArgs

    [PSCustomObject[]]$all = @()

    for ($i = 1; $i -le $Runs; $i++) {
        Write-Host "        Run $i / $Runs ..." -ForegroundColor Gray -NoNewline

        $raw = @()
        try {
            $raw = & $diskspdExe @DsArgs 2>&1
        } catch {
            Write-Host "  [ERROR] $($_.Exception.Message)" -ForegroundColor Red
            continue
        }

        $p = Parse-Diskspd -Lines ([string[]]$raw)
        Repair-ModeIops -Result $p -Mode $Mode -BlockBytes $blockBytes

        if (-not $p.HasData) {
            Write-Host "  [WARNING] No data -- full DiskSpd output:" -ForegroundColor Yellow
            Write-Host ""
            $raw | ForEach-Object { Write-INFO "  | $_" }
            Write-Host ""
        } else {
            if ($Mode -eq "Read") {
                Write-Host ("  {0,8:N1} MB/s  |  {1,8:N0} IOPS  |  lat avg {2:N3} ms  |  P99 {3:N3} ms" -f `
                    $p.ReadMBs, $p.ReadIOPS, $p.ReadLatAvg, $p.ReadP99) -ForegroundColor White
            } else {
                Write-Host ("  {0,8:N1} MB/s  |  {1,8:N0} IOPS  |  lat avg {2:N3} ms  |  P99 {3:N3} ms" -f `
                    $p.WriteMBs, $p.WriteIOPS, $p.WriteLatAvg, $p.WriteP99) -ForegroundColor White
            }
        }

        $all += $p
        if ($i -lt $Runs) { Start-Sleep -Seconds 3 }
    }

    if ($all.Count -eq 0) {
        Write-FAIL "All $Runs runs failed -- no data for $TestName"
        return $null
    }

    [PSCustomObject[]]$valid = @($all | Where-Object { $_.HasData -eq $true })

    # Loop-based averages -- avoids Measure-Object issues with PSCustomObject
    function SA { param([PSCustomObject[]]$a, [string]$p2)
        $s = [double]0; $n = 0
        foreach ($x in $a) { $v = $x.$p2; if ($null -ne $v -and $v -gt 0) { $s += $v; $n++ } }
        if ($n -eq 0) { return [double]0 }
        return [math]::Round($s / $n, 3)
    }
    function SMin { param([PSCustomObject[]]$a, [string]$p2)
        $m = [double]::MaxValue
        foreach ($x in $a) { $v = $x.$p2; if ($null -ne $v -and $v -gt 0 -and $v -lt $m) { $m = $v } }
        if ($m -eq [double]::MaxValue) { return [double]0 }
        return [math]::Round($m, 2)
    }
    function SMax { param([PSCustomObject[]]$a, [string]$p2)
        $m = [double]0
        foreach ($x in $a) { $v = $x.$p2; if ($null -ne $v -and $v -gt $m) { $m = $v } }
        return [math]::Round($m, 2)
    }

    $result = [PSCustomObject]@{
        ReadMBs     = [math]::Round((SA $all "ReadMBs"),     2)
        WriteMBs    = [math]::Round((SA $all "WriteMBs"),    2)
        ReadIOPS    = [math]::Round((SA $all "ReadIOPS"),    0)
        WriteIOPS   = [math]::Round((SA $all "WriteIOPS"),   0)
        ReadLatAvg  = [math]::Round((SA $all "ReadLatAvg"),  3)
        WriteLatAvg = [math]::Round((SA $all "WriteLatAvg"), 3)
        ReadP50     = [math]::Round((SA $all "ReadP50"),     3)
        ReadP95     = [math]::Round((SA $all "ReadP95"),     3)
        ReadP99     = [math]::Round((SA $all "ReadP99"),     3)
        WriteP50    = [math]::Round((SA $all "WriteP50"),    3)
        WriteP95    = [math]::Round((SA $all "WriteP95"),    3)
        WriteP99    = [math]::Round((SA $all "WriteP99"),    3)
        MBs_min     = if ($Mode -eq "Read") { SMin $all "ReadMBs" } else { SMin $all "WriteMBs" }
        MBs_max     = if ($Mode -eq "Read") { SMax $all "ReadMBs" } else { SMax $all "WriteMBs" }
        Runs        = $all.Count
        ValidRuns   = $valid.Count
        Variance    = [double]0
        HasData     = ($valid.Count -gt 0)
    }

    $ctr = if ($Mode -eq "Read") { $result.ReadMBs } else { $result.WriteMBs }
    if ($ctr -gt 0) {
        $result.Variance = [math]::Round(($result.MBs_max - $result.MBs_min) / $ctr * 100, 1)
    }
    if ($valid.Count -eq 0) { Write-WARN "No valid runs for $TestName -- result is zero" }
    return $result
}


# ==============================================================
#  11. BENCHMARK PHASES
# ==============================================================
$benchmarkErrors = @()

# --- Sequential Read ---
Write-Header "Step 5/6 -- Sequential Read"
Write-INFO "Measures: large-file copy speed, OS load, streaming (block=$($prof.SeqBlock))"
$seqRead = Run-Tests -DsArgs @(
    "-b$($prof.SeqBlock)", "-d$($prof.TestSec)", "-o$($prof.QueueDepth)", "-t$($prof.Threads)",
    "-Sh", "-w0", "-D", "-L", "-c$($prof.FileSize)", $testFile
) -Mode "Read" -Runs $prof.Runs -TestName "Sequential Read"

if ($null -eq $seqRead) { $benchmarkErrors += "Sequential Read failed completely" }
elseif (-not $seqRead.HasData) { $benchmarkErrors += "Sequential Read: data parse failed (zeroed result)" }
else {
    Write-OK "Avg: $($seqRead.ReadMBs) MB/s  (variance $($seqRead.Variance)%,  min $($seqRead.MBs_min)  max $($seqRead.MBs_max))"
    if ($seqRead.Variance -gt 15) { Write-WARN "High variance ($($seqRead.Variance)%)  -  possible thermal throttling" }
}
Start-Sleep -Seconds 5

# --- Sequential Write ---
Write-Header "Step 5/6 -- Sequential Write"
Write-INFO "Measures: saving large files, backup, video recording"
$seqWrite = Run-Tests -DsArgs @(
    "-b$($prof.SeqBlock)", "-d$($prof.TestSec)", "-o$($prof.QueueDepth)", "-t$($prof.Threads)",
    "-Sh", "-w100", "-D", "-L", "-c$($prof.FileSize)", $testFile
) -Mode "Write" -Runs $prof.Runs -TestName "Sequential Write"

if ($null -eq $seqWrite) { $benchmarkErrors += "Sequential Write failed completely" }
elseif (-not $seqWrite.HasData) { $benchmarkErrors += "Sequential Write: data parse failed (zeroed result)" }
else {
    Write-OK "Avg: $($seqWrite.WriteMBs) MB/s  (variance $($seqWrite.Variance)%)"
    if ($seqWrite.Variance -gt 15) { Write-WARN "High variance  -  possible SLC cache exhaustion" }
}
Start-Sleep -Seconds 5

# --- Random 4K Read ---
Write-Header "Step 5/6 -- Random 4K Read  (IOPS + Latency)"
Write-INFO "Measures: app launch time, OS responsiveness, game loading"
$rand4kRead = Run-Tests -DsArgs @(
    "-b4K", "-d$($prof.TestSec)", "-o$($prof.QueueDepth)", "-t$($prof.Threads)",
    "-Sh", "-w0", "-r", "-D", "-L", "-c$($prof.FileSize)", $testFile
) -Mode "Read" -Runs $prof.Runs -TestName "Random 4K Read"

if ($null -eq $rand4kRead) { $benchmarkErrors += "Random 4K Read failed completely" }
elseif (-not $rand4kRead.HasData) { $benchmarkErrors += "Random 4K Read: data parse failed" }
else {
    Write-OK "IOPS: $($rand4kRead.ReadIOPS)  |  avg lat: $($rand4kRead.ReadLatAvg) ms  |  P99: $($rand4kRead.ReadP99) ms"
}
Start-Sleep -Seconds 5

# --- Random 4K Write ---
Write-Header "Step 5/6 -- Random 4K Write  (IOPS + Latency)"
Write-INFO "Measures: database writes, log files, frequent small saves"
$rand4kWrite = Run-Tests -DsArgs @(
    "-b4K", "-d$($prof.TestSec)", "-o$($prof.QueueDepth)", "-t$($prof.Threads)",
    "-Sh", "-w100", "-r", "-D", "-L", "-c$($prof.FileSize)", $testFile
) -Mode "Write" -Runs $prof.Runs -TestName "Random 4K Write"

if ($null -eq $rand4kWrite) { $benchmarkErrors += "Random 4K Write failed completely" }
elseif (-not $rand4kWrite.HasData) { $benchmarkErrors += "Random 4K Write: data parse failed" }
else {
    Write-OK "IOPS: $($rand4kWrite.WriteIOPS)  |  avg lat: $($rand4kWrite.WriteLatAvg) ms  |  P99: $($rand4kWrite.WriteP99) ms"
}

# Cleanup
Remove-Item $testFile -Force -EA SilentlyContinue

# ==============================================================
#  12. VALIDITY SCORING
# ==============================================================
Write-Header "Step 6/6 -- Validity scoring & export"

$score  = 100
$checks = @()

$checks += @{ check="Running as Administrator"; pass=$true; detail="" }

if ($warmupDone) { $checks += @{ check="Warmup completed";  pass=$true;  detail="" } }
else             { $score -= 10; $checks += @{ check="Warmup skipped"; pass=$false; detail="First-run numbers may be 5-15% lower" } }

if ($cpuOK)    { $checks += @{ check="CPU load acceptable"; pass=$true; detail="" } }
else           { $score -= 10; $checks += @{ check="CPU load high ($cpuLoad%)";  pass=$false; detail="Retest with apps closed" } }

if ($diskIOOK) { $checks += @{ check="Background I/O low"; pass=$true; detail="" } }
else           { $score -= 10; $checks += @{ check="Background I/O elevated"; pass=$false; detail="Pause cloud sync / updates" } }

# Benchmark errors
foreach ($be in $benchmarkErrors) {
    $score -= 20; $checks += @{ check="Benchmark issue: $be"; pass=$false; detail="Result for this test is zero / missing" }
}

# Data validity
if ($seqRead -and $seqRead.HasData) {
    $readOK = ($seqRead.ReadMBs -ge $prof.MinSeqReadMBs)
    if ($readOK) { $checks += @{ check="Seq Read meets minimum ($($seqRead.ReadMBs) MB/s >= $($prof.MinSeqReadMBs))"; pass=$true; detail="" } }
    else         { $score -= 20; $checks += @{ check="Seq Read below minimum ($($seqRead.ReadMBs) < $($prof.MinSeqReadMBs) MB/s)"; pass=$false; detail="Check SATA cable, PCIe slot, or storage driver" } }
}

if ($seqRead -and $seqRead.HasData -and $seqRead.Variance -gt 20) {
    $score -= 15
    $checks += @{ check="High variance ($($seqRead.Variance)%)"; pass=$false; detail="Rerun with no background activity" }
} elseif ($seqRead -and $seqRead.HasData) {
    $checks += @{ check="Variance acceptable ($($seqRead.Variance)%)"; pass=$true; detail="" }
}

$score      = [math]::Max(0, $score)
$validLabel = if ($score -ge 90) {"RELIABLE"} elseif ($score -ge 65) {"ACCEPTABLE"} else {"UNRELIABLE"}
$vColor     = if ($score -ge 90) {"Green"}    elseif ($score -ge 65) {"Yellow"}     else {"Red"}

foreach ($c in $checks) { Write-Check $c.check $c.pass $c.detail }
Write-Host ""
Write-Host "  Validity Score: $score/100  --  $validLabel" -ForegroundColor $vColor

if ($benchmarkErrors.Count -gt 0) {
    Write-Host ""
    Write-Host "  BENCHMARK ERRORS DETECTED:" -ForegroundColor Red
    foreach ($be in $benchmarkErrors) { Write-FAIL $be }
    Write-WARN "The JSON will still be saved but affected fields will be zero."
    Write-WARN "Load the JSON in the Viewer  -  it will flag the missing data."
}

# ==============================================================
#  13. SYSTEM INFO
# ==============================================================
$sysInfo = @{
    ComputerName  = $env:COMPUTERNAME
    OS            = ""
    CPU           = ""
    RAM_GB        = 0
    PowerPlan     = ""
    DriveModel    = $selectedDrive.Model
    DriveLabel    = $selectedDrive.Label
    DriveTotalGB  = $selectedDrive.TotalGB
    DriveFreeGB   = $selectedDrive.FreGB
}
try { $sysInfo.OS       = (Get-WmiObject Win32_OperatingSystem  -EA Stop).Caption } catch {}
try { $sysInfo.CPU      = (Get-WmiObject Win32_Processor        -EA Stop | Select-Object -First 1).Name } catch {}
try { $sysInfo.RAM_GB   = [math]::Round((Get-WmiObject Win32_ComputerSystem -EA Stop).TotalPhysicalMemory/1GB,1) } catch {}
try { $sysInfo.PowerPlan= ((powercfg /getactivescheme 2>$null) -split "\(" | Select-Object -Last 1).TrimEnd(")") } catch {}

# ==============================================================
#  14. CONVERT RESULTS TO PLAIN HASHTABLES FOR JSON
# ==============================================================
function To-Dict {
    param($obj)
    if ($null -eq $obj) { return $null }
    $d = @{}
    $obj.PSObject.Properties | ForEach-Object { $d[$_.Name] = $_.Value }
    return $d
}

$safeLabel = $Label -replace '[^\w\-]','_'

$payload = @{
    meta = @{
        version       = "2.1"
        tool          = "DiskBenchmark.ps1 + DiskSpd"
        timestamp     = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        label         = $Label
        diskType      = $DiskType
        driveLetter   = $DriveLetter
        drivePath     = $drivePath
        system        = $sysInfo
    }
    validity = @{
        score           = $score
        label           = $validLabel
        warmupDone      = $warmupDone
        adminMode       = $true
        cpuLoadOk       = $cpuOK
        diskIOOk        = $diskIOOK
        benchmarkErrors = @($benchmarkErrors)
        issues          = @($issues)
        warnings        = @($warnings)
        details         = @($checks)
    }
    profile = @{
        displayName      = $prof.Name
        warmupSec        = $prof.WarmupSec
        testDurationSec  = $prof.TestSec
        runs             = $prof.Runs
        fileSize         = $prof.FileSize
        seqBlockSize     = $prof.SeqBlock
        queueDepth       = $prof.QueueDepth
        threadCount      = $prof.Threads
        thresholds = @{
            minSeqReadMBs    = $prof.MinSeqReadMBs
            minSeqWriteMBs   = $prof.MinSeqWriteMBs
            minIOPS          = $prof.MinIOPS
            maxLatencyMs     = $prof.MaxLatMs
            expectedReadMBs  = $prof.ExpectedReadMBs
            expectedWriteMBs = $prof.ExpectedWriteMBs
        }
    }
    results = @{
        seqRead     = (To-Dict $seqRead)
        seqWrite    = (To-Dict $seqWrite)
        rand4kRead  = (To-Dict $rand4kRead)
        rand4kWrite = (To-Dict $rand4kWrite)
    }
}

# ==============================================================
#  15. SAVE JSON
# ==============================================================
$jsonStr = $payload | ConvertTo-Json -Depth 10
$outFile = Join-Path $OutputPath "DiskBench_${DiskType}_${safeLabel}.json"
$saved   = $false

try {
    [System.IO.File]::WriteAllText($outFile, $jsonStr, [System.Text.Encoding]::UTF8)
    $saved = $true
} catch {
    Write-WARN "Cannot write to $outFile  -  $($_.Exception.Message)"
    $outFile = Join-Path $env:USERPROFILE "DiskBench_${DiskType}_${safeLabel}.json"
    try {
        [System.IO.File]::WriteAllText($outFile, $jsonStr, [System.Text.Encoding]::UTF8)
        $saved = $true
    } catch { Write-FAIL "Could not save JSON anywhere: $($_.Exception.Message)" }
}

if ($saved) { Write-OK "Results saved: $outFile" }

# ==============================================================
#  16. CONSOLE SUMMARY
# ==============================================================
Write-Host ""
Write-Divider
Write-Host "  FINAL RESULTS  --  $DiskType on $drivePath  ($Label)" -ForegroundColor Cyan
Write-Divider

function FmtVal { param($obj, [string]$prop, [string]$unit)
    if ($null -eq $obj -or -not $obj.HasData) { return "n/a (parse failed)" }
    $v = $obj.$prop; if ($null -eq $v) { return "n/a" }
    return "$v $unit"
}

Write-Host ("  {0,-30} {1}" -f "Sequential Read:",     (FmtVal $seqRead    "ReadMBs"    "MB/s")) -ForegroundColor White
Write-Host ("  {0,-30} {1}" -f "Sequential Write:",    (FmtVal $seqWrite   "WriteMBs"   "MB/s")) -ForegroundColor White
Write-Host ("  {0,-30} {1}" -f "Random 4K Read IOPS:", (FmtVal $rand4kRead "ReadIOPS"   "IOPS")) -ForegroundColor White
Write-Host ("  {0,-30} {1}" -f "Random 4K Write IOPS:", (FmtVal $rand4kWrite "WriteIOPS" "IOPS")) -ForegroundColor White

$readLat  = if ($rand4kRead  -and $rand4kRead.HasData)  { "$($rand4kRead.ReadLatAvg) ms avg  /  $($rand4kRead.ReadP99) ms P99"   } else { "n/a" }
$writeLat = if ($rand4kWrite -and $rand4kWrite.HasData) { "$($rand4kWrite.WriteLatAvg) ms avg  /  $($rand4kWrite.WriteP99) ms P99" } else { "n/a" }
Write-Host ("  {0,-30} {1}" -f "Read Latency (avg/P99):",$readLat)  -ForegroundColor White
Write-Host ("  {0,-30} {1}" -f "Write Latency (avg/P99):",$writeLat) -ForegroundColor White
Write-Host ("  {0,-30} {1}" -f "Validity:", "$score/100  $validLabel") -ForegroundColor $vColor

if ($benchmarkErrors.Count -gt 0) {
    Write-Host ""
    Write-Host ("  {0,-30} {1}" -f "Benchmark errors:", $benchmarkErrors.Count) -ForegroundColor Red
    foreach ($be in $benchmarkErrors) { Write-Host "    - $be" -ForegroundColor Red }
}

Write-Host ""
Write-Divider
if ($saved) {
    Write-Host "  Open DiskBenchmark-Viewer.html and load:" -ForegroundColor Green
    Write-Host "  $outFile" -ForegroundColor Cyan
}
Write-Divider
Write-Host ""
Write-Host "  Press any key to close this window..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
