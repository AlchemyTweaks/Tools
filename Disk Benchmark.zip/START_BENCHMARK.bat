@echo off
setlocal EnableDelayedExpansion
title Disk Benchmark Tool v2.1

set "SCRIPT_DIR=%~dp0"
set "PS1=%SCRIPT_DIR%DiskBenchmark.ps1"

if not exist "%PS1%" (
    echo.
    echo  [ERROR] DiskBenchmark.ps1 not found in: %SCRIPT_DIR%
    echo  Make sure both files are in the same folder.
    echo.
    pause & exit /b 1
)

:MENU_DISKTYPE
cls
echo.
echo  +---------------------------------------------------+
echo  ^|         DISK BENCHMARK TOOL  v2.1               ^|
echo  ^|         Powered by Microsoft DiskSpd            ^|
echo  +---------------------------------------------------+
echo.
echo  Select the type of disk to benchmark:
echo.
echo    [1]  NVMe  (PCIe SSD - fastest, e.g. M.2 slot)
echo    [2]  SSD   (SATA SSD - standard fast drive)
echo    [3]  HDD   (Mechanical hard drive)
echo.
set /p DTYPE="  Your choice (1/2/3): "
if "%DTYPE%"=="1" set "DT=NVMe" & goto MENU_LABEL
if "%DTYPE%"=="2" set "DT=SSD"  & goto MENU_LABEL
if "%DTYPE%"=="3" set "DT=HDD"  & goto MENU_LABEL
echo  Invalid. Enter 1, 2 or 3.
timeout /t 2 >nul & goto MENU_DISKTYPE

:MENU_LABEL
cls
echo.
echo  +---------------------------------------------------+
echo  ^|  Disk type: %DT%                                    ^|
echo  +---------------------------------------------------+
echo.
echo  Enter a short label for this run (helps you identify it later).
echo  Examples:  Before   After_driver   Baseline   After_format
echo.
set /p LABEL="  Label (press Enter for auto): "
if "%LABEL%"=="" (
    for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set "DT2=%%I"
    set "LABEL=Test_!DT2:~0,8!_!DT2:~8,4!"
)

:MENU_CONFIRM
cls
echo.
echo  +---------------------------------------------------+
echo  ^|  READY TO START                                  ^|
echo  +---------------------------------------------------+
echo.
echo    Disk type  : %DT%
echo    Label      : %LABEL%
echo    Drive      : You will be asked to pick a drive in the next step
echo.
echo  The script will:
echo    1. Show all available drives with their names and sizes
echo    2. Ask you to pick which drive to benchmark
echo    3. Download DiskSpd automatically if needed
echo    4. Request Administrator privileges (click Yes)
echo    5. Run warmup + 4 benchmark phases
echo    6. Save a JSON file to your Desktop
echo.
echo  Estimated time: 5-20 minutes depending on disk type.
echo.
echo    [Y]  Start now
echo    [N]  Go back
echo.
set /p CONFIRM="  Choice (Y/N): "
if /i "%CONFIRM%"=="Y" goto RUN
if /i "%CONFIRM%"=="N" goto MENU_DISKTYPE
goto MENU_CONFIRM

:RUN
cls
echo.
echo  Starting... A UAC prompt may appear - click Yes to allow Administrator access.
echo.
timeout /t 2 >nul

powershell.exe -NoProfile -ExecutionPolicy Bypass ^
    -File "%PS1%" ^
    -DiskType "%DT%" ^
    -Label "%LABEL%"

if errorlevel 1 (
    echo.
    echo  -------------------------------------------------------
    echo  The benchmark exited with an error.  Common causes:
    echo    - UAC was cancelled  (click Yes when prompted)
    echo    - No internet for DiskSpd download
    echo    - Not enough free space on the drive
    echo.
    echo  You can also right-click this .bat and choose
    echo  "Run as administrator" to skip the UAC prompt.
    echo  -------------------------------------------------------
    echo.
    pause
)
exit /b 0
