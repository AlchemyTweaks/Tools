# ============================================================
#  Game Ping Monitor - Endpoint RTT Edition
#  Supports: Fortnite, Valorant, CS2, Apex, Warzone, OW2
#  - Auto-elevates to Administrator
#  - Detects public endpoints from the game's own process
#  - Observes all candidate endpoints for a few seconds
#  - Scores the most stable endpoint instead of taking the first one
#  - Measures endpoint RTT with protocol-aware fallbacks
#  - Tracks measurement method per sample
#  - Tracks endpoint changes during the session
#  - Keeps warmup excluded from summary stats
#  - Writes beginner-friendly summary + advanced export sections
#  - [P] Pause/Resume   [Q] Quit + Export
#
#  Positioning:
#  - Network Benchmark mode = raw network benchmark (throughput/jitter/loss)
#  - Game Latency mode      = latency monitor toward a detected game server
#  - This tool is designed for BEFORE/AFTER comparison and may not match
#    the game's own ping counter exactly.
# ============================================================

# -- Auto-elevate to Administrator -------------------------------------------
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]"Administrator")) {
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# -- Resolve output directory -------------------------------------------------
if ($PSScriptRoot -and (Test-Path $PSScriptRoot)) {
    $outputDir = $PSScriptRoot
} elseif ($MyInvocation.MyCommand.Path) {
    $outputDir = Split-Path -Parent $MyInvocation.MyCommand.Path
} else {
    $outputDir = [Environment]::GetFolderPath("Desktop")
    Write-Host "[!] Could not determine script path. Saving output to Desktop." -ForegroundColor Yellow
}

# -- Settings ----------------------------------------------------------------
$RECOMMENDED_SAMPLES       = 60
$RECOMMENDED_SECONDS       = 60
$INTERVAL_MS               = 1000
$ENDPOINT_OBSERVE_SECONDS  = 8
$ENDPOINT_OBSERVE_INTERVAL = 1000
$ENDPOINT_RECHECK_SEC      = 15
$ENDPOINT_RESELECT_SECONDS = 3
$WARMUP_SECONDS            = 10
$FAILED_SAMPLE             = 9999
$COMMON_SERVICE_PORTS      = @(53, 80, 123, 443, 3478, 3479, 3480, 5222, 8080, 8443)
$POSITIONING_NOTE          = "This tool measures latency toward the server detected from the game. It is designed for BEFORE/AFTER comparison and may not match the game's own ping counter exactly."
$BENCHMARK_SCOPE_NOTE      = "Network Benchmark mode = raw network benchmark (throughput, jitter, packet loss, bufferbloat)"
$MONITOR_SCOPE_NOTE        = "Game Latency mode = latency monitor toward the detected game server for BEFORE/AFTER comparison"
$BENCHMARK_REGIONS         = [ordered]@{
    "1" = @{ Name = "US East"; Servers = @("atl.speedtest.clouvider.net", "dal.speedtest.clouvider.net", "iperf.he.net") }
    "2" = @{ Name = "US West"; Servers = @("la.speedtest.clouvider.net", "dal.speedtest.clouvider.net") }
    "3" = @{ Name = "EU";      Servers = @("lon.speedtest.clouvider.net", "bouygues.iperf.fr") }
    "4" = @{ Name = "Asia";    Servers = @("la.speedtest.clouvider.net", "lon.speedtest.clouvider.net") }
}

# -- Known game EXE names -----------------------------------------------------
$gameProcesses = @{
    "FortniteClient-Win64-Shipping" = "Fortnite"
    "VALORANT-Win64-Shipping"       = "Valorant"
    "cs2"                           = "CS2"
    "r5apex"                        = "Apex Legends"
    "ModernWarfare"                 = "Warzone"
    "Overwatch"                     = "Overwatch 2"
}

$tcpGames = @()

function Test-PublicIPv4([string]$ip) {
    return $ip -match '^\d+\.\d+\.\d+\.\d+$' -and
        $ip -notmatch '^(0\.|10\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.|127\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|224\.|23\d\.|24\d\.|25[0-5]\.)'
}

function Get-RunningGame {
    foreach ($exe in $gameProcesses.Keys) {
        $proc = Get-Process -Name $exe -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($proc) {
            return @{
                ProcessId = $proc.Id
                Name      = $gameProcesses[$exe]
                EXE       = $exe
            }
        }
    }
    return $null
}

function Test-ProcessAlive([int]$processId) {
    return $null -ne (Get-Process -Id $processId -ErrorAction SilentlyContinue)
}

function Format-YesNo([bool]$value) {
    if ($value) { return "Yes" }
    return "No"
}

function Format-Sec([double]$seconds) {
    if ($seconds -lt 0) { $seconds = 0 }
    return ("{0:N0}s" -f [math]::Round($seconds, 0))
}

function Get-EndpointKey($candidate) {
    return ("{0}|{1}|{2}" -f $candidate.Proto, $candidate.IP, $candidate.Port)
}

function Get-EndpointDisplay($candidate) {
    return ("{0} {1}:{2}" -f $candidate.Proto, $candidate.IP, $candidate.Port)
}

function Get-EndpointHeuristicBonus($candidate, [bool]$preferTcpOnly) {
    $bonus = 0

    if ($candidate.Port -ge 1024) { $bonus += 6 }
    if ($candidate.Port -ge 7000) { $bonus += 4 }

    if ($COMMON_SERVICE_PORTS -contains $candidate.Port) {
        $bonus -= 8
    } else {
        $bonus += 8
    }

    if ($preferTcpOnly -and $candidate.Proto -eq "TCP") {
        $bonus += 12
    } elseif (-not $preferTcpOnly -and $candidate.Proto -eq "UDP") {
        $bonus += 10
    }

    return $bonus
}

function Get-EndpointConfidenceLabel($primary, $secondary) {
    if (-not $primary) { return "Low" }

    $gap = if ($secondary) { [math]::Round($primary.Score - $secondary.Score, 1) } else { $primary.Score }

    if ($primary.PresencePct -ge 60 -and $primary.StabilityPct -ge 45 -and $gap -ge 8) {
        return "High"
    }

    if ($primary.PresencePct -ge 35 -and $primary.StabilityPct -ge 20) {
        return "Medium"
    }

    return "Low"
}

function Get-StabilityLabel([int]$changeCount, [double]$longestStableSec, [double]$totalSec) {
    if ($totalSec -le 0) { return "Unknown" }

    $stableShare = $longestStableSec / $totalSec
    if ($changeCount -le 1 -and $stableShare -ge 0.7) { return "Good" }
    if ($changeCount -le 2 -and $stableShare -ge 0.4) { return "Moderate" }
    return "Poor"
}

function Get-MethodStabilityLabel([int]$switchCount, [double]$primaryPct) {
    if ($switchCount -eq 0 -and $primaryPct -ge 85) { return "Stable" }
    if ($switchCount -le 2 -and $primaryPct -ge 60) { return "Moderate" }
    return "Unstable"
}

function New-EndpointCandidate([string]$proto, [string]$ip, [int]$port, [string]$source) {
    $measurementLabel = if ($proto -eq "UDP") { "ICMP primary, TCP fallback" } else { "TCP-Port primary, TCP-443 fallback" }

    [pscustomobject]@{
        Proto          = $proto
        IP             = $ip
        Port           = $port
        Source         = $source
        Measurement    = $measurementLabel
        SeenCount      = 0
        CurrentStreak  = 0
        MaxStreak      = 0
        FirstSeenTick  = 0
        LastSeenTick   = 0
        PresencePct    = 0
        StabilityPct   = 0
        SpanPct        = 0
        HeuristicBonus = 0
        Score          = 0
    }
}

function Get-MeasurementProfile($conn) {
    if ($conn.Proto -eq "TCP") {
        return [pscustomobject]@{
            Fidelity      = "Exact for the selected TCP endpoint"
            ProtocolBasis = "Native TCP endpoint measurement"
            Summary       = "Measures TCP connect RTT to the detected endpoint and same port. TCP-443 is only used as fallback if needed."
            CompareRule   = "Best compared against sessions that used the same protocol and similar server conditions."
        }
    }

    return [pscustomobject]@{
        Fidelity      = "Approximate for the selected UDP endpoint"
        ProtocolBasis = "UDP endpoint observed, RTT measured with ICMP primary and TCP fallback"
        Summary       = "Measures latency toward the detected server IP. For UDP endpoints the script uses ICMP first because generic UDP RTT is not universally available."
        CompareRule   = "Useful for BEFORE/AFTER testing on the same game, region and mode, but not identical to the in-game ping counter."
    }
}

function Get-ConnectionSnapshot([int]$processId, [bool]$preferTcpOnly) {
    $candidateMap = @{}

    if (-not $preferTcpOnly) {
        $udpLines = netstat -nop UDP 2>$null
        foreach ($line in $udpLines) {
            # Windows UDP netstat can appear in two formats:
            # Format A (with remote):  UDP  local:port  remote:port  PID
            # Format B (listen only):  UDP  local:port  *:*          PID
            # We want Format A with a real remote IP (not * or 0.0.0.0)
            if ($line -match '^\s*UDP\s+(\d+\.\d+\.\d+\.\d+):(\d+)\s+(\d+\.\d+\.\d+\.\d+):(\d+)\s+(\d+)\s*$') {
                $remoteIp   = $Matches[3]
                $remotePort = [int]$Matches[4]
                $ownerPid   = [int]$Matches[5]

                if ($ownerPid -eq $processId -and (Test-PublicIPv4 $remoteIp)) {
                    $key = "UDP|$remoteIp|$remotePort"
                    if (-not $candidateMap.ContainsKey($key)) {
                        $candidateMap[$key] = New-EndpointCandidate "UDP" $remoteIp $remotePort "netstat UDP"
                    }
                }
            }
        }
    }

    $tcpLines = netstat -nop TCP 2>$null
    foreach ($line in $tcpLines) {
        if ($line -match '^\s*TCP\s+(\d+\.\d+\.\d+\.\d+):(\d+)\s+(\d+\.\d+\.\d+\.\d+):(\d+)\s+ESTABLISHED\s+(\d+)\s*$') {
            $remoteIp   = $Matches[3]
            $remotePort = [int]$Matches[4]
            $ownerPid   = [int]$Matches[5]

            if ($ownerPid -eq $processId -and (Test-PublicIPv4 $remoteIp)) {
                $key = "TCP|$remoteIp|$remotePort"
                if (-not $candidateMap.ContainsKey($key)) {
                    $candidateMap[$key] = New-EndpointCandidate "TCP" $remoteIp $remotePort "netstat TCP"
                }
            }
        }
    }

    return @(
        $candidateMap.Values |
            Sort-Object `
                @{ Expression = { if ($_.Proto -eq "UDP") { 0 } else { 1 } }; Descending = $false }, `
                @{ Expression = "Port"; Descending = $true }, `
                @{ Expression = "IP"; Descending = $false }
    )
}

function Observe-GameEndpoints([int]$processId, [string]$gameEXE, [int]$observeSeconds = $ENDPOINT_OBSERVE_SECONDS, [int]$intervalMs = $ENDPOINT_OBSERVE_INTERVAL, $preferredConn = $null) {
    $preferTcpOnly = $tcpGames -contains $gameEXE
    $candidateMap  = @{}
    $tickCount     = [math]::Max(1, [int][math]::Ceiling(($observeSeconds * 1000) / $intervalMs))
    $completedTicks = 0

    for ($tick = 1; $tick -le $tickCount; $tick++) {
        if (-not (Test-ProcessAlive $processId)) { break }

        $snapshot    = @(Get-ConnectionSnapshot $processId $preferTcpOnly)
        $presentKeys = @{}
        $completedTicks = $tick

        foreach ($endpoint in $snapshot) {
            $key = Get-EndpointKey $endpoint
            $presentKeys[$key] = $true

            if (-not $candidateMap.ContainsKey($key)) {
                $candidateMap[$key] = New-EndpointCandidate $endpoint.Proto $endpoint.IP $endpoint.Port $endpoint.Source
                $candidateMap[$key].FirstSeenTick = $tick
            }

            $entry = $candidateMap[$key]
            $entry.SeenCount++
            $entry.CurrentStreak++
            if ($entry.CurrentStreak -gt $entry.MaxStreak) {
                $entry.MaxStreak = $entry.CurrentStreak
            }
            $entry.LastSeenTick = $tick
        }

        foreach ($key in @($candidateMap.Keys)) {
            if (-not $presentKeys.ContainsKey($key)) {
                $candidateMap[$key].CurrentStreak = 0
            }
        }

        if ($tick -lt $tickCount) {
            Start-Sleep -Milliseconds $intervalMs
        }
    }

    if ($completedTicks -eq 0) {
        return [pscustomobject]@{
            ObservedSeconds = 0
            Ticks           = 0
            Candidates      = @()
            Primary         = $null
            Confidence      = "Low"
        }
    }

    $preferredKey = if ($preferredConn) { Get-EndpointKey $preferredConn } else { $null }
    $candidates   = @($candidateMap.Values)

    foreach ($candidate in $candidates) {
        $spanTicks = [math]::Max(1, $candidate.LastSeenTick - $candidate.FirstSeenTick + 1)
        $preferredBonus = if ($preferredKey -and (Get-EndpointKey $candidate) -eq $preferredKey) { 12 } else { 0 }

        $candidate.PresencePct    = [math]::Round(($candidate.SeenCount / $completedTicks) * 100, 1)
        $candidate.StabilityPct   = [math]::Round(($candidate.MaxStreak / $completedTicks) * 100, 1)
        $candidate.SpanPct        = [math]::Round(($spanTicks / $completedTicks) * 100, 1)
        $candidate.HeuristicBonus = Get-EndpointHeuristicBonus $candidate $preferTcpOnly
        $candidate.Score          = [math]::Round(
            ($candidate.PresencePct * 0.50) +
            ($candidate.StabilityPct * 0.25) +
            ($candidate.SpanPct * 0.15) +
            $candidate.HeuristicBonus +
            $preferredBonus,
            1
        )
    }

    $sorted = @(
        $candidates |
            Sort-Object `
                @{ Expression = "Score"; Descending = $true }, `
                @{ Expression = "PresencePct"; Descending = $true }, `
                @{ Expression = "StabilityPct"; Descending = $true }, `
                @{ Expression = "Port"; Descending = $true }, `
                @{ Expression = "IP"; Descending = $false }
    )

    $primary    = if ($sorted.Count -gt 0) { $sorted[0] } else { $null }
    $secondary  = if ($sorted.Count -gt 1) { $sorted[1] } else { $null }
    $confidence = Get-EndpointConfidenceLabel $primary $secondary

    return [pscustomobject]@{
        ObservedSeconds = [math]::Round(($completedTicks * $intervalMs) / 1000, 1)
        Ticks           = $completedTicks
        Candidates      = $sorted
        Primary         = $primary
        Confidence      = $confidence
    }
}

function Select-InitialConnection($observation) {
    $candidateList = @($observation.Candidates)
    if ($candidateList.Count -eq 0) { return $null }
    if ($candidateList.Count -eq 1) { return $candidateList[0] }

    $showCount = [Math]::Min(5, $candidateList.Count)

    Write-Host ""
    Write-Host "[*] Endpoint observation finished." -ForegroundColor Yellow
    Write-Host ("    Observation window : {0}s" -f $observation.ObservedSeconds) -ForegroundColor DarkYellow
    Write-Host ("    Detected endpoints : {0}" -f $candidateList.Count) -ForegroundColor DarkYellow
    Write-Host ("    Recommended [1]    : most stable endpoint (confidence {0})" -f $observation.Confidence) -ForegroundColor DarkYellow
    Write-Host "    UDP and TCP RTT should not be compared as if they were the same thing." -ForegroundColor DarkYellow
    Write-Host "    For UDP games the result remains an approximation toward the detected server." -ForegroundColor DarkYellow
    Write-Host ""

    for ($i = 0; $i -lt $showCount; $i++) {
        $candidate = $candidateList[$i]
        Write-Host ("    [{0}] {1} | Seen {2}% | Stable {3}% | Score {4}" -f ($i + 1), (Get-EndpointDisplay $candidate), $candidate.PresencePct, $candidate.StabilityPct, $candidate.Score) -ForegroundColor Gray
    }

    if ($candidateList.Count -gt $showCount) {
        Write-Host "    ...additional lower-priority endpoints omitted." -ForegroundColor DarkGray
    }

    Write-Host ""
    $choice = (Read-Host "  Press ENTER for [1] or type a number").Trim()
    if ($choice -match '^\d+$') {
        $index = [int]$choice - 1
        if ($index -ge 0 -and $index -lt $showCount) {
            return $candidateList[$index]
        }
    }

    return $candidateList[0]
}

function Measure-TCPRTT([string]$ip, [int]$port) {
    $client     = $null
    $waitHandle = $null

    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $sw     = [System.Diagnostics.Stopwatch]::StartNew()
        $async  = $client.BeginConnect($ip, $port, $null, $null)
        $waitHandle = $async.AsyncWaitHandle

        if (-not $waitHandle.WaitOne(2000, $false)) {
            $sw.Stop()
            return $null
        }

        $client.EndConnect($async)
        $sw.Stop()
        return $sw.ElapsedMilliseconds
    } catch {
        return $null
    } finally {
        if ($waitHandle -ne $null) {
            try { $waitHandle.Close() } catch {}
        }

        if ($client -ne $null) {
            try { $client.Close() } catch {}
            try { $client.Dispose() } catch {}
        }
    }
}

function Measure-ICMPRTT([string]$ip) {
    $ping = $null

    try {
        $ping   = New-Object System.Net.NetworkInformation.Ping
        $result = $ping.Send($ip, 2000)
        if ($result.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) {
            return $result.RoundtripTime
        }
    } catch {
        return $null
    } finally {
        if ($ping -ne $null) {
            try { $ping.Dispose() } catch {}
        }
    }

    return $null
}

function Invoke-EndpointMeasurement($conn) {
    $attempts = [System.Collections.Generic.List[object]]::new()
    $attemptNames = [System.Collections.Generic.List[string]]::new()

    if ($conn.Proto -eq "TCP") {
        $attempts.Add([pscustomobject]@{ Method = "TCP-Port"; Port = $conn.Port })
        if ($conn.Port -ne 443) {
            $attempts.Add([pscustomobject]@{ Method = "TCP-443"; Port = 443 })
        }
    } else {
        $attempts.Add([pscustomobject]@{ Method = "ICMP"; Port = $null })
        $attempts.Add([pscustomobject]@{ Method = "TCP-Port"; Port = $conn.Port })
        if ($conn.Port -ne 443) {
            $attempts.Add([pscustomobject]@{ Method = "TCP-443"; Port = 443 })
        }
    }

    for ($i = 0; $i -lt $attempts.Count; $i++) {
        $attempt = $attempts[$i]
        $attemptNames.Add($attempt.Method)
        $rtt = switch ($attempt.Method) {
            "ICMP"     { Measure-ICMPRTT $conn.IP }
            "TCP-Port" { Measure-TCPRTT $conn.IP $attempt.Port }
            "TCP-443"  { Measure-TCPRTT $conn.IP 443 }
            default    { $null }
        }

        if ($rtt -ne $null) {
            return [pscustomobject]@{
                RTT              = $rtt
                Method           = $attempt.Method
                FallbackUsed     = ($i -gt 0)
                FallbackAttempted = ($i -gt 0)
                AttemptSequence  = ($attemptNames -join " > ")
                Success          = $true
                FailureReason    = ""
            }
        }
    }

    $failedMethod = if ($attempts.Count -gt 0) { $attempts[$attempts.Count - 1].Method } else { "None" }

    return [pscustomobject]@{
        RTT              = $null
        Method           = $failedMethod
        FallbackUsed     = ($attempts.Count -gt 1)
        FallbackAttempted = ($attempts.Count -gt 1)
        AttemptSequence  = ($attemptNames -join " > ")
        Success          = $false
        FailureReason    = "Probe blocked or timed out"
    }
}

function Get-Percentile($data, [int]$pct) {
    if (-not $data -or @($data).Count -eq 0) { return $null }
    $sorted = @($data) | Sort-Object
    $index  = [math]::Ceiling(($pct / 100) * $sorted.Count) - 1
    $index  = [math]::Max(0, [math]::Min($index, $sorted.Count - 1))
    return $sorted[$index]
}

function Get-PercentileSet($data) {
    if (-not $data -or $data.Count -eq 0) {
        return [pscustomobject]@{
            P50 = $null
            P90 = $null
            P95 = $null
            P99 = $null
        }
    }

    return [pscustomobject]@{
        P50 = [double](Get-Percentile $data 50)
        P90 = [double](Get-Percentile $data 90)
        P95 = [double](Get-Percentile $data 95)
        P99 = [double](Get-Percentile $data 99)
    }
}

function Compute-Jitter($validData) {
    if ($validData.Count -lt 2) { return 0 }

    $jitterList = [System.Collections.Generic.List[double]]::new()
    for ($i = 1; $i -lt $validData.Count; $i++) {
        $jitterList.Add([math]::Abs($validData[$i] - $validData[$i - 1]))
    }

    return [math]::Round(($jitterList | Measure-Object -Average).Average, 1)
}

function Get-ValidSamples($samples) {
    return @($samples | Where-Object { $_ -ne $FAILED_SAMPLE })
}

function Get-FailureCount($samples) {
    return @($samples | Where-Object { $_ -eq $FAILED_SAMPLE }).Count
}

function Get-LatencyHistogram($validData) {
    $buckets = [ordered]@{
        "<=40" = 0
        "41-50" = 0
        "51-60" = 0
        "61-80" = 0
        "81+" = 0
    }

    foreach ($value in @($validData)) {
        if ($value -le 40) {
            $buckets["<=40"]++
        } elseif ($value -le 50) {
            $buckets["41-50"]++
        } elseif ($value -le 60) {
            $buckets["51-60"]++
        } elseif ($value -le 80) {
            $buckets["61-80"]++
        } else {
            $buckets["81+"]++
        }
    }

    return $buckets
}

function Get-SpikeAnalysis($sampleRecords, $percentiles) {
    $measurementRecords = @($sampleRecords | Where-Object { -not $_.Warmup } | Sort-Object Sequence)
    $validRecords = @($measurementRecords | Where-Object { $_.Success })

    if ($validRecords.Count -eq 0 -or $percentiles.P50 -eq $null) {
        return [pscustomobject]@{
            BaselineMs          = $null
            SpikeThresholdMs    = $null
            BadThresholdMs      = $null
            SpikeCount          = 0
            SpikeRatePct        = 0
            LongestBadStreak    = 0
            TailGapP95P50       = $null
            TailGapP99P50       = $null
            TailRatioP95OverP50 = $null
            BaselineVsTailLabel = "Unavailable"
            Histogram           = Get-LatencyHistogram @()
            AnnotatedSamples    = @()
        }
    }

    $baseline       = [double]$percentiles.P50
    $p90Value       = if ($percentiles.P90 -ne $null) { [double]$percentiles.P90 } else { $baseline }
    $p95Value       = if ($percentiles.P95 -ne $null) { [double]$percentiles.P95 } else { $baseline }
    $p99Value       = if ($percentiles.P99 -ne $null) { [double]$percentiles.P99 } else { $p95Value }
    $spikeThreshold = [math]::Round([math]::Max(($baseline * 1.75), ($baseline + 15)), 1)
    $badThreshold   = [math]::Round([math]::Max($p90Value, ($baseline + 20)), 1)
    $spikeCount     = 0
    $currentBad     = 0
    $longestBad     = 0
    $annotated      = [System.Collections.Generic.List[object]]::new()

    foreach ($record in @($sampleRecords | Sort-Object Sequence)) {
        $isSpike = $false
        $isBad   = $false

        if (-not $record.Warmup -and $record.Success) {
            $recordRtt = [double]$record.RTT
            if ($recordRtt -ge $spikeThreshold) {
                $isSpike = $true
                $spikeCount++
            }

            if ($recordRtt -ge $badThreshold) {
                $isBad = $true
                $currentBad++
                if ($currentBad -gt $longestBad) {
                    $longestBad = $currentBad
                }
            } else {
                $currentBad = 0
            }
        } elseif (-not $record.Warmup) {
            $currentBad = 0
        }

        $record | Add-Member -NotePropertyName Spike -NotePropertyValue $isSpike -Force
        $record | Add-Member -NotePropertyName Bad -NotePropertyValue $isBad -Force

        $annotated.Add([pscustomobject]@{
            seq              = $record.Sequence
            timestamp        = $record.Timestamp
            t_ms             = if ($record.PSObject.Properties.Match("RelativeMs").Count -gt 0 -and $record.RelativeMs -ne $null) { [int]$record.RelativeMs } elseif ($record.PSObject.Properties.Match("ElapsedSec").Count -gt 0 -and $record.ElapsedSec -ne $null) { [int]($record.ElapsedSec * 1000) } else { 0 }
            phase            = if ($record.Warmup) { "warmup" } else { "measure" }
            endpoint         = $record.Endpoint
            endpoint_key     = if ($record.PSObject.Properties.Match("EndpointKey").Count -gt 0) { $record.EndpointKey } else { "" }
            protocol         = $record.Protocol
            method           = $record.Method
            fallback_used    = [bool]$record.FallbackUsed
            success          = [bool]$record.Success
            rtt_ms           = if ($record.Success) { [double]$record.RTT } else { $null }
            spike            = $isSpike
            bad              = $isBad
            attempt_sequence = $record.AttemptSequence
            failure_reason   = $record.FailureReason
        })
    }

    $tailGapP95P50 = [math]::Round(($p95Value - $baseline), 1)
    $tailGapP99P50 = [math]::Round(($p99Value - $baseline), 1)
    $tailRatio     = if ($baseline -gt 0) { [math]::Round(($p95Value / $baseline), 2) } else { $null }
    $spikeRatePct  = [math]::Round(($spikeCount / $validRecords.Count) * 100, 1)
    $tailLabel     = if ($tailRatio -eq $null) {
        "Unavailable"
    } elseif ($tailRatio -le 1.25) {
        "Tight tail"
    } elseif ($tailRatio -le 1.5) {
        "Moderate tail"
    } elseif ($tailRatio -le 1.8) {
        "Elevated tail"
    } else {
        "Heavy tail"
    }

    return [pscustomobject]@{
        BaselineMs          = $baseline
        SpikeThresholdMs    = $spikeThreshold
        BadThresholdMs      = $badThreshold
        SpikeCount          = $spikeCount
        SpikeRatePct        = $spikeRatePct
        LongestBadStreak    = $longestBad
        TailGapP95P50       = $tailGapP95P50
        TailGapP99P50       = $tailGapP99P50
        TailRatioP95OverP50 = $tailRatio
        BaselineVsTailLabel = $tailLabel
        Histogram           = Get-LatencyHistogram ($validRecords | ForEach-Object { [double]$_.RTT })
        AnnotatedSamples    = @($annotated)
    }
}

function Get-SessionValidity([int]$validSampleCount, [double]$failureRate, [string]$endpointConfidence, [bool]$selectedRecommended, [string]$connectionStability, $methodStats, $spikeAnalysis) {
    $score   = 0
    $reasons = [System.Collections.Generic.List[string]]::new()
    $caveats = [System.Collections.Generic.List[string]]::new()

    if ($validSampleCount -ge 60) {
        $score += 25
        $reasons.Add("Sample count is strong ($validSampleCount valid samples).")
    } elseif ($validSampleCount -ge 40) {
        $score += 20
        $reasons.Add("Sample count is usable ($validSampleCount valid samples).")
    } elseif ($validSampleCount -ge 25) {
        $score += 12
        $caveats.Add("Sample count is below the ideal comparison target.")
    } elseif ($validSampleCount -gt 0) {
        $score += 5
        $caveats.Add("Very few valid samples were captured.")
    } else {
        $caveats.Add("No valid latency samples were captured.")
    }

    switch ($endpointConfidence) {
        "High"   { $score += 15; $reasons.Add("Endpoint detection confidence is high.") }
        "Medium" { $score += 10; $reasons.Add("Endpoint detection confidence is moderate.") }
        default  { $score += 4;  $caveats.Add("Endpoint detection confidence is low.") }
    }

    if ($selectedRecommended) {
        $score += 4
    } else {
        $score += 2
        $caveats.Add("A manual endpoint override was selected.")
    }

    switch ($connectionStability) {
        "Good"     { $score += 6; $reasons.Add("Endpoint remained stable for most of the run.") }
        "Moderate" { $score += 3; $caveats.Add("Endpoint stability was only moderate.") }
        "Poor"     { $caveats.Add("Endpoint changed often during the run.") }
    }

    if ($methodStats.PrimaryMethod -eq "None") {
        $caveats.Add("No successful primary measurement method was established.")
    } else {
        if ($methodStats.PrimaryPct -ge 85) {
            $score += 10
            $reasons.Add("Measurement method stayed mostly consistent.")
        } elseif ($methodStats.PrimaryPct -ge 60) {
            $score += 7
            $caveats.Add("Measurement method was mixed during the run.")
        } else {
            $score += 3
            $caveats.Add("Measurement method changed frequently.")
        }

        if ($methodStats.SwitchCount -eq 0) {
            $score += 6
        } elseif ($methodStats.SwitchCount -le 2) {
            $score += 3
        } else {
            $caveats.Add("Several method switches were observed.")
        }

        if (-not $methodStats.FallbackOccurred) {
            $score += 4
            $reasons.Add("No fallback probe was needed.")
        } else {
            $score += 1
            $caveats.Add("Fallback probing was needed.")
        }
    }

    if ($failureRate -le 2) {
        $score += 15
        $reasons.Add("Failed RTT burden is very low.")
    } elseif ($failureRate -le 5) {
        $score += 11
    } elseif ($failureRate -le 10) {
        $score += 7
        $caveats.Add("Failed RTT burden is noticeable.")
    } elseif ($failureRate -le 20) {
        $score += 3
        $caveats.Add("Failed RTT burden is high.")
    } else {
        $caveats.Add("Failed RTT burden is very high.")
    }

    if ($spikeAnalysis.SpikeRatePct -le 5 -and $spikeAnalysis.LongestBadStreak -le 1) {
        $score += 15
        $reasons.Add("Latency tail is controlled with few spikes.")
    } elseif ($spikeAnalysis.SpikeRatePct -le 10 -and $spikeAnalysis.LongestBadStreak -le 2) {
        $score += 11
    } elseif ($spikeAnalysis.SpikeRatePct -le 20) {
        $score += 7
        $caveats.Add("Latency spikes are present but still interpretable.")
    } else {
        $score += 3
        $caveats.Add("Spike burden is high and weakens the run.")
    }

    if ($spikeAnalysis.BaselineVsTailLabel -eq "Heavy tail") {
        $caveats.Add("P95 is much higher than baseline, so the tail is heavy.")
    } elseif ($spikeAnalysis.BaselineVsTailLabel -eq "Elevated tail") {
        $caveats.Add("The latency tail is elevated.")
    }

    $score = [math]::Max(0, [math]::Min(100, [int][math]::Round($score, 0)))
    $class = if ($score -ge 85) {
        "High"
    } elseif ($score -ge 70) {
        "Usable"
    } elseif ($score -ge 55) {
        "Caveated"
    } else {
        "Low"
    }

    return [pscustomobject]@{
        Score           = $score
        ConfidenceClass = $class
        Reasons         = @($reasons)
        Caveats         = @($caveats)
    }
}

function Get-BenchmarkValidity($tcpResult, $udpResult, $tcpSummary, $udpSummary, $idleStats, $loadedStats, $latencyIncrease) {
    $score   = 0
    $reasons = [System.Collections.Generic.List[string]]::new()
    $caveats = [System.Collections.Generic.List[string]]::new()

    if ($tcpResult.ExitCode -eq 0) {
        $score += 20
        $reasons.Add("TCP throughput test completed successfully.")
    } else {
        $caveats.Add("TCP throughput test reported a non-zero exit code.")
    }

    if ($udpResult.ExitCode -eq 0) {
        $score += 20
        $reasons.Add("UDP jitter/loss test completed successfully.")
    } else {
        $caveats.Add("UDP jitter/loss test reported a non-zero exit code.")
    }

    if ($tcpSummary.ThroughputMbps -ne $null) {
        if ($tcpSummary.Retransmits -ne $null) {
            $score += 15
        } else {
            $score += 10
            $caveats.Add("Retransmission count unavailable (iperf3 server did not report it - result is still valid).")
        }
    } else {
        $caveats.Add("TCP summary data is incomplete.")
    }

    if ($udpSummary.JitterMs -ne $null -and $udpSummary.LossPct -ne $null) {
        $score += 15
    } else {
        $caveats.Add("UDP summary data is incomplete.")
    }

    if ($idleStats.Success -ge 8) {
        $score += 15
        $reasons.Add("Idle latency baseline has enough ping samples.")
    } elseif ($idleStats.Success -gt 0) {
        $score += 8
        $caveats.Add("Idle latency baseline has only partial ping coverage.")
    } else {
        $caveats.Add("Idle latency baseline has no valid ping samples.")
    }

    if ($loadedStats.Success -ge 12) {
        $score += 15
        $reasons.Add("Loaded latency phase has enough ping samples.")
    } elseif ($loadedStats.Success -gt 0) {
        $score += 8
        $caveats.Add("Loaded latency phase has only partial ping coverage.")
    } else {
        $caveats.Add("Loaded latency phase has no valid ping samples.")
    }

    if ($latencyIncrease -ne $null) {
        $score += 10
    } else {
        $caveats.Add("Bufferbloat delta could not be derived.")
    }

    $score = [math]::Max(0, [math]::Min(100, [int][math]::Round($score, 0)))
    $class = if ($score -ge 85) {
        "High"
    } elseif ($score -ge 70) {
        "Usable"
    } elseif ($score -ge 55) {
        "Caveated"
    } else {
        "Low"
    }

    return [pscustomobject]@{
        Score           = $score
        ConfidenceClass = $class
        Reasons         = @($reasons)
        Caveats         = @($caveats)
    }
}

function Get-MethodStats($sampleRecords) {
    $records = @($sampleRecords | Where-Object { -not $_.Warmup })
    $successful = @($records | Where-Object { $_.Success })
    $methodCounts = @{
        "ICMP"     = 0
        "TCP-Port" = 0
        "TCP-443"  = 0
    }

    foreach ($record in $successful) {
        if ($methodCounts.ContainsKey($record.Method)) {
            $methodCounts[$record.Method]++
        }
    }

    $successCount = $successful.Count
    $icmpPct = if ($successCount -gt 0) { [math]::Round(($methodCounts["ICMP"] / $successCount) * 100, 1) } else { 0 }
    $tcpPortPct = if ($successCount -gt 0) { [math]::Round(($methodCounts["TCP-Port"] / $successCount) * 100, 1) } else { 0 }
    $tcp443Pct = if ($successCount -gt 0) { [math]::Round(($methodCounts["TCP-443"] / $successCount) * 100, 1) } else { 0 }

    $ordered = @(
        $methodCounts.GetEnumerator() |
            Sort-Object `
                @{ Expression = "Value"; Descending = $true }, `
                @{ Expression = "Name"; Descending = $false }
    )
    $primaryMethod = if ($successCount -gt 0 -and $ordered.Count -gt 0 -and $ordered[0].Value -gt 0) { [string]$ordered[0].Key } else { "None" }
    $primaryPct = if ($primaryMethod -ne "None") { [math]::Round(($methodCounts[$primaryMethod] / $successCount) * 100, 1) } else { 0 }

    $switchCount = 0
    $lastMethod  = $null
    foreach ($record in ($successful | Sort-Object Sequence)) {
        if ($lastMethod -and $record.Method -ne $lastMethod) {
            $switchCount++
        }
        $lastMethod = $record.Method
    }

    $fallbackOccurred = (@($records | Where-Object { $_.FallbackUsed }).Count -gt 0)

    return [pscustomobject]@{
        SuccessCount      = $successCount
        ICMPPct           = $icmpPct
        TCPPortPct        = $tcpPortPct
        TCP443Pct         = $tcp443Pct
        ICMPCount         = $methodCounts["ICMP"]
        TCPPortCount      = $methodCounts["TCP-Port"]
        TCP443Count       = $methodCounts["TCP-443"]
        SwitchCount       = $switchCount
        PrimaryMethod     = $primaryMethod
        PrimaryPct        = $primaryPct
        FallbackOccurred  = $fallbackOccurred
        FallbackCount     = @($records | Where-Object { $_.FallbackUsed }).Count
        StabilityLabel    = Get-MethodStabilityLabel $switchCount $primaryPct
    }
}

function Get-MeasurementDescription($conn, $methodStats) {
    if ($methodStats -and $methodStats.PrimaryMethod -and $methodStats.PrimaryMethod -ne "None") {
        return ("{0} primary ({1}% of successful samples)" -f $methodStats.PrimaryMethod, $methodStats.PrimaryPct)
    }

    if ($conn.Proto -eq "TCP") {
        return "TCP-Port primary"
    }

    return "ICMP primary"
}

function Get-ComparisonWarnings([string]$endpointConfidence, $methodStats, [int]$serverChangeCount, [string]$connectionStability) {
    $warnings = [System.Collections.Generic.List[string]]::new()

    if ($methodStats.SwitchCount -gt 0) {
        $warnings.Add("Warning: Different measurement method was used during this run.")
    }

    if ($methodStats.FallbackOccurred) {
        $warnings.Add("Warning: Fallback measurement was needed during this run.")
    }

    if ($serverChangeCount -ge 2) {
        $warnings.Add("Warning: The server changed many times during this run.")
    }

    if ($endpointConfidence -eq "Low") {
        $warnings.Add("Warning: Endpoint detection confidence is low for this run.")
    }

    if ($connectionStability -eq "Poor") {
        $warnings.Add("Warning: Connection stability was poor because the endpoint changed often.")
    }

    return @($warnings)
}

function Resolve-IperfBundle {
    $userProfile = [Environment]::GetFolderPath("UserProfile")
    $downloads   = Join-Path $userProfile "Downloads"
    $desktop     = [Environment]::GetFolderPath("Desktop")
    $searchPaths = @(
        (Join-Path $outputDir "iperf3.exe"),
        (Join-Path $desktop "iperf3.exe"),
        (Join-Path $downloads "iperf3.exe")
    )

    $seen = @{}
    foreach ($path in $searchPaths) {
        if (-not $path -or $seen.ContainsKey($path)) { continue }
        $seen[$path] = $true

        if (Test-Path $path) {
            $dir = Split-Path -Parent $path
            $dll = Join-Path $dir "cygwin1.dll"
            return [pscustomobject]@{
                ExePath = $path
                DirPath = $dir
                DllPath = $dll
                HasDll  = (Test-Path $dll)
            }
        }
    }

    return $null
}

function Invoke-IperfCapture([string]$iperfExe, [string[]]$arguments, [switch]$RetryIfBusy) {
    $attempt = 0
    $maxAttempts = if ($RetryIfBusy) { 3 } else { 1 }

    while ($true) {
        $attempt++
        $lines    = & $iperfExe @arguments 2>&1
        $exitCode = $LASTEXITCODE
        $text     = (($lines | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine).TrimEnd()

        $isTransient = ($text -match 'server is busy') -or
                       ($text -match 'unable to connect') -or
                       ($text -match 'Connection refused') -or
                       ($text -match 'timed out') -or
                       ($exitCode -ne 0 -and $text -match 'error')

        if ($RetryIfBusy -and $isTransient -and $attempt -lt $maxAttempts) {
            $waitSec = if ($text -match 'server is busy') { 10 } else { 5 }
            Write-Host ("  [*] Connection issue, waiting {0}s and retrying (attempt {1}/{2})..." -f $waitSec, $attempt, $maxAttempts) -ForegroundColor DarkYellow
            Start-Sleep -Seconds $waitSec
            continue
        }

        return [pscustomobject]@{
            ExitCode = $exitCode
            Output   = $text
        }
    }
}

function Test-IperfServer([string]$iperfExe, [string]$server) {
    # Two attempts with a short gap - one dropped probe no longer blacklists a healthy server
    for ($attempt = 1; $attempt -le 2; $attempt++) {
        $probe = Invoke-IperfCapture $iperfExe @("-c", $server, "-t", "2", "--connect-timeout", "6000")
        if ($probe.ExitCode -eq 0) { return $true }
        if ($attempt -lt 2) { Start-Sleep -Seconds 3 }
    }
    return $false
}

function Find-BenchmarkServer([string]$iperfExe, [hashtable]$regionInfo) {
    $tried = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)

    # Pass 1: preferred region
    foreach ($server in @($regionInfo.Servers)) {
        if (-not $server) { continue }
        $tried.Add($server) | Out-Null
        Write-Host ("     Testing {0} ..." -f $server) -ForegroundColor Gray
        if (Test-IperfServer $iperfExe $server) {
            Write-Host ("     Connected to {0}" -f $server) -ForegroundColor Green
            return $server
        }
        Write-Host ("     {0} not responding, trying next..." -f $server) -ForegroundColor DarkYellow
    }

    # Pass 2: cross-region fallback
    Write-Host "" 
    Write-Host "  [!] No servers responded in the selected region." -ForegroundColor Yellow
    Write-Host "  [*] Trying servers from other regions as fallback..." -ForegroundColor Yellow
    foreach ($region in $BENCHMARK_REGIONS.Values) {
        foreach ($server in @($region.Servers)) {
            if (-not $server -or $tried.Contains($server)) { continue }
            $tried.Add($server) | Out-Null
            Write-Host ("     Testing {0} ({1}) ..." -f $server, $region.Name) -ForegroundColor Gray
            if (Test-IperfServer $iperfExe $server) {
                Write-Host ("     Connected to {0} (fallback from {1})" -f $server, $region.Name) -ForegroundColor Yellow
                return $server
            }
            Write-Host ("     {0} not responding." -f $server) -ForegroundColor DarkYellow
        }
    }

    return $null
}

function Get-PingSampleStats([string]$target, [int]$count, [int]$delayMs = 1000) {
    $samples = [System.Collections.Generic.List[double]]::new()
    $details = [System.Collections.Generic.List[string]]::new()
    $ping    = $null

    try {
        $ping = New-Object System.Net.NetworkInformation.Ping
        for ($i = 1; $i -le $count; $i++) {
            try {
                $reply = $ping.Send($target, 2000)
                if ($reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) {
                    $samples.Add([double]$reply.RoundtripTime)
                    $details.Add(("  Sample {0:D2}: {1} ms" -f $i, $reply.RoundtripTime))
                } else {
                    $details.Add(("  Sample {0:D2}: failed ({1})" -f $i, $reply.Status))
                }
            } catch {
                $details.Add(("  Sample {0:D2}: failed ({1})" -f $i, $_.Exception.Message))
            }

            if ($i -lt $count) {
                Start-Sleep -Milliseconds $delayMs
            }
        }
    } finally {
        if ($ping -ne $null) {
            try { $ping.Dispose() } catch {}
        }
    }

    $validSamples = @($samples)
    $avg = if ($validSamples.Count -gt 0) {
        [math]::Round(($validSamples | Measure-Object -Average).Average, 1)
    } else {
        $null
    }

    return [pscustomobject]@{
        Count   = $count
        Success = $validSamples.Count
        Samples = $validSamples
        Details = @($details)
        Min     = if ($validSamples.Count -gt 0) { ($validSamples | Measure-Object -Minimum).Minimum } else { $null }
        Max     = if ($validSamples.Count -gt 0) { ($validSamples | Measure-Object -Maximum).Maximum } else { $null }
        Avg     = $avg
    }
}

function Get-LastIperfMatchValue([string]$text, [string]$pattern, [int]$groupIndex) {
    $matches = [regex]::Matches($text, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($matches.Count -eq 0) { return $null }
    return $matches[$matches.Count - 1].Groups[$groupIndex].Value
}

function Convert-IperfRateToMbps([string]$value, [string]$unit) {
    if (-not $value) { return $null }

    $rate = [double]$value
    $resolvedUnit = if ($unit) { $unit } else { "M" }
    switch ($resolvedUnit.ToUpperInvariant()) {
        "G" { return [math]::Round($rate * 1000, 1) }
        "K" { return [math]::Round($rate / 1000, 3) }
        default { return [math]::Round($rate, 1) }
    }
}

function Get-TcpBenchmarkSummary([string]$iperfOutput) {
    # Try JSON parse first (retransmits always present in iperf3 JSON output).
    # Many servers omit retransmit count from plain-text sender summary line.
    # Safety: validate the parsed object has the expected structure before using it.
    $retransmitsFromJson = $null
    $throughputFromJson  = $null
    try {
        # Find outermost JSON object - avoid matching nested {} from error messages
        $jsonMatch = [regex]::Match($iperfOutput, '(?s)\{.*\}')
        if ($jsonMatch.Success) {
            $parsed = $jsonMatch.Value | ConvertFrom-Json -ErrorAction Stop
            # Only use if the expected iperf3 result structure is present
            if ($parsed.PSObject.Properties.Name -contains 'end' -and
                $parsed.end.PSObject.Properties.Name -contains 'sum_sent') {
                $tcpEnd = $parsed.end.sum_sent
                if ($tcpEnd -ne $null) {
                    # retransmits can legitimately be 0 - use explicit null check on property existence
                    if ($tcpEnd.PSObject.Properties.Name -contains 'retransmits') {
                        $retransmitsFromJson = [int]$tcpEnd.retransmits
                    }
                    if ($tcpEnd.PSObject.Properties.Name -contains 'bits_per_second') {
                        $bps = [double]$tcpEnd.bits_per_second
                        if ($bps -gt 0) {
                            $throughputFromJson = [math]::Round($bps / 1000000, 1)
                        }
                    }
                }
            }
        }
    } catch {}

    # Plain-text fallback (always attempted - used if JSON unavailable or incomplete)
    $rateValue = Get-LastIperfMatchValue $iperfOutput '([\d\.]+)\s+([KMG])?bits/sec(?:\s+(\d+))?\s+sender' 1
    $rateUnit  = Get-LastIperfMatchValue $iperfOutput '([\d\.]+)\s+([KMG])?bits/sec(?:\s+(\d+))?\s+sender' 2
    $retrans   = Get-LastIperfMatchValue $iperfOutput '([\d\.]+)\s+([KMG])?bits/sec(?:\s+(\d+))?\s+sender' 3

    $finalThroughput  = if ($throughputFromJson -ne $null) { $throughputFromJson } else { Convert-IperfRateToMbps $rateValue $rateUnit }
    $finalRetransmits = if ($retransmitsFromJson -ne $null) { $retransmitsFromJson } elseif ($retrans) { [int]$retrans } else { $null }

    return [pscustomobject]@{
        ThroughputMbps = $finalThroughput
        Retransmits    = $finalRetransmits
        RetransmitsSource = if ($retransmitsFromJson -ne $null) { "JSON" } elseif ($retrans) { "plain-text" } else { "unavailable" }
    }
}

function Get-UdpBenchmarkSummary([string]$iperfOutput) {
    $pattern  = '([\d\.]+)\s+([KMG])?bits/sec\s+([\d\.]+)\s+ms\s+\d+/\d+\s+\(([\d\.]+)%\)\s+(sender|receiver)'
    $matches  = [regex]::Matches($iperfOutput, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    $selected = $null

    foreach ($match in $matches) {
        if ($match.Groups[5].Value -match 'receiver') {
            $selected = $match
        }
    }

    if (-not $selected -and $matches.Count -gt 0) {
        $selected = $matches[$matches.Count - 1]
    }

    if (-not $selected) {
        return [pscustomobject]@{
            JitterMs = $null
            LossPct  = $null
        }
    }

    return [pscustomobject]@{
        JitterMs = [double]$selected.Groups[3].Value
        LossPct  = [double]$selected.Groups[4].Value
    }
}

function Start-NetworkBenchmark {
    $bundle = Resolve-IperfBundle
    if (-not $bundle -or -not (Test-Path $bundle.ExePath)) {
        Write-Host ""
        Write-Host "[ERROR] iperf3.exe was not found." -ForegroundColor Red
        Write-Host "        Place iperf3.exe and cygwin1.dll next to this script or keep them in Downloads." -ForegroundColor Yellow
        return
    }

    if (-not $bundle.HasDll) {
        Write-Host ""
        Write-Host "[ERROR] cygwin1.dll was not found next to iperf3.exe." -ForegroundColor Red
        Write-Host ("        iperf3.exe path: {0}" -f $bundle.ExePath) -ForegroundColor Yellow
        return
    }

    Clear-Host
    Write-Host ""
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "    NETWORK BENCHMARK  [IPERF3 + ICMP]" -ForegroundColor Cyan
    Write-Host "  TCP / UDP / Bufferbloat BEFORE-AFTER" -ForegroundColor DarkCyan
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host " This mode runs the raw network benchmark:" -ForegroundColor Yellow
    Write-Host "   TCP throughput + retransmissions" -ForegroundColor Gray
    Write-Host "   UDP jitter + packet loss" -ForegroundColor Gray
    Write-Host "   Bufferbloat (idle vs loaded latency)" -ForegroundColor Gray
    Write-Host ""
    Write-Host (" iperf3 bundle : {0}" -f $bundle.ExePath) -ForegroundColor DarkGray
    Write-Host ""

    do {
        Write-Host " Is this a BEFORE or AFTER benchmark?" -ForegroundColor Yellow
        Write-Host "   B = Before changes" -ForegroundColor Gray
        Write-Host "   A = After changes" -ForegroundColor Gray
        $phaseChoice = ((Read-Host "  Enter B or A").Trim()).ToUpperInvariant()
    } until ($phaseChoice -in @("B", "A"))
    $phaseLabel = if ($phaseChoice -eq "B") { "BEFORE" } else { "AFTER" }

    Write-Host ""
    Write-Host " Select benchmark region:" -ForegroundColor Yellow
    foreach ($regionKey in $BENCHMARK_REGIONS.Keys) {
        Write-Host ("   {0} = {1}" -f $regionKey, $BENCHMARK_REGIONS[$regionKey].Name) -ForegroundColor Gray
    }

    do {
        $regionChoice = (Read-Host "  Enter 1-4").Trim()
    } until ($BENCHMARK_REGIONS.Contains($regionChoice))
    $regionInfo = $BENCHMARK_REGIONS[$regionChoice]

    $timestamp  = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
    $outputFile = Join-Path $outputDir ("{0}_results_{1}.txt" -f $phaseLabel, $timestamp)

    Write-Host ""
    Write-Host ("[*] Region: {0}" -f $regionInfo.Name) -ForegroundColor Yellow
    Write-Host "[*] Finding a responsive server..." -ForegroundColor Yellow

    $server = Find-BenchmarkServer $bundle.ExePath $regionInfo
    if (-not $server) {
        Write-Host ""
        Write-Host ("[ERROR] No servers responded in {0}." -f $regionInfo.Name) -ForegroundColor Red
        return
    }

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " TEST 1/3: TCP Throughput" -ForegroundColor Cyan
    Write-Host " Duration: 30 seconds" -ForegroundColor DarkCyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    # Plain-text run: shows live progress on screen and goes into the txt report
    $tcpResult  = Invoke-IperfCapture $bundle.ExePath @("-c", $server, "-t", "30", "-P", "4", "--connect-timeout", "10000") -RetryIfBusy
    Write-Host $tcpResult.Output
    # Silent JSON run: used ONLY to extract retransmits (invisible to user, short 8s)
    Write-Host " [*] Collecting retransmit data..." -ForegroundColor DarkGray
    $tcpJson    = Invoke-IperfCapture $bundle.ExePath @("-c", $server, "-t", "8", "-P", "4", "--connect-timeout", "10000", "-J")
    $tcpSummary = Get-TcpBenchmarkSummary ($tcpJson.Output + "`n" + $tcpResult.Output)

    # IMPORTANT: Wait for the connection to fully cool down before measuring
    # idle latency. If we start too soon, the idle baseline is still elevated
    # from the TCP test, making the bufferbloat delta look smaller than it is.
    Write-Host " [*] Cooling down connection (8s)..." -ForegroundColor DarkGray
    Start-Sleep -Seconds 8

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " TEST 2/3: UDP Jitter And Packet Loss" -ForegroundColor Cyan
    Write-Host " Duration: 15 seconds" -ForegroundColor DarkCyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    $udpResult  = Invoke-IperfCapture $bundle.ExePath @("-c", $server, "-u", "-b", "50M", "-t", "15", "--connect-timeout", "10000") -RetryIfBusy
    $udpSummary = Get-UdpBenchmarkSummary $udpResult.Output
    Write-Host $udpResult.Output

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " TEST 3/3: Bufferbloat" -ForegroundColor Cyan
    Write-Host " Measuring idle latency, then latency under load." -ForegroundColor DarkCyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""

    # Multiple ICMP targets in case 1.1.1.1 is blocked by ISP
    Write-Host " [*] Measuring idle latency (10 pings)..." -ForegroundColor Yellow
    $pingTargets = @("1.1.1.1", "8.8.8.8", "9.9.9.9")
    $idleTarget  = $null
    foreach ($t in $pingTargets) {
        $probe = Get-PingSampleStats $t 3 200
        if ($probe.Success -ge 2) { $idleTarget = $t; break }
    }
    if (-not $idleTarget) {
        Write-Host " [!] Could not reach any ICMP target. Bufferbloat test skipped." -ForegroundColor Red
        $idleStats   = [pscustomobject]@{ Count=0; Success=0; Samples=@(); Details=@("Skipped"); Min=$null; Max=$null; Avg=$null }
        $loadedStats = [pscustomobject]@{ Count=0; Success=0; Samples=@(); Details=@("Skipped"); Min=$null; Max=$null; Avg=$null }
        $latencyIncrease = $null
        $grade = "N/A"
    } else {
        $idleStats = Get-PingSampleStats $idleTarget 10
        Write-Host (" [*] Idle latency ({0}): avg {1}ms (min {2}, max {3})" -f $idleTarget, $idleStats.Avg, $idleStats.Min, $idleStats.Max) -ForegroundColor Green

        Write-Host " [*] Saturating connection with iperf3 while measuring latency..." -ForegroundColor Yellow
        $loadProcess = $null
        try {
            $loadProcess = Start-Process -FilePath $bundle.ExePath `
                -ArgumentList @("-c", $server, "-t", "25", "-P", "8", "--connect-timeout", "10000") `
                -WindowStyle Hidden -PassThru -ErrorAction Stop
        } catch {
            Write-Host (" [!] Could not start load process: {0}" -f $_.Exception.Message) -ForegroundColor DarkYellow
        }
        # Wait for iperf3 to fully ramp up and saturate the connection before
        # starting ping measurements. 2s was too short - TCP slow-start needs
        # 4-5s to reach full throughput, especially on slower connections.
        Start-Sleep -Seconds 5
        $loadedStats = Get-PingSampleStats $idleTarget 15
        if ($loadProcess -ne $null) {
            Wait-Process -Id $loadProcess.Id -Timeout 30 -ErrorAction SilentlyContinue
            if (-not $loadProcess.HasExited) { try { $loadProcess.Kill() } catch {} }
        }

        $latencyIncrease = if ($idleStats.Avg -ne $null -and $loadedStats.Avg -ne $null) {
            [math]::Max(0, [math]::Round($loadedStats.Avg - $idleStats.Avg, 1))
        } else { $null }

        $grade = if ($latencyIncrease -eq $null) { "N/A" }
                 elseif ($latencyIncrease -lt 5)   { "A+" }
                 elseif ($latencyIncrease -lt 30)  { "A" }
                 elseif ($latencyIncrease -lt 60)  { "B" }
                 elseif ($latencyIncrease -lt 200) { "C" }
                 elseif ($latencyIncrease -lt 400) { "D" }
                 else { "F" }
    }

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " BUFFERBLOAT RESULT" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host (" Idle latency:     {0}ms avg" -f $idleStats.Avg) -ForegroundColor Gray
    Write-Host (" Loaded latency:   {0}ms avg" -f $loadedStats.Avg) -ForegroundColor Gray
    Write-Host (" Latency increase: +{0}ms" -f $latencyIncrease) -ForegroundColor Gray
    Write-Host (" Grade:            {0}" -f $grade) -ForegroundColor Green
    Write-Host ""

    $benchmarkValidity = Get-BenchmarkValidity $tcpResult $udpResult $tcpSummary $udpSummary $idleStats $loadedStats $latencyIncrease
    $benchmarkSessionObject = [pscustomobject]@{
        schema_version = "gpm-session/v2"
        kind           = "benchmark"
        tool           = "GamePingMonitor.ps1"
        mode           = "network_benchmark"
        session_id     = ("benchmark|{0}|{1}|{2}" -f $phaseLabel.ToLowerInvariant(), $regionInfo.Name.Replace(" ", "_").ToLowerInvariant(), $timestamp)
        phase          = $phaseLabel
        created_at     = (Get-Date).ToString("o")
        settings       = [pscustomobject]@{
            region_key            = $regionChoice
            region_name           = $regionInfo.Name
            tcp_duration_seconds  = 30
            tcp_parallel_streams  = 4
            udp_duration_seconds  = 15
            udp_target_bandwidth  = "50M"
            idle_ping_target      = if ($idleTarget) { $idleTarget } else { "N/A" }
            idle_ping_count       = $idleStats.Count
            loaded_ping_count     = $loadedStats.Count
            load_parallel_streams = 8
        }
        benchmark      = [pscustomobject]@{
            region = $regionInfo.Name
            server = $server
            tcp    = [pscustomobject]@{
                throughput_mbps = $tcpSummary.ThroughputMbps
                retransmits     = $tcpSummary.Retransmits
                exit_code       = $tcpResult.ExitCode
            }
            udp    = [pscustomobject]@{
                jitter_ms = $udpSummary.JitterMs
                loss_pct  = $udpSummary.LossPct
                exit_code = $udpResult.ExitCode
            }
            bufferbloat = [pscustomobject]@{
                idle_latency_ms     = $idleStats.Avg
                loaded_latency_ms   = $loadedStats.Avg
                latency_increase_ms = $latencyIncrease
                grade               = $grade
            }
        }
        counts         = [pscustomobject]@{
            idle_ping_samples   = $idleStats.Count
            idle_valid_samples  = $idleStats.Success
            loaded_ping_samples = $loadedStats.Count
            loaded_valid_samples = $loadedStats.Success
        }
        validity       = [pscustomobject]@{
            score            = $benchmarkValidity.Score
            confidence_class = $benchmarkValidity.ConfidenceClass
            reasons          = @($benchmarkValidity.Reasons)
            caveats          = @($benchmarkValidity.Caveats)
        }
        notes          = @(
            $BENCHMARK_SCOPE_NOTE,
            $MONITOR_SCOPE_NOTE
        )
    }

    $reportLines = [System.Collections.Generic.List[string]]::new()
    $reportLines.Add("============================================================")
    $reportLines.Add("  Network Benchmark Results")
    $reportLines.Add(("  {0} Network Benchmark" -f $phaseLabel))
    $reportLines.Add("============================================================")
    $reportLines.Add("")
    $reportLines.Add(("  Date:     {0}" -f $timestamp))
    $reportLines.Add(("  Region:   {0}" -f $regionInfo.Name))
    $reportLines.Add(("  Server:   {0}" -f $server))
    $reportLines.Add(("  Phase:    {0}" -f $phaseLabel))
    $reportLines.Add(("  Tool:     Integrated Network Benchmark Mode"))
    $reportLines.Add("")
    $reportLines.Add("------------------------------------------------------------")
    $reportLines.Add("  User Summary")
    $reportLines.Add("------------------------------------------------------------")
    $reportLines.Add(("  Validity Score : {0}/100 ({1})" -f $benchmarkValidity.Score, $benchmarkValidity.ConfidenceClass))
    $reportLines.Add(("  TCP Throughput : {0} Mbps" -f $tcpSummary.ThroughputMbps))
    $reportLines.Add(("  Retransmits    : {0}" -f $tcpSummary.Retransmits))
    $reportLines.Add(("  UDP Jitter     : {0} ms" -f $udpSummary.JitterMs))
    $reportLines.Add(("  UDP Loss       : {0}%" -f $udpSummary.LossPct))
    $reportLines.Add(("  Bufferbloat    : +{0} ms ({1})" -f $latencyIncrease, $grade))
    $reportLines.Add(("  Idle Samples   : {0}/{1} valid" -f $idleStats.Success, $idleStats.Count))
    $reportLines.Add(("  Loaded Samples : {0}/{1} valid" -f $loadedStats.Success, $loadedStats.Count))
    foreach ($reason in @($benchmarkValidity.Reasons)) { $reportLines.Add(("  Validity Reason: {0}" -f $reason)) }
    foreach ($caveat in @($benchmarkValidity.Caveats)) { $reportLines.Add(("  Validity Caveat: {0}" -f $caveat)) }
    $reportLines.Add("")
    $reportLines.Add("------------------------------------------------------------")
    $reportLines.Add("  TEST 1: TCP Throughput (30s, 4 parallel streams)")
    $reportLines.Add("------------------------------------------------------------")
    foreach ($line in ($tcpResult.Output -split "`r?`n")) { $reportLines.Add($line) }
    $reportLines.Add("")
    $reportLines.Add("------------------------------------------------------------")
    $reportLines.Add("  TEST 2: UDP Jitter and Packet Loss (15s, 50Mbps target)")
    $reportLines.Add("------------------------------------------------------------")
    foreach ($line in ($udpResult.Output -split "`r?`n")) { $reportLines.Add($line) }
    $reportLines.Add("")
    $reportLines.Add("------------------------------------------------------------")
    $reportLines.Add("  TEST 3: Bufferbloat (idle vs loaded latency)")
    $reportLines.Add("------------------------------------------------------------")
    $reportLines.Add("")
    $reportLines.Add(("  Idle Latency: avg {0}ms (min {1}ms, max {2}ms)" -f $idleStats.Avg, $idleStats.Min, $idleStats.Max))
    $reportLines.Add(("  Loaded Latency: avg {0}ms (min {1}ms, max {2}ms)" -f $loadedStats.Avg, $loadedStats.Min, $loadedStats.Max))
    $reportLines.Add("")
    $reportLines.Add("  ----------------------------------------")
    $reportLines.Add("  BUFFERBLOAT RESULT")
    $reportLines.Add("  ----------------------------------------")
    $reportLines.Add(("   Idle latency:     {0}ms avg" -f $idleStats.Avg))
    $reportLines.Add(("   Loaded latency:   {0}ms avg" -f $loadedStats.Avg))
    $reportLines.Add(("   Latency increase: +{0}ms" -f $latencyIncrease))
    $reportLines.Add(("   Grade: {0}" -f $grade))
    $reportLines.Add("")
    $reportLines.Add("   Grading: A+ (under 5ms) / A (under 30ms) / B (under 60ms)")
    $reportLines.Add("            C (under 200ms) / D (under 400ms) / F (400ms+)")
    $reportLines.Add("")
    $reportLines.Add("  Idle ping details:")
    foreach ($line in $idleStats.Details) { $reportLines.Add($line) }
    $reportLines.Add("")
    $reportLines.Add("  Loaded ping details:")
    foreach ($line in $loadedStats.Details) { $reportLines.Add($line) }
    $reportLines.Add("")
    $reportLines.Add("  Quick Summary:")
    $reportLines.Add(("   TCP Throughput: {0} Mbps" -f $tcpSummary.ThroughputMbps))
    $reportLines.Add(("   Retransmits:    {0}" -f $tcpSummary.Retransmits))
    $reportLines.Add(("   UDP Jitter:     {0} ms" -f $udpSummary.JitterMs))
    $reportLines.Add(("   UDP Loss:       {0}%" -f $udpSummary.LossPct))
    $reportLines.Add(("   Bufferbloat:    +{0} ms ({1})" -f $latencyIncrease, $grade))
    $reportLines.Add("")
    $reportLines.Add(("  Companion Tool:  {0}" -f $MONITOR_SCOPE_NOTE))
    $reportLines.Add("------------------------------------------------------------")
    $reportLines.Add("-----BEGIN SESSION JSON-----")
    $reportLines.Add(($benchmarkSessionObject | ConvertTo-Json -Depth 8))
    $reportLines.Add("-----END SESSION JSON-----")
    $reportLines.Add("============================================================")

    $report = $reportLines -join [Environment]::NewLine
    $report | Out-File -FilePath $outputFile -Encoding UTF8

    Write-Host ("[+] Saved benchmark results to: {0}" -f $outputFile) -ForegroundColor Green
}

# -- Mode Selection -----------------------------------------------------------
Clear-Host
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "    UNIFIED NETWORK AND GAME MONITOR" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host " [1] Network Benchmark" -ForegroundColor Yellow
Write-Host "     TCP throughput + retransmissions" -ForegroundColor Gray
Write-Host "     UDP jitter + packet loss" -ForegroundColor Gray
Write-Host "     Bufferbloat" -ForegroundColor Gray
Write-Host ""
Write-Host " [2] Game Latency Monitor" -ForegroundColor Yellow
Write-Host "     Latency toward the detected game server" -ForegroundColor Gray
Write-Host "     BEFORE/AFTER comparison during a real match" -ForegroundColor Gray
Write-Host ""
Write-Host " [Q] Exit" -ForegroundColor Yellow
Write-Host ""
$modeChoice = ((Read-Host "  Select mode (default 2)").Trim()).ToUpperInvariant()

if (-not $modeChoice) { $modeChoice = "2" }

switch ($modeChoice) {
    "1" {
        Start-NetworkBenchmark
        Write-Host ""
        Write-Host "Press ENTER to exit..." -ForegroundColor Gray
        Read-Host
        exit
    }
    "Q" {
        exit
    }
}

# -- Header ------------------------------------------------------------------
Clear-Host
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "      GAME PING MONITOR  [ENDPOINT RTT]" -ForegroundColor Cyan
Write-Host "  Fortnite / Valorant / CS2 / Apex / More" -ForegroundColor DarkCyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host " Scope:" -ForegroundColor Yellow
Write-Host "   $MONITOR_SCOPE_NOTE" -ForegroundColor Gray
Write-Host "   $BENCHMARK_SCOPE_NOTE" -ForegroundColor Gray
Write-Host ""
Write-Host " Positioning:" -ForegroundColor Yellow
Write-Host "   $POSITIONING_NOTE" -ForegroundColor DarkYellow
Write-Host ""

# -- Session label ------------------------------------------------------------
Write-Host " Session label (e.g. BEFORE / AFTER / TEST-1)" -ForegroundColor Yellow
Write-Host " Press ENTER to skip:" -ForegroundColor Gray
Write-Host ""
$sessionLabel = (Read-Host "  Label").Trim()
if (-not $sessionLabel) {
    $sessionLabel = "SESSION_$(Get-Date -Format 'HHmmss')"
}

$outputFile = "$outputDir\PingResults_${sessionLabel}_$(Get-Date -Format 'yyyy-MM-dd_HH-mm-ss').txt"

Write-Host ""
Write-Host "[*] Waiting for a supported game to launch..." -ForegroundColor Yellow
Write-Host "    Supported: $($gameProcesses.Values -join ', ')" -ForegroundColor Gray
Write-Host ""
Write-Host "    Press [B] at any time to go back to the main menu." -ForegroundColor DarkGray
Write-Host ""

# -- Wait for game ------------------------------------------------------------
$game     = $null
$attempts = 0
while (-not $game) {

    # Non-blocking key check for [B] back
    if ([Console]::KeyAvailable) {
        $k = [Console]::ReadKey($true).Key
        if ($k -eq 'B') {
            Write-Host "`n[*] Returning to main menu..." -ForegroundColor Yellow
            # Re-run the script to go back to mode selection
            & "$PSCommandPath"
            exit
        }
    }

    $game = Get-RunningGame
    if (-not $game) {
        $attempts++
        Write-Host "`r[*] Attempt $attempts - No game detected... (Press B to go back)" -NoNewline -ForegroundColor DarkYellow
        Start-Sleep -Seconds 3
    }
}

Write-Host ""
Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host " GAME DETECTED" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host ("  Name        : {0}" -f $game.Name) -ForegroundColor Green
Write-Host ("  Process EXE : {0}.exe" -f $game.EXE) -ForegroundColor Green
Write-Host ("  Process ID  : {0}" -f $game.ProcessId) -ForegroundColor Green
Write-Host ("  Full path   : {0}" -f (Get-Process -Id $game.ProcessId -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Path)) -ForegroundColor DarkGreen
Write-Host ""
Write-Host " Is this the correct game?" -ForegroundColor Yellow
Write-Host "   [ENTER] Yes, continue" -ForegroundColor Gray
Write-Host "   [B]     No, go back to main menu" -ForegroundColor Gray
Write-Host ""
$gameConfirm = (Read-Host "  Choice").Trim().ToUpperInvariant()
if ($gameConfirm -eq "B") {
    Write-Host "[*] Returning to main menu..." -ForegroundColor Yellow
    & "$PSCommandPath"
    exit
}

Write-Host ""
Write-Host "[*] Waiting for match to start (endpoint observation)..." -ForegroundColor Yellow
Write-Host "    Make sure you are INSIDE a match, not in lobby." -ForegroundColor Gray
Write-Host "    The script observes all candidate IP:port pairs for a few seconds and recommends the most stable one." -ForegroundColor Gray
Write-Host ""
Write-Host "    Press [B] at any time to go back to the main menu." -ForegroundColor DarkGray
Write-Host ""

# -- Wait for endpoints -------------------------------------------------------
$initialObservation = $null
$attempts = 0
while (-not $initialObservation -or @($initialObservation.Candidates).Count -eq 0) {

    # Non-blocking key check for [B] back
    if ([Console]::KeyAvailable) {
        $k = [Console]::ReadKey($true).Key
        if ($k -eq 'B') {
            Write-Host "`n[*] Returning to main menu..." -ForegroundColor Yellow
            & "$PSCommandPath"
            exit
        }
    }

    if (-not (Test-ProcessAlive $game.ProcessId)) {
        Write-Host "`n[!] Game process closed before a match endpoint was found. Exiting." -ForegroundColor Red
        Read-Host "Press ENTER to exit"
        exit
    }

    $initialObservation = Observe-GameEndpoints $game.ProcessId $game.EXE $ENDPOINT_OBSERVE_SECONDS $ENDPOINT_OBSERVE_INTERVAL
    if (@($initialObservation.Candidates).Count -eq 0) {
        $attempts++
        Write-Host "`r[*] Attempt $attempts - No stable public game endpoint yet... (Press B to go back)" -NoNewline -ForegroundColor DarkYellow
        Start-Sleep -Seconds 3
    }
}

$initialDetectedEndpoints = @($initialObservation.Candidates)
$primaryObservedConn = $initialObservation.Primary
$conn = Select-InitialConnection $initialObservation
$selectedIsPrimary = $primaryObservedConn -and ((Get-EndpointKey $conn) -eq (Get-EndpointKey $primaryObservedConn))
$endpointConfidence = if ($selectedIsPrimary) {
    $initialObservation.Confidence
} elseif ($initialObservation.Confidence -eq "High") {
    "Medium"
} else {
    "Low"
}
$measurementProfile = Get-MeasurementProfile $conn

Write-Host ""
Write-Host ("  [+] Server locked : {0}:{1}" -f $conn.IP, $conn.Port) -ForegroundColor Green
Write-Host ("      Protocol      : {0}" -f $conn.Proto) -ForegroundColor DarkGreen
Write-Host ("      Confidence    : {0}" -f $endpointConfidence) -ForegroundColor DarkGreen
Write-Host ("      Measurement   : {0}" -f (Get-MeasurementDescription $conn $null)) -ForegroundColor DarkGreen
Write-Host ("      Accuracy      : {0}" -f $measurementProfile.Fidelity) -ForegroundColor DarkGreen
if (-not $selectedIsPrimary) {
    Write-Host "      Note          : Manual override selected instead of the top-ranked endpoint." -ForegroundColor DarkYellow
}
Write-Host ""
Write-Host "--------------------------------------------" -ForegroundColor DarkGray
Write-Host " WARMUP      : First ${WARMUP_SECONDS}s excluded from stats" -ForegroundColor DarkYellow
Write-Host " RECOMMENDED : $RECOMMENDED_SAMPLES valid samples (~${RECOMMENDED_SECONDS}s)" -ForegroundColor Yellow
Write-Host " CONTROLS    : [P] Pause/Resume   [Q] Quit + Export   [B] Back to menu" -ForegroundColor White
Write-Host " PROTOCOL    : UDP and TCP endpoint RTT should not be compared as if they were equivalent." -ForegroundColor DarkYellow
Write-Host " NOTE        : Failed RTT probes are tracked as failed samples, not packet loss." -ForegroundColor DarkYellow
Write-Host "--------------------------------------------" -ForegroundColor DarkGray
Write-Host ""

# -- Pre-recording countdown (gives user time to alt-tab back into game) -----
Write-Host " Switch back to your game now!" -ForegroundColor Yellow
Write-Host " Recording starts in:" -ForegroundColor Yellow
Write-Host ""
for ($cd = 5; $cd -ge 1; $cd--) {
    Write-Host ("`r   {0}..." -f $cd) -NoNewline -ForegroundColor Cyan
    Start-Sleep -Seconds 1
}
Write-Host "`r   GO! Recording started.          " -ForegroundColor Green
Write-Host ""

# -- Measurement loop ---------------------------------------------------------
$pingResults    = [System.Collections.Generic.List[double]]::new()
$warmupResults  = [System.Collections.Generic.List[double]]::new()
$sampleRecords  = [System.Collections.Generic.List[object]]::new()
$paused         = $false
$sequenceNum    = 0
$startTime      = Get-Date
$lastRecheck    = Get-Date
$serverSwitches = 0
$serverChangeEvents = [System.Collections.Generic.List[object]]::new()
$uniqueEndpointKeys = @{}
$uniqueEndpointKeys[(Get-EndpointKey $conn)] = $true
$stableSegmentStart = Get-Date
$longestStableDurationSec = 0

while ($true) {
    if ([Console]::KeyAvailable) {
        $key = [Console]::ReadKey($true).Key
        if ($key -eq 'P') {
            $paused = -not $paused
            if ($paused) {
                Write-Host "`n[PAUSE] Recording paused. Press P to resume." -ForegroundColor Magenta
            } else {
                Write-Host "[RESUME] Recording resumed..." -ForegroundColor Green
            }
        }
        if ($key -eq 'Q') { break }
        if ($key -eq 'B') {
            Write-Host "`n[*] Returning to main menu..." -ForegroundColor Yellow
            & "$PSCommandPath"
            exit
        }
    }

    if ($paused) {
        Start-Sleep -Milliseconds 500
        continue
    }

    if (-not (Test-ProcessAlive $game.ProcessId)) {
        Write-Host ""
        Write-Host "[!] Game process has closed. Stopping recording." -ForegroundColor Red
        break
    }

    $secondsSinceRecheck = ((Get-Date) - $lastRecheck).TotalSeconds
    if ($secondsSinceRecheck -ge $ENDPOINT_RECHECK_SEC) {
        $recheckObservation = Observe-GameEndpoints $game.ProcessId $game.EXE $ENDPOINT_RESELECT_SECONDS $ENDPOINT_OBSERVE_INTERVAL $conn
        $latestCandidates = @($recheckObservation.Candidates)

        if ($latestCandidates.Count -gt 0) {
            $currentStillExists = $latestCandidates | Where-Object {
                (Get-EndpointKey $_) -eq (Get-EndpointKey $conn)
            } | Select-Object -First 1
            if (-not $currentStillExists) {
                $nextConn = $recheckObservation.Primary
                if ($nextConn) {
                    $switchTime = Get-Date
                    $segmentDurationSec = ($switchTime - $stableSegmentStart).TotalSeconds
                    if ($segmentDurationSec -gt $longestStableDurationSec) {
                        $longestStableDurationSec = $segmentDurationSec
                    }

                    $serverSwitches++
                    $serverChangeEvents.Add([pscustomobject]@{
                        Timestamp   = $switchTime.ToString("HH:mm:ss")
                        OldEndpoint = Get-EndpointDisplay $conn
                        NewEndpoint = Get-EndpointDisplay $nextConn
                        Reason      = "Connection change"
                    })
                    $uniqueEndpointKeys[(Get-EndpointKey $nextConn)] = $true
                    $measurementProfile = Get-MeasurementProfile $nextConn

                    Write-Host ""
                    Write-Host ("[!] Endpoint changed: {0} -> {1} (switch #{2})" -f (Get-EndpointDisplay $conn), (Get-EndpointDisplay $nextConn), $serverSwitches) -ForegroundColor Magenta
                    Write-Host ("    Measurement       : {0}" -f (Get-MeasurementDescription $nextConn $null)) -ForegroundColor DarkMagenta
                    Write-Host ("    Accuracy          : {0}" -f $measurementProfile.Fidelity) -ForegroundColor DarkMagenta
                    Write-Host ""

                    $conn = $nextConn
                    $stableSegmentStart = $switchTime
                }
            }
        }

        $lastRecheck = Get-Date
    }

    $sequenceNum++
    $measurement = Invoke-EndpointMeasurement $conn
    $ms          = $measurement.RTT
    $elapsed     = [int]((Get-Date) - $startTime).TotalSeconds
    $sampleTime  = Get-Date

    $isWarmup   = $elapsed -lt $WARMUP_SECONDS
    $remaining  = [math]::Max(0, $RECOMMENDED_SECONDS - [math]::Max(0, $elapsed - $WARMUP_SECONDS))
    $validSoFar = (Get-ValidSamples $pingResults).Count

    $timerStr = if ($isWarmup) {
        "  [WARMUP $($WARMUP_SECONDS - $elapsed)s - excluded from stats]"
    } elseif ($remaining -gt 0) {
        "  [${remaining}s left | $validSoFar/$RECOMMENDED_SAMPLES valid samples]"
    } else {
        "  [Ready to export | $validSoFar valid samples]"
    }

    $sampleEndpoint = "{0}:{1}" -f $conn.IP, $conn.Port
    $sampleRttValue = if ($ms -ne $null) { $ms } else { $FAILED_SAMPLE }

    $sampleRecords.Add([pscustomobject]@{
        Sequence         = $sequenceNum
        Timestamp        = $sampleTime.ToString("HH:mm:ss")
        ElapsedSec       = $elapsed
        RelativeMs       = ($elapsed * 1000)
        Phase            = if ($isWarmup) { "warmup" } else { "measure" }
        Warmup           = $isWarmup
        Endpoint         = $sampleEndpoint
        EndpointKey      = (Get-EndpointKey $conn)
        Protocol         = $conn.Proto
        RTT              = $sampleRttValue
        Success          = $measurement.Success
        Method           = $measurement.Method
        FallbackUsed     = $measurement.FallbackUsed
        FallbackAttempted = $measurement.FallbackAttempted
        AttemptSequence  = $measurement.AttemptSequence
        FailureReason    = $measurement.FailureReason
    })

    if ($ms -ne $null) {
        if ($isWarmup) {
            $warmupResults.Add($ms)
            Write-Host ("[#{0:D4}][{1}][{2}] RTT: {3,4} ms{4}" -f $sequenceNum, $conn.Proto, $measurement.Method, $ms, $timerStr) -ForegroundColor DarkGray
        } else {
            $pingResults.Add($ms)
            $validNow = Get-ValidSamples $pingResults
            $avg      = [math]::Round(($validNow | Measure-Object -Average).Average, 1)
            $min      = ($validNow | Measure-Object -Minimum).Minimum
            $max      = ($validNow | Measure-Object -Maximum).Maximum
            $color    = if ($ms -le 40) { "Green" } elseif ($ms -le 80) { "Yellow" } else { "Red" }
            $fallbackMarker = if ($measurement.FallbackUsed) { " | fallback" } else { "" }

            Write-Host ("[#{0:D4}][{1}][{2}] RTT: {3,4} ms   Min: {4} ms  Avg: {5} ms  Max: {6} ms{7}{8}" -f $sequenceNum, $conn.Proto, $measurement.Method, $ms, $min, $avg, $max, $fallbackMarker, $timerStr) -ForegroundColor $color
        }
    } else {
        if ($isWarmup) {
            $warmupResults.Add($FAILED_SAMPLE)
            Write-Host ("[#{0:D4}][{1}] No RTT sample ({2}){3}" -f $sequenceNum, $measurement.Method, $measurement.FailureReason, $timerStr) -ForegroundColor DarkGray
        } else {
            $pingResults.Add($FAILED_SAMPLE)
            Write-Host ("[#{0:D4}][{1}] No RTT sample ({2}){3}" -f $sequenceNum, $measurement.Method, $measurement.FailureReason, $timerStr) -ForegroundColor DarkRed
        }
    }

    Start-Sleep -Milliseconds $INTERVAL_MS
}

# -- Export ------------------------------------------------------------------
Write-Host ""
Write-Host "[*] Exporting results..." -ForegroundColor Cyan

$validResults = Get-ValidSamples $pingResults
$failedCount  = Get-FailureCount $pingResults
$measurementRecords = @($sampleRecords | Where-Object { -not $_.Warmup })
$validSampleCount = $validResults.Count
$rawSampleCount = $sampleRecords.Count
$warmupSampleCount = @($sampleRecords | Where-Object { $_.Warmup }).Count
$measurementSampleCount = $measurementRecords.Count
$totalSamples = $measurementSampleCount
$elapsed = [int]((Get-Date) - $startTime).TotalSeconds
$failureRate = if ($totalSamples -gt 0) { [math]::Round(($failedCount / $totalSamples) * 100, 1) } else { 0 }
$finalSegmentDurationSec = ((Get-Date) - $stableSegmentStart).TotalSeconds
if ($finalSegmentDurationSec -gt $longestStableDurationSec) {
    $longestStableDurationSec = $finalSegmentDurationSec
}

if ($validResults.Count -gt 0) {
    $finalAvgValue = [math]::Round(($validResults | Measure-Object -Average).Average, 1)
    $finalMinValue = [double](($validResults | Measure-Object -Minimum).Minimum)
    $finalMaxValue = [double](($validResults | Measure-Object -Maximum).Maximum)
    $percentileSet = Get-PercentileSet $validResults
    $jitterValue   = Compute-Jitter $validResults
} else {
    $finalAvgValue = $null
    $finalMinValue = $null
    $finalMaxValue = $null
    $percentileSet = Get-PercentileSet @()
    $jitterValue   = $null
}

$warmupAvgValue = if ($warmupResults.Count -gt 0) {
    $warmupValid = Get-ValidSamples $warmupResults
    if ($warmupValid.Count -gt 0) {
        [math]::Round(($warmupValid | Measure-Object -Average).Average, 1)
    } else {
        $null
    }
} else {
    $null
}

$methodStats = Get-MethodStats $sampleRecords
$measurementDescription = Get-MeasurementDescription $conn $methodStats
$measurementProfile     = Get-MeasurementProfile $conn
$connectionStability    = Get-StabilityLabel $serverSwitches $longestStableDurationSec $elapsed
$spikeAnalysis          = Get-SpikeAnalysis $sampleRecords $percentileSet
$sessionValidity        = Get-SessionValidity $validSampleCount $failureRate $endpointConfidence $selectedIsPrimary $connectionStability $methodStats $spikeAnalysis
$comparisonWarnings     = [System.Collections.Generic.List[string]]::new()
foreach ($warning in @(Get-ComparisonWarnings $endpointConfidence $methodStats $serverSwitches $connectionStability)) {
    $comparisonWarnings.Add($warning)
}
if ($sessionValidity.ConfidenceClass -eq "Low") {
    $comparisonWarnings.Add("Warning: Session validity is low, so the run should not be treated as strong evidence.")
} elseif ($sessionValidity.ConfidenceClass -eq "Caveated") {
    $comparisonWarnings.Add("Warning: Session validity is caveated, so comparisons should be treated carefully.")
}
$primaryEndpointDisplay = if ($primaryObservedConn) { Get-EndpointDisplay $primaryObservedConn } else { "Unknown" }
$selectedEndpointDisplay = Get-EndpointDisplay $conn
$sessionPhase = if ($sessionLabel -match '(?i)before') {
    "BEFORE"
} elseif ($sessionLabel -match '(?i)after') {
    "AFTER"
} else {
    $sessionLabel
}
$finalAvg = if ($finalAvgValue -ne $null) { $finalAvgValue } else { "N/A" }
$finalMin = if ($finalMinValue -ne $null) { $finalMinValue } else { "N/A" }
$finalMax = if ($finalMaxValue -ne $null) { $finalMaxValue } else { "N/A" }
$p50      = if ($percentileSet.P50 -ne $null) { $percentileSet.P50 } else { "N/A" }
$p90      = if ($percentileSet.P90 -ne $null) { $percentileSet.P90 } else { "N/A" }
$p95      = if ($percentileSet.P95 -ne $null) { $percentileSet.P95 } else { "N/A" }
$p99      = if ($percentileSet.P99 -ne $null) { $percentileSet.P99 } else { "N/A" }
$jitter   = if ($jitterValue -ne $null) { $jitterValue } else { "N/A" }
$warmupAvg = if ($warmupAvgValue -ne $null) { $warmupAvgValue } else { "N/A" }

$detectedEndpointLines = [System.Collections.Generic.List[string]]::new()
if ($initialDetectedEndpoints.Count -gt 0) {
    $endpointIndex = 0
    foreach ($endpoint in $initialDetectedEndpoints) {
        $endpointIndex++
        $detectedEndpointLines.Add(
            "Detected Endpoint $endpointIndex : $(Get-EndpointDisplay $endpoint) | Seen $($endpoint.PresencePct)% | Stable $($endpoint.StabilityPct)% | Span $($endpoint.SpanPct)% | Score $($endpoint.Score)"
        )
    }
} else {
    $detectedEndpointLines.Add("Detected Endpoint 1 : None")
}

$serverChangeLines = [System.Collections.Generic.List[string]]::new()
if ($serverChangeEvents.Count -gt 0) {
    $changeIndex = 0
    foreach ($change in $serverChangeEvents) {
        $changeIndex++
        $serverChangeLines.Add(
            "Server Change $changeIndex : $($change.OldEndpoint) -> $($change.NewEndpoint) | Time $($change.Timestamp) | Reason $($change.Reason)"
        )
    }
} else {
    $serverChangeLines.Add("Server Change 1 : None")
}

$warningLines = [System.Collections.Generic.List[string]]::new()
if ($comparisonWarnings.Count -gt 0) {
    $warningIndex = 0
    foreach ($warning in $comparisonWarnings) {
        $warningIndex++
        $warningLines.Add("Comparison Warning $warningIndex : $warning")
    }
} else {
    $warningLines.Add("Comparison Warning 1 : None")
}

$histogramLines = [System.Collections.Generic.List[string]]::new()
$histogramIndex = 0
foreach ($bucket in $spikeAnalysis.Histogram.GetEnumerator()) {
    $histogramIndex++
    $histogramLines.Add("Latency Bucket $histogramIndex : $($bucket.Key) = $($bucket.Value)")
}

$sampleLines = [System.Collections.Generic.List[string]]::new()
foreach ($record in $sampleRecords) {
    $statusText = if ($record.Success) { "Success" } else { "Failed" }
    $rttText = if ($record.Success) { "$($record.RTT) ms" } else { "FAILED" }
    $failureText = if (-not $record.Success -and $record.FailureReason) { " | FailureReason=$($record.FailureReason)" } else { "" }
    $sampleLines.Add(
        "Sample {0:D4} : Time={1} | Phase={2} | Warmup={3} | Endpoint={4} | Protocol={5} | RTT={6} | Method={7} | FallbackUsed={8} | Spike={9} | Bad={10} | AttemptSequence={11} | Status={12}{13}" -f `
        $record.Sequence,
        $record.Timestamp,
        $record.Phase,
        (Format-YesNo $record.Warmup),
        $record.Endpoint,
        $record.Protocol,
        $rttText,
        $record.Method,
        (Format-YesNo $record.FallbackUsed),
        (Format-YesNo $record.Spike),
        (Format-YesNo $record.Bad),
        $record.AttemptSequence,
        $statusText,
        $failureText
    )
}

$latencySessionObject = [pscustomobject]@{
    schema_version    = "gpm-session/v2"
    kind              = "latency"
    tool              = "GamePingMonitor.ps1"
    mode              = "game_latency"
    session_id        = ("latency|{0}|{1}|{2}" -f $game.Name.Replace(" ", "_").ToLowerInvariant(), $sessionPhase.ToLowerInvariant(), (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'))
    phase             = $sessionPhase
    created_at        = (Get-Date).ToString("o")
    settings          = [pscustomobject]@{
        interval_ms      = $INTERVAL_MS
        warmup_seconds   = $WARMUP_SECONDS
        recommended_samples = $RECOMMENDED_SAMPLES
        recommended_seconds = $RECOMMENDED_SECONDS
        observe_seconds  = $ENDPOINT_OBSERVE_SECONDS
        recheck_seconds  = $ENDPOINT_RECHECK_SEC
    }
    identity          = [pscustomobject]@{
        game        = $game.Name
        process_exe = ("{0}.exe" -f $game.EXE)
        process_id  = $game.ProcessId
        label       = $sessionLabel
    }
    endpoint_detection = [pscustomobject]@{
        primary_endpoint      = $primaryEndpointDisplay
        selected_endpoint     = $selectedEndpointDisplay
        confidence_class      = $endpointConfidence
        observation_seconds   = $initialObservation.ObservedSeconds
        selected_recommended  = [bool]$selectedIsPrimary
        candidates            = @(
            foreach ($endpoint in $initialDetectedEndpoints) {
                [pscustomobject]@{
                    endpoint        = Get-EndpointDisplay $endpoint
                    protocol        = $endpoint.Proto
                    ip              = $endpoint.IP
                    port            = $endpoint.Port
                    presence_pct    = $endpoint.PresencePct
                    stability_pct   = $endpoint.StabilityPct
                    span_pct        = $endpoint.SpanPct
                    heuristic_bonus = $endpoint.HeuristicBonus
                    score           = $endpoint.Score
                }
            }
        )
    }
    measurement       = [pscustomobject]@{
        protocol           = $conn.Proto
        method_description = $measurementDescription
        protocol_fit       = $measurementProfile.ProtocolBasis
        accuracy           = $measurementProfile.Fidelity
        primary_method     = $methodStats.PrimaryMethod
        primary_method_pct = $methodStats.PrimaryPct
        method_mix         = [pscustomobject]@{
            icmp_pct     = $methodStats.ICMPPct
            tcp_port_pct = $methodStats.TCPPortPct
            tcp_443_pct  = $methodStats.TCP443Pct
        }
        method_switch_count = $methodStats.SwitchCount
        fallback_occurred   = [bool]$methodStats.FallbackOccurred
        fallback_count      = $methodStats.FallbackCount
        method_stability    = $methodStats.StabilityLabel
    }
    counts            = [pscustomobject]@{
        raw_sample_count         = $rawSampleCount
        warmup_sample_count      = $warmupSampleCount
        measurement_sample_count = $measurementSampleCount
        valid_sample_count       = $validSampleCount
        failed_sample_count      = $failedCount
    }
    distribution      = [pscustomobject]@{
        warmup_avg_ms = $warmupAvgValue
        min           = $finalMinValue
        p50           = $percentileSet.P50
        p90           = $percentileSet.P90
        p95           = $percentileSet.P95
        p99           = $percentileSet.P99
        avg           = $finalAvgValue
        max           = $finalMaxValue
        jitter        = $jitterValue
        failure_rate_pct = $failureRate
    }
    stability         = [pscustomobject]@{
        baseline_ms          = $spikeAnalysis.BaselineMs
        spike_threshold_ms   = $spikeAnalysis.SpikeThresholdMs
        bad_threshold_ms     = $spikeAnalysis.BadThresholdMs
        spike_count          = $spikeAnalysis.SpikeCount
        spike_rate_pct       = $spikeAnalysis.SpikeRatePct
        longest_bad_streak   = $spikeAnalysis.LongestBadStreak
        tail_gap_p95_p50     = $spikeAnalysis.TailGapP95P50
        tail_gap_p99_p50     = $spikeAnalysis.TailGapP99P50
        tail_ratio_p95_p50   = $spikeAnalysis.TailRatioP95OverP50
        baseline_vs_tail     = $spikeAnalysis.BaselineVsTailLabel
        histogram            = [pscustomobject]$spikeAnalysis.Histogram
    }
    endpoint_consistency = [pscustomobject]@{
        server_change_count     = $serverSwitches
        unique_endpoints        = $uniqueEndpointKeys.Count
        longest_stable_seconds  = [math]::Round($longestStableDurationSec, 1)
        connection_stability    = $connectionStability
        events                  = @(
            foreach ($change in $serverChangeEvents) {
                [pscustomobject]@{
                    time         = $change.Timestamp
                    old_endpoint = $change.OldEndpoint
                    new_endpoint = $change.NewEndpoint
                    reason       = $change.Reason
                }
            }
        )
    }
    validity          = [pscustomobject]@{
        score            = $sessionValidity.Score
        confidence_class = $sessionValidity.ConfidenceClass
        reasons          = @($sessionValidity.Reasons)
        caveats          = @($sessionValidity.Caveats)
    }
    warnings          = @($comparisonWarnings)
    notes             = @(
        $POSITIONING_NOTE,
        $measurementProfile.Summary,
        $measurementProfile.CompareRule,
        "Failed RTT probes are not the same as packet loss."
    )
    samples           = @($spikeAnalysis.AnnotatedSamples)
}

$reportLines = [System.Collections.Generic.List[string]]::new()
$reportLines.Add("============================================")
$reportLines.Add("  GAME PING MONITOR - RESULTS")
$reportLines.Add("============================================")
$reportLines.Add("Label         : $sessionLabel")
$reportLines.Add("Date          : $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')")
$reportLines.Add("Game          : $($game.Name)")
$reportLines.Add("Process (EXE) : $($game.EXE).exe")
$reportLines.Add("Process ID    : $($game.ProcessId)")
$reportLines.Add("Endpoint IP   : $($conn.IP)")
$reportLines.Add("Port          : $($conn.Port)")
$reportLines.Add("Protocol      : $($conn.Proto)")
$reportLines.Add("Method        : $measurementDescription")
$reportLines.Add("Protocol Fit  : $($measurementProfile.ProtocolBasis)")
$reportLines.Add("Accuracy      : $($measurementProfile.Fidelity)")
$reportLines.Add("Duration      : ${elapsed}s")
$reportLines.Add("Endpoint Chg  : $serverSwitches")
$reportLines.Add("Output Dir    : $outputDir")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Tool Scope    : $MONITOR_SCOPE_NOTE")
$reportLines.Add("Companion Tool: $BENCHMARK_SCOPE_NOTE")
$reportLines.Add("Positioning   : $POSITIONING_NOTE")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("User Summary")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Server Measured      : $selectedEndpointDisplay")
$reportLines.Add("Reliability          : $endpointConfidence")
$reportLines.Add("Measurement Method   : $(if ($methodStats.PrimaryMethod -ne 'None') { "$($methodStats.PrimaryMethod) ($($methodStats.PrimaryPct)%)" } else { 'No successful RTT samples' })")
$reportLines.Add("Fallback Used        : $(Format-YesNo $methodStats.FallbackOccurred)")
$reportLines.Add("Server Changes       : $serverSwitches")
$reportLines.Add("Connection Stability : $connectionStability")
$reportLines.Add("Method Stability     : $($methodStats.StabilityLabel)")
$reportLines.Add("Test Validity        : $($sessionValidity.Score)/100 ($($sessionValidity.ConfidenceClass))")
$reportLines.Add("Latency Tail         : $($spikeAnalysis.BaselineVsTailLabel)")
$reportLines.Add("Spike Summary        : $($spikeAnalysis.SpikeCount) spikes ($($spikeAnalysis.SpikeRatePct)%)")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Warmup Period          : ${WARMUP_SECONDS}s excluded ($($warmupResults.Count) samples, avg $warmupAvg ms)")
$reportLines.Add("RawSampleCount         : $rawSampleCount")
$reportLines.Add("WarmupSampleCount      : $warmupSampleCount")
$reportLines.Add("MeasurementSampleCount : $measurementSampleCount")
$reportLines.Add("ValidSampleCount       : $validSampleCount")
$reportLines.Add("FailedSampleCount      : $failedCount")
$reportLines.Add("Failed RTT             : $failedCount ($failureRate%)")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Min RTT   : $finalMin ms")
$reportLines.Add("P50 RTT   : $p50 ms")
$reportLines.Add("Avg RTT   : $finalAvg ms")
$reportLines.Add("P90 RTT   : $p90 ms")
$reportLines.Add("P95 RTT   : $p95 ms")
$reportLines.Add("P99 RTT   : $p99 ms")
$reportLines.Add("Max RTT   : $finalMax ms")
$reportLines.Add("Jitter    : $jitter ms")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Baseline And Tail Analysis")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("SpikeThresholdMs   : $($spikeAnalysis.SpikeThresholdMs)")
$reportLines.Add("BadThresholdMs     : $($spikeAnalysis.BadThresholdMs)")
$reportLines.Add("SpikeCount         : $($spikeAnalysis.SpikeCount)")
$reportLines.Add("SpikeRatePct       : $($spikeAnalysis.SpikeRatePct)")
$reportLines.Add("LongestBadStreak   : $($spikeAnalysis.LongestBadStreak)")
$reportLines.Add("TailGapP95P50      : $($spikeAnalysis.TailGapP95P50)")
$reportLines.Add("TailGapP99P50      : $($spikeAnalysis.TailGapP99P50)")
$reportLines.Add("TailRatioP95OverP50: $($spikeAnalysis.TailRatioP95OverP50)")
$reportLines.Add("BaselineVsTail     : $($spikeAnalysis.BaselineVsTailLabel)")
foreach ($line in $histogramLines) { $reportLines.Add($line) }
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Measurement Method Summary")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("%ICMP             : $($methodStats.ICMPPct)")
$reportLines.Add("%TCP-Port         : $($methodStats.TCPPortPct)")
$reportLines.Add("%TCP-443          : $($methodStats.TCP443Pct)")
$reportLines.Add("MethodSwitchCount : $($methodStats.SwitchCount)")
$reportLines.Add("PrimaryMethod     : $($methodStats.PrimaryMethod)")
$reportLines.Add("PrimaryMethodPct  : $($methodStats.PrimaryPct)")
$reportLines.Add("FallbackOccurred  : $(Format-YesNo $methodStats.FallbackOccurred)")
$reportLines.Add("FallbackCount     : $($methodStats.FallbackCount)")
$reportLines.Add("MethodStability   : $($methodStats.StabilityLabel)")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Endpoint Detection")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Observation Window : $($initialObservation.ObservedSeconds)s")
$reportLines.Add("Primary Endpoint   : $primaryEndpointDisplay")
$reportLines.Add("Confidence         : $($initialObservation.Confidence)")
$reportLines.Add("Selected Recommended : $(Format-YesNo $selectedIsPrimary)")
foreach ($line in $detectedEndpointLines) { $reportLines.Add($line) }
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Server Change Summary")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("ServerChangeCount    : $serverSwitches")
$reportLines.Add("UniqueEndpoints      : $($uniqueEndpointKeys.Count)")
$reportLines.Add("LongestStableDuration: $(Format-Sec $longestStableDurationSec)")
$reportLines.Add("ConnectionStability  : $connectionStability")
foreach ($line in $serverChangeLines) { $reportLines.Add($line) }
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Session Validity")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("ValidityScore    : $($sessionValidity.Score)")
$reportLines.Add("ConfidenceClass  : $($sessionValidity.ConfidenceClass)")
if ($sessionValidity.Reasons.Count -gt 0) {
    $reasonIndex = 0
    foreach ($reason in $sessionValidity.Reasons) {
        $reasonIndex++
        $reportLines.Add("Validity Reason $reasonIndex : $reason")
    }
} else {
    $reportLines.Add("Validity Reason 1 : None")
}
if ($sessionValidity.Caveats.Count -gt 0) {
    $caveatIndex = 0
    foreach ($caveat in $sessionValidity.Caveats) {
        $caveatIndex++
        $reportLines.Add("Validity Caveat $caveatIndex : $caveat")
    }
} else {
    $reportLines.Add("Validity Caveat 1 : None")
}
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Comparison Warnings")
$reportLines.Add("--------------------------------------------")
foreach ($line in $warningLines) { $reportLines.Add($line) }
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Notes")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Accuracy Note : $($measurementProfile.Summary)")
$reportLines.Add("Compare Note  : $($measurementProfile.CompareRule)")
$reportLines.Add("Probe Note    : Failed RTT probes are not the same as packet loss.")
$reportLines.Add("--------------------------------------------")
$reportLines.Add("Sample Details")
$reportLines.Add("--------------------------------------------")
foreach ($line in $sampleLines) { $reportLines.Add($line) }
$reportLines.Add("--------------------------------------------")
$reportLines.Add("-----BEGIN SESSION JSON-----")
$reportLines.Add(($latencySessionObject | ConvertTo-Json -Depth 10))
$reportLines.Add("-----END SESSION JSON-----")
$reportLines.Add("============================================")

$report = $reportLines -join [Environment]::NewLine

Write-Host ""
Write-Host "  Server measured      : $selectedEndpointDisplay" -ForegroundColor Cyan
Write-Host "  Reliability          : $endpointConfidence" -ForegroundColor Cyan
Write-Host "  Measurement method   : $(if ($methodStats.PrimaryMethod -ne 'None') { "$($methodStats.PrimaryMethod) ($($methodStats.PrimaryPct)%)" } else { 'No successful RTT samples' })" -ForegroundColor Cyan
Write-Host "  Fallback used        : $(Format-YesNo $methodStats.FallbackOccurred)" -ForegroundColor Cyan
Write-Host "  Server changes       : $serverSwitches" -ForegroundColor Cyan
Write-Host "  Connection stability : $connectionStability" -ForegroundColor Cyan
if ($comparisonWarnings.Count -gt 0) {
    foreach ($warning in $comparisonWarnings) {
        Write-Host "  $warning" -ForegroundColor Yellow
    }
}
Write-Host ""

$report | Out-File -FilePath $outputFile -Encoding UTF8
Write-Host "[+] Saved to: $outputFile" -ForegroundColor Green

Write-Host ""
Write-Host "Press ENTER to exit..." -ForegroundColor Gray
Read-Host
